package ru.fatecore.world;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import ru.fatecore.util.Modes;

/** Сообщение при переходе между мирами: «Вы переместились в мир: [Название]». */
public final class WorldChangeListener implements Listener {

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        p.sendMessage("§eВы оказались в мире: §6[" + Modes.prettyWorld(p.getWorld().getName()) + "].");
    }
}
