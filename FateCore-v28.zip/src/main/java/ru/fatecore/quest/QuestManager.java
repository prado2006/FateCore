package ru.fatecore.quest;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.fatecore.FateCore;
import ru.fatecore.api.IDataStore;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.util.Items;
import ru.fatecore.util.Msg;
import ru.fatecore.util.YamlStore;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * МОДУЛЬ 6 — ежедневные квесты. Пул из 30 квестов (quests.yml → pool); у КАЖДОГО игрока свои
 * {@value #DAILY_COUNT} квеста на день (выбираются случайно при входе / смене суток МСК).
 * Награда квеста — Эхо / опыт / ключ / предмет (reward_type в quests.yml); за все квесты дня — одна случайная награда.
 * Прогресс игроков хранится там же (progress.<uuid>.q.<id>). Донат-группы выдать нельзя.
 */
public final class QuestManager {
    public static final String QUEST_GROUP = "quest";
    public static final ZoneId MSK = ZoneId.of("Europe/Moscow");
    public static final int DAILY_COUNT = 3;

    public enum Difficulty {
        EASY("&a", "Лёгкий", 15, 25),
        MEDIUM("&e", "Средний", 35, 50),
        HARD("&c", "Сложный", 70, 90);

        public final String color;
        public final String label;
        public final int minEcho;
        public final int maxEcho;

        Difficulty(String color, String label, int minEcho, int maxEcho) {
            this.color = color;
            this.label = label;
            this.minEcho = minEcho;
            this.maxEcho = maxEcho;
        }
    }

    /** Что считает квест. */
    public enum Type {
        BREAK_LOG(Material.OAK_LOG),
        PLACE_BLOCK(Material.BRICKS),
        BREAK_BLOCK(Material.IRON_PICKAXE),
        KILL_MOB(Material.IRON_SWORD),
        FISH(Material.FISHING_ROD),
        CRAFT(Material.CRAFTING_TABLE),
        BEDWARS_WIN(Material.RED_BED),
        BEDWARS_KILL(Material.RED_BED),
        SKYWARS_WIN(Material.ENDER_EYE),
        SKYWARS_KILL(Material.DIAMOND_SWORD),
        /** Урожай: созревшая культура (или арбуз, тыква, тростник и т.п.). */
        HARVEST(Material.WHEAT),
        /** Пройденные пешком блоки (ходьба и бег). */
        WALK(Material.LEATHER_BOOTS),
        VISIT_NETHER(Material.NETHERRACK),
        VISIT_END(Material.END_STONE),
        /** Сделка с жителем (или странствующим торговцем). */
        TRADE(Material.EMERALD),
        /** Покормить животное (оно вошло в режим любви). */
        FEED_ANIMAL(Material.WHEAT_SEEDS),
        /** Забрать результат из наковальни. */
        ANVIL(Material.ANVIL);

        public final Material icon;

        Type(Material icon) {
            this.icon = icon;
        }
    }

    /** Что получает игрок за квест: Эхо, очки опыта, ключи или предмет. */
    public enum RewardType { ECHO, XP, KEY, ITEM }

    public record Def(String id, String title, Type type, Difficulty difficulty, int target,
                      RewardType rewardType, int rewardAmount, Material rewardItem,
                      Set<String> filter, Material icon, String category, String description) {
        /** Засчитывается ли событие с такими ключами (названия блока/моба/предмета, HOSTILE, ANIMAL). */
        public boolean matches(String... keys) {
            if (filter.isEmpty()) return true;
            for (String k : keys) {
                if (k != null && filter.contains(k.toUpperCase(Locale.ROOT))) return true;
            }
            return false;
        }
    }

    private final FateCore plugin;
    private final EchoManager echo;
    private final YamlStore store;

    private Map<String, Def> pool;
    private YamlConfiguration jarDefaults;

    private final IDataStore data;

    public QuestManager(FateCore plugin, EchoManager echo, IDataStore data) {
        this.plugin = plugin;
        this.echo = echo;
        this.data = data;
        boolean created = !new File(plugin.getDataFolder(), "quests.yml").exists(); // YamlStore создаёт файл из jar
        this.store = new YamlStore(plugin, "quests.yml");

        // сообщения в консоль: владелец сразу видит, подхватился ли новый quests.yml
        int n = pool().size();
        long cats = pool().values().stream().map(Def::category).filter(c -> !c.isEmpty()).distinct().count();
        var console = plugin.getServer().getConsoleSender();
        console.sendMessage(created
                ? "§a[FateCore] Создан новый quests.yml с " + n + " квестами (" + cats + " категорий)."
                : "§a[FateCore] Загружено " + n + " квестов из quests.yml (категорий: " + cats + ").");
        LocalDate until = openingUntil();
        if (openingActive()) {
            console.sendMessage("§a[FateCore] Опенинг-буст активен до " + until + ", множитель x"
                    + plugin.getConfig().getDouble("economy.opening-boost", 1.0) + ".");
        }
    }

    // ---------- предохранители наград: множитель, опенинг-буст, недельный кап ----------

    /** Дата окончания опенинг-буста (economy.opening-boost-until, формат 2026-12-01) или null. */
    private LocalDate openingUntil() {
        Object o = plugin.getConfig().get("economy.opening-boost-until");
        if (o == null) return null;
        if (o instanceof java.util.Date d) return d.toInstant().atZone(MSK).toLocalDate(); // незаквотированная дата в YAML
        try {
            return LocalDate.parse(o.toString().trim());
        } catch (DateTimeParseException e) {
            plugin.getLogger().warning("economy.opening-boost-until: неверная дата «" + o + "» (нужен формат ГГГГ-ММ-ДД)");
            return null;
        }
    }

    /** Опенинг-буст действует ДО указанной даты (по МСК): в сам день окончания множитель уже 1.0. */
    private boolean openingActive() {
        LocalDate until = openingUntil();
        return until != null && LocalDate.now(MSK).isBefore(until);
    }

    /** Итоговый множитель наград за квесты: quest-reward-multiplier × (опенинг-буст, пока активен). */
    public double rewardMultiplier() {
        double m = Math.max(0, plugin.getConfig().getDouble("economy.quest-reward-multiplier", 1.0));
        if (openingActive()) m *= Math.max(0, plugin.getConfig().getDouble("economy.opening-boost", 1.0));
        return m;
    }

    /** Количество награды с учётом множителя (округление; при множителе > 0 не меньше 1). */
    private int scaled(int base) {
        double m = rewardMultiplier();
        if (m <= 0 || base <= 0) return 0;
        return (int) Math.max(1, Math.round(base * m));
    }

    private static final String K_ECHO_WEEK = "quest_echo_week";
    private static final String K_ECHO_USED = "quest_echo_used";

    /**
     * Начисляет Эхо за квест с недельным капом (economy.quest-weekly-echo-cap, 0 = без лимита).
     * Счётчик в IDataStore, сбрасывается в понедельник 00:00 МСК. Возвращает фактически начисленное.
     * При исчерпании капа квесты засчитываются, но Эхо не начисляется (игроку пишется сообщение).
     */
    private ru.fatecore.classes.ClassManager classes;

    /** Подключает классы (Торговец: +5% Эхо за квесты; кап недели при этом сохраняется). */
    public void setClasses(ru.fatecore.classes.ClassManager classes) { this.classes = classes; }

    private int grantQuestEcho(Player p, int amount) {
        if (amount <= 0) return 0;
        if (classes != null && classes.getClass(p.getUniqueId()) == ru.fatecore.classes.ClassManager.FateClass.TORGOVETS) {
            amount = (int) Math.round(amount * 1.05);
        }
        int cap = plugin.getConfig().getInt("economy.quest-weekly-echo-cap", 3000);
        if (cap <= 0) {
            echo.addEcho(p, amount);
            return amount;
        }
        UUID id = p.getUniqueId();
        long week = LocalDate.now(MSK).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toEpochDay();
        if (data.getLong(id, K_ECHO_WEEK, -1) != week) {
            data.setLong(id, K_ECHO_WEEK, week);
            data.setLong(id, K_ECHO_USED, 0);
        }
        long used = data.getLong(id, K_ECHO_USED, 0);
        int grant = (int) Math.max(0, Math.min(amount, cap - used));
        if (grant > 0) {
            data.setLong(id, K_ECHO_USED, used + grant);
            echo.addEcho(p, grant);
        }
        if (grant < amount) {
            p.sendMessage("§e[Квесты] §7Недельный лимит Эхо с квестов исчерпан (" + cap + "/" + cap + "). Сброс в понедельник.");
        }
        return grant;
    }

    private void giveKeys(Player p, int amount) {
        for (int i = 0; i < amount; i++) {
            ItemStack key = Items.make(Material.TRIPWIRE_HOOK, "&6Ключ", "&7Для открытия кейса");
            ItemMeta meta = key.getItemMeta();
            meta.getPersistentDataContainer().set(plugin.key("key"), PersistentDataType.BYTE, (byte) 1);
            key.setItemMeta(meta);
            Items.give(p, key);
        }
    }

    /** Есть ли у игрока на сегодня квест такого типа (быстрый фильтр для частых событий). */
    public boolean hasActive(UUID id, Type type) {
        for (Def d : activeQuests(id)) if (d.type() == type) return true;
        return false;
    }

    // ---------- определения (pool, plushka) ----------

    /** Определения берутся из quests.yml на сервере; если там старый формат (без pool) — из quests.yml внутри плагина. */
    private ConfigurationSection defs() {
        if (store.cfg().isConfigurationSection("pool")) return store.cfg();
        if (jarDefaults == null) {
            InputStream in = plugin.getResource("quests.yml");
            jarDefaults = in == null ? new YamlConfiguration()
                    : YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
            plugin.getLogger().warning("quests.yml на сервере в старом формате (нет pool) — используется пул из плагина. "
                    + "Удалите старый quests.yml, чтобы получить новый файл.");
        }
        return jarDefaults;
    }

    public Map<String, Def> pool() {
        if (pool == null) pool = parsePool();
        return pool;
    }

    private Map<String, Def> parsePool() {
        Map<String, Def> out = new LinkedHashMap<>();
        ConfigurationSection root = defs().getConfigurationSection("pool");
        if (root == null) return out;
        for (String id : root.getKeys(false)) {
            ConfigurationSection c = root.getConfigurationSection(id);
            if (c == null) continue;
            Type type;
            Difficulty diff;
            try {
                type = Type.valueOf(c.getString("type", "").toUpperCase(Locale.ROOT));
                diff = Difficulty.valueOf(c.getString("difficulty", "").toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("quests.yml: квест " + id + " пропущен (неверный type/difficulty)");
                continue;
            }
            // reward_type: echo | xp | key | item (+ reward_amount, для item ещё reward_item); старый формат: echo: N
            RewardType rt;
            try {
                rt = RewardType.valueOf(c.getString("reward_type", "echo").toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("quests.yml: квест " + id + " пропущен (неверный reward_type)");
                continue;
            }
            int rewardAmount = c.getInt("reward_amount", c.getInt("echo", diff.minEcho));
            Material rewardItem = null;
            if (rt == RewardType.ITEM) {
                rewardItem = Material.matchMaterial(c.getString("reward_item", ""));
                if (rewardItem == null) {
                    plugin.getLogger().warning("quests.yml: квест " + id + " пропущен (неверный reward_item)");
                    continue;
                }
            }
            if (rt == RewardType.ECHO && (rewardAmount < diff.minEcho || rewardAmount > diff.maxEcho)) {
                plugin.getLogger().warning("quests.yml: награда квеста " + id + " (" + rewardAmount + ") вне диапазона "
                        + diff + " " + diff.minEcho + "-" + diff.maxEcho);
            }
            Set<String> filter = new HashSet<>();
            for (String f : c.getStringList("filter")) filter.add(f.toUpperCase(Locale.ROOT));
            Material icon = Material.matchMaterial(c.getString("icon", ""));
            out.put(id, new Def(id, c.getString("title", id), type, diff, Math.max(1, c.getInt("target", 1)),
                    rt, rewardAmount, rewardItem, filter, icon != null ? icon : type.icon, c.getString("category", ""),
                    c.getString("description", "")));
        }
        return out;
    }

    // ---------- личные квесты дня ----------

    /** День МСК и границы его суток в мс: строку даты пересчитываем только при смене суток, а не на каждое событие. */
    private record DayCache(String day, long startMs, long endMs) {}

    private static volatile DayCache dayCache = new DayCache("", 0L, 0L);

    private static String today() {
        long now = System.currentTimeMillis();
        DayCache c = dayCache;
        if (now >= c.startMs() && now < c.endMs()) return c.day();
        LocalDate d = LocalDate.now(MSK);
        c = new DayCache(d.toString(),
                d.atStartOfDay(MSK).toInstant().toEpochMilli(),
                d.plusDays(1).atStartOfDay(MSK).toInstant().toEpochMilli());
        dayCache = c;
        return c.day();
    }

    /** Квесты игрока на сегодня (кэш в памяти, чтобы частые события не лезли в YAML). */
    private record Active(String day, List<Def> list) {}

    private final Map<UUID, Active> activeCache = new ConcurrentHashMap<>();

    /** Дополнительные слоты квестов за привилегии: права fatecore.quests.slots.1 / .2 (выдаются группами hero / overlord). */
    private static int extraSlots(Player p) {
        if (p == null) return 0;
        if (p.hasPermission("fatecore.quests.slots.2")) return 2;
        if (p.hasPermission("fatecore.quests.slots.1")) return 1;
        return 0;
    }

    /** Личные квесты игрока на сегодня: при смене суток МСК (или первом входе) выбираются 3 случайных из пула. */
    public List<Def> activeQuests(UUID id) {
        String today = today();
        Active cached = activeCache.get(id);
        if (cached != null && cached.day().equals(today)) return cached.list();

        Map<String, Def> all = pool();
        ConfigurationSection s = sec(id);
        if (today.equals(s.getString("lastReset"))) {
            List<Def> saved = new ArrayList<>();
            for (String q : s.getStringList("ids")) {
                Def d = all.get(q);
                if (d != null) saved.add(d);
            }
            if (!saved.isEmpty()) {
                Active a = new Active(today, Collections.unmodifiableList(saved));
                activeCache.put(id, a);
                return a.list();
            }
        }
        // новый день (или записи нет): сбрасываем прогресс и выбираем новые квесты
        s.set("q", null);
        s.set("dayCompleted", 0);
        s.set("rewarded", null);
        s.set("plushka", false);
        s.set("rerollDay", null);
        s.set("lastReset", today);
        return roll(id, s, today, all, List.of());
    }

    private List<Def> roll(UUID id, ConfigurationSection s, String today, Map<String, Def> all, List<Def> exclude) {
        List<Def> shuffled = new ArrayList<>(all.values());
        shuffled.removeAll(exclude);
        if (shuffled.size() < DAILY_COUNT) shuffled = new ArrayList<>(all.values());
        Collections.shuffle(shuffled, ThreadLocalRandom.current());
        int count = Math.min(DAILY_COUNT + extraSlots(plugin.getServer().getPlayer(id)), shuffled.size());
        List<Def> picked = new ArrayList<>(shuffled.subList(0, count));
        List<String> ids = new ArrayList<>();
        for (Def d : picked) ids.add(d.id());
        s.set("ids", ids);
        store.dirty();
        Active a = new Active(today, Collections.unmodifiableList(picked));
        activeCache.put(id, a);
        return a.list();
    }

    /** Смена квестов (покупка в бустах): не чаще 1 раза в сутки и только пока ни один квест не засчитан. null — можно. */
    public String rerollBlocker(UUID id) {
        activeQuests(id);
        ConfigurationSection s = sec(id);
        if (today().equals(s.getString("rerollDay"))) return "Смену квестов можно использовать только 1 раз в день.";
        if (s.getInt("dayCompleted") > 0) return "Нельзя перебросить квесты после выполнения хотя бы одного.";
        return null;
    }

    /** Выполняет смену квестов (проверку rerollBlocker делает вызывающий). Новые 3 квеста не повторяют прежние. */
    public void reroll(UUID id) {
        List<Def> old = activeQuests(id);
        ConfigurationSection s = sec(id);
        String today = today();
        s.set("q", null);
        s.set("rewarded", null);
        s.set("dayCompleted", 0);
        s.set("rerollDay", today);
        roll(id, s, today, pool(), old);
    }

    /** Освобождаем кэш при выходе игрока. */
    public void forget(UUID id) {
        activeCache.remove(id);
    }

    private static String itemName(Material m) {
        return switch (m) {
            case GOLDEN_APPLE -> "золотое яблоко";
            case DIAMOND -> "алмаз";
            case ARROW -> "стрела";
            case COOKED_BEEF -> "стейк";
            case BREAD -> "хлеб";
            case GOLDEN_CARROT -> "золотая морковь";
            case COOKED_SALMON -> "жареный лосось";
            default -> m.name().toLowerCase(Locale.ROOT).replace('_', ' ');
        };
    }

    /** Текст награды с учётом множителя (то, что игрок реально получит). */
    public String rewardText(Def d) {
        int n = scaled(d.rewardAmount());
        return switch (d.rewardType()) {
            case ECHO -> n + " Эхо";
            case XP -> n + " опыта";
            case KEY -> n + " " + (n == 1 ? "ключ" : "ключа");
            case ITEM -> n + " × " + itemName(d.rewardItem());
        };
    }

    // ---------- данные игрока ----------

    private ConfigurationSection sec(UUID id) {
        String path = "progress." + id;
        ConfigurationSection s = store.cfg().getConfigurationSection(path);
        return s != null ? s : store.cfg().createSection(path);
    }

    /** Гарантирует, что у игрока есть квесты на сегодня (сброс прогресса при смене суток). */
    public void resetQuestsIfNewDay(UUID id) {
        activeQuests(id);
    }

    /** Полночь МСК: у игроков онлайн выбираются новые квесты (офлайн — при следующем входе). */
    public void resetOnline() {
        plugin.getServer().getOnlinePlayers().forEach(p -> activeQuests(p.getUniqueId()));
    }

    public int progress(UUID id, Def d) {
        activeQuests(id);
        return sec(id).getInt("q." + d.id());
    }

    public int dayCompleted(UUID id) {
        activeQuests(id);
        return sec(id).getInt("dayCompleted");
    }

    public boolean plushkaGiven(UUID id) {
        activeQuests(id);
        return sec(id).getBoolean("plushka");
    }

    public String progressString(UUID id) {
        StringBuilder sb = new StringBuilder();
        for (Def d : activeQuests(id)) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(d.title()).append(' ').append(progress(id, d)).append('/').append(d.target());
        }
        return sb.toString();
    }

    // ---------- прогресс ----------

    /**
     * Засчитывает событие всем активным квестам данного типа, которым подходят ключи
     * (название блока/моба/предмета, HOSTILE, ANIMAL).
     */
    public void addProgress(Player p, Type type, int amount, String... keys) {
        UUID id = p.getUniqueId();
        List<Def> active = activeQuests(id);
        boolean relevant = false; // быстрый выход: ни один квест дня не считает этот тип событий (ломание/установка блоков — очень частые)
        for (Def d : active) {
            if (d.type() == type) {
                relevant = true;
                break;
            }
        }
        if (!relevant) return;
        ConfigurationSection s = sec(id);
        for (Def d : active) {
            if (d.type() != type || !d.matches(keys)) continue;
            int cur = s.getInt("q." + d.id());
            if (cur >= d.target()) continue;
            int now = Math.min(d.target(), cur + amount);
            s.set("q." + d.id(), now);
            store.dirty();
            if (now >= d.target()) complete(p, d, s);
        }
    }

    private java.util.function.Consumer<Player> completionHook;

    /** Вызывается после каждого выполненного квеста (для достижений). */
    public void setCompletionHook(java.util.function.Consumer<Player> hook) {
        this.completionHook = hook;
    }

    private void complete(Player p, Def d, ConfigurationSection s) {
        if (s.getBoolean("rewarded." + d.id())) return;
        s.set("rewarded." + d.id(), true);
        int done = s.getInt("dayCompleted") + 1;
        s.set("dayCompleted", done);
        store.dirty();

        String reward;
        int amount = scaled(d.rewardAmount());
        switch (d.rewardType()) {
            case ECHO -> {
                int granted = grantQuestEcho(p, amount); // недельный кап
                reward = granted > 0 ? granted + " Эхо" : null;
            }
            case XP -> {
                p.giveExp(amount);
                reward = amount + " опыта";
            }
            case KEY -> {
                giveKeys(p, amount);
                reward = rewardText(d);
            }
            default -> {
                Items.give(p, new ItemStack(d.rewardItem(), Math.max(1, amount)));
                reward = rewardText(d);
            }
        }
        Msg.send(p, "&aКвест выполнен: " + d.difficulty().color + "[" + d.difficulty().label + "] &6" + d.title()
                + (reward != null ? "&a. Награда: &e" + reward : "&a."));
        if (completionHook != null) completionHook.accept(p);

        if (done >= activeQuests(p.getUniqueId()).size() && !s.getBoolean("plushka")) {
            s.set("plushka", true);
            store.dirty();
            giveBonus(p);
        }
    }

    /** За все квесты дня: ОДНА случайная награда из quests.yml → plushka (Эхо, ключ, опыт, префикс, кирка, буст). */
    private void giveBonus(Player p) {
        List<Map<?, ?>> variants = defs().getMapList("plushka");
        if (variants.isEmpty()) return;
        Map<?, ?> v = variants.get(ThreadLocalRandom.current().nextInt(variants.size()));
        Msg.send(p, "&d&lВсе квесты выполнены! &fТвоя случайная награда: &e" + v.get("label"));
        Object rewards = v.get("rewards");
        if (rewards instanceof List<?> list) applyRewards(p, list);
    }

    // ---------- награды ----------

    private void applyRewards(Player p, List<?> rewards) {
        for (Object o : rewards) {
            if (o instanceof Map<?, ?> m) applyReward(p, m);
        }
    }

    private static double num(Map<?, ?> r, String k, double def) {
        Object o = r.get(k);
        return o instanceof Number n ? n.doubleValue() : def;
    }

    private static String str(Map<?, ?> r, String k) {
        Object o = r.get(k);
        return o == null ? "" : o.toString();
    }

    private void applyReward(Player p, Map<?, ?> r) {
        String type = str(r, "type").toLowerCase();
        switch (type) {
            case "echo" -> grantQuestEcho(p, scaled((int) num(r, "amount", 0)));
            case "item" -> {
                Material m = Material.matchMaterial(str(r, "material"));
                if (m == null) {
                    plugin.getLogger().warning("quests.yml: неизвестный материал " + str(r, "material"));
                    return;
                }
                int amount = scaled((int) num(r, "amount", 1));
                if (amount > 0) Items.give(p, new ItemStack(m, amount));
            }
            case "effect" -> {
                PotionEffectType t = PotionEffectType.getByName(str(r, "effect"));
                if (t == null) {
                    plugin.getLogger().warning("quests.yml: неизвестный эффект " + str(r, "effect"));
                    return;
                }
                p.addPotionEffect(new PotionEffect(t, (int) num(r, "seconds", 60) * 20, (int) num(r, "amplifier", 0)));
            }
            case "key" -> {
                giveKeys(p, scaled((int) num(r, "amount", 1)));
            }
            case "tools" -> giveTools(p, r);
            case "quest_prefix" -> grantQuestPrefix(p, (long) num(r, "hours", 24));
            case "echo_boost" -> echo.addBoost(p.getUniqueId(), num(r, "multiplier", 1.1), (long) num(r, "seconds", 3600));
            default -> plugin.getLogger().warning("quests.yml: тип награды «" + type + "» не разрешён и пропущен");
        }
    }

    private void giveTools(Player p, Map<?, ?> r) {
        Object items = r.get("items");
        Object enchants = r.get("enchants");
        if (!(items instanceof List<?> list)) return;
        for (Object name : list) {
            Material mat = Material.matchMaterial(String.valueOf(name));
            if (mat == null) continue;
            ItemStack it = new ItemStack(mat);
            if (enchants instanceof Map<?, ?> em) {
                for (Map.Entry<?, ?> en : em.entrySet()) {
                    // getByKey работает на 1.20.1 и новее (константы EFFICIENCY/UNBREAKING есть только в новых API)
                    Enchantment ench = Enchantment.getByKey(
                            NamespacedKey.minecraft(String.valueOf(en.getKey()).toLowerCase()));
                    if (ench != null && en.getValue() instanceof Number n) {
                        it.addUnsafeEnchantment(ench, n.intValue());
                    }
                }
            }
            Items.give(p, it);
        }
    }

    // ---------- префикс [Quest]: только группа "quest", на ограниченное время ----------

    /** Единственная группа, которую выдают квесты: косметический префикс [Quest], НЕ донат-ранг. */
    public void grantQuestPrefix(Player p, long hours) {
        LuckPerms lp = LuckPermsProvider.get();
        Instant until = Instant.now().plus(Duration.ofHours(hours));
        lp.getUserManager().modifyUser(p.getUniqueId(), user -> {
            user.data().clear(NodeType.INHERITANCE.predicate(n -> n.getGroupName().equals(QUEST_GROUP)));
            user.data().add(InheritanceNode.builder(QUEST_GROUP).expiry(until).build());
        });
        sec(p.getUniqueId()).set("questPrefixUntil", until.toEpochMilli());
        store.dirty();
    }

    /** Планировщик: снимает группу quest, когда срок вышел. */
    public void checkPrefixExpiry(Player p) {
        // только чтение: не создаём пустую секцию игрока каждую минуту
        long until = store.cfg().getLong("progress." + p.getUniqueId() + ".questPrefixUntil");
        if (until <= 0 || System.currentTimeMillis() < until) return;
        LuckPerms lp = LuckPermsProvider.get();
        lp.getUserManager().modifyUser(p.getUniqueId(), user ->
                user.data().clear(NodeType.INHERITANCE.predicate(n -> n.getGroupName().equals(QUEST_GROUP))));
        sec(p.getUniqueId()).set("questPrefixUntil", 0);
        store.dirty();
    }

    public void checkPrefixExpiryOnline() {
        plugin.getServer().getOnlinePlayers().forEach(this::checkPrefixExpiry);
    }
}
