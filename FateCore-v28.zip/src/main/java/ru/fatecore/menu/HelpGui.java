package ru.fatecore.menu;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import ru.fatecore.learn.BountyCommand;
import ru.fatecore.learn.PlaytimeTask;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public final class HelpGui implements Listener {

    private static final int SIZE = 54;
    private static final int SLOT_TITLE = 4;
    private static final int SLOT_DONATE = 16;
    private static final int SLOT_CLOSE = 49;
    private static final int SLOT_GUIDE = 40;

    private static final Map<Integer, String> COMMANDS = new HashMap<>();
    static {
        COMMANDS.put(10, "help");
        COMMANDS.put(12, "quests");
        COMMANDS.put(14, "shop");
        COMMANDS.put(20, "daily");
        COMMANDS.put(22, "playtime");
        COMMANDS.put(32, "lobby");
        COMMANDS.put(28, "stats");
    }

    public static final class Holder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    private final Plugin plugin;
    private final DonateGui donateGui;
    private final ru.fatecore.onboarding.OnboardingListener onboarding;

    private java.util.function.Consumer<Player> back;

    /** Действие кнопки «Назад» (открыть главное меню). */
    public void setBack(java.util.function.Consumer<Player> back) { this.back = back; }

    public HelpGui(Plugin plugin, DonateGui donateGui, ru.fatecore.onboarding.OnboardingListener onboarding) {
        this.plugin = plugin;
        this.onboarding = onboarding;
        this.donateGui = donateGui;
    }

    private static final Component TITLE = MenuItems.text("&6Помощь и возможности сервера");

    /** Содержимое меню собирается один раз; слот обмена пересобирается, только если изменился налог в конфиге. */
    private ItemStack[] template;
    private int tradeTax = Integer.MIN_VALUE;
    private String playReward;

    private ItemStack[] template() {
        int tax = ru.fatecore.trade.TradeGui.tax(plugin);
        ItemStack[] tpl = template;
        if (tpl == null) {
            tpl = new ItemStack[SIZE];
            Arrays.fill(tpl, MenuItems.filler(Material.BLACK_STAINED_GLASS_PANE));

            tpl[SLOT_TITLE] = MenuItems.button(Material.BOOK, "&6&lВозможности сервера",
                    "&7Здесь собраны все фишки сервера.", "&7Нажимайте на предметы — команды выполнятся сами.");

            tpl[10] = MenuItems.button(Material.BOOK, "&e/help", "&7Список всех команд сервера", "", "&aНажми, чтобы выполнить");
            tpl[12] = MenuItems.button(Material.WRITABLE_BOOK, "&e/quests", "&7Ежедневные задания Квестового Мастера", "", "&aНажми, чтобы выполнить");
            tpl[14] = MenuItems.button(Material.EMERALD, "&e/shop", "&7Магазин сервера за Эхо", "", "&aНажми, чтобы выполнить");
            tpl[SLOT_DONATE] = MenuItems.button(Material.NETHER_STAR, "&e/donate", "&7Привилегии и поддержка проекта", "", "&aНажми, чтобы открыть");

            tpl[20] = MenuItems.button(Material.GOLD_INGOT, "&6Ежедневная награда",
                    "&7Команда: &e/daily", "&7Заходите каждый день — чем длиннее серия,", "&7тем больше награда.", "", "&aНажми, чтобы получить");
            tpl[24] = MenuItems.button(Material.SKELETON_SKULL, "&6Баунти",
                    "&7Назначьте награду за голову игрока:", "&e/bounty <ник> <сумма>",
                    "&7Минимум: &e" + BountyCommand.MIN_AMOUNT + " Эхо&7. Комиссия: &e" + BountyCommand.COMMISSION_PERCENT + "%&7",
                    "&7(у привилегий комиссия ниже).",
                    "&7Тот, кто убьёт его, получит это Эхо.");
            tpl[30] = MenuItems.button(Material.SHIELD, "&6Боевой режим",
                    "&7В бою нельзя телепортироваться &e15 сек&7.", "&7Выход из игры во время боя — смерть.");
            tpl[32] = MenuItems.button(Material.FEATHER, "&6Возврат в хаб",
                    "&7Команда: &e/lobby", "&7Защита от падения в пустоту.", "", "&aНажми, чтобы вернуться");

            tpl[28] = MenuItems.button(Material.PLAYER_HEAD, "&6Статистика",
                    "&7Убийства, смерти, победы и время игры.", "&7Команда: &e/stats", "", "&aНажми, чтобы открыть");

            tpl[SLOT_GUIDE] = MenuItems.button(Material.WRITTEN_BOOK, "&6&lГид по серверу",
                    "&7Книга новичка: классы, режимы,", "&7правила, Эхо и квесты.", "", "&aНажми, чтобы открыть книгу");

            tpl[SLOT_CLOSE] = MenuItems.button(Material.ARROW, "&eНазад", "&7Вернуться в главное меню");
            template = tpl;
            tradeTax = Integer.MIN_VALUE;
            playReward = null;
        }
        String reward = PlaytimeTask.rewardText(plugin.getConfig());
        if (!reward.equals(playReward)) { // economy.hourly-playtime-reward мог измениться (/fatecore reload)
            tpl[22] = MenuItems.button(Material.CLOCK, "&6Награда за игру",
                    "&7За каждый час игры дают &e" + reward + " Эхо&7.", "&7Проверить время: &e/playtime", "", "&aНажми, чтобы проверить");
            playReward = reward;
        }
        if (tax != tradeTax) {
            tpl[34] = MenuItems.button(Material.PAPER, "&6Обмен",
                    "&7Безопасный обмен предметами:", "&e/trade <ник>",
                    "&7Налог: &e" + tax + " Эхо &7с участника (у привилегий ниже).");
            tradeTax = tax;
        }
        return tpl;
    }

    public void open(Player player) {
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.inventory = inv;
        inv.setContents(template());
        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;

        int slot = e.getSlot();
        if (slot == SLOT_CLOSE) {
            if (back != null) back.accept(p); else p.closeInventory();
        } else if (slot == SLOT_GUIDE) {
            ItemStack book = onboarding.guideBook();
            p.closeInventory();
            if (book == null) {
                p.sendMessage(MenuItems.text("&cГид пока недоступен."));
            } else {
                Bukkit.getScheduler().runTask(plugin, () -> p.openBook(book));
            }
        } else if (slot == SLOT_DONATE) {
            Bukkit.getScheduler().runTask(plugin, () -> donateGui.open(p));
        } else if (COMMANDS.containsKey(slot)) {
            String cmd = COMMANDS.get(slot);
            p.closeInventory();
            Bukkit.getScheduler().runTask(plugin, () -> p.performCommand(cmd));
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
