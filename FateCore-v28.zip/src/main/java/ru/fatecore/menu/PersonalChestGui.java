package ru.fatecore.menu;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import ru.fatecore.FateCore;
import ru.fatecore.util.Items;
import ru.fatecore.util.YamlStore;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Персональный сундук: /enderchest (/echest, /ec) открывает собственное меню.
 * Страница 1 — настоящий эндер-сундук игрока (27 слотов), страницы 2–4 хранятся в enderchest.yml.
 * Число страниц задают права fatecore.ec.pages.2 / fatecore.ec.pages.4 (без них — 1 страница).
 * Внизу меню — кнопки «Назад» / «Вперёд» и номер страницы. Содержимое сохраняется после каждого клика,
 * при смене страницы, закрытии и выключении плагина. Команда с ником и игроки без essentials.enderchest — как обычно (Essentials).
 */
public final class PersonalChestGui implements Listener {
    private static final int ITEM_SLOTS = 27;
    private static final int SIZE = 36;
    private static final int SLOT_PREV = 30;
    private static final int SLOT_INFO = 31;
    private static final int SLOT_NEXT = 32;
    private static final Set<String> ALIASES = Set.of(
            "enderchest", "echest", "ec", "essentials:enderchest", "essentials:echest", "essentials:ec");

    /** Маркер меню (используется и защитой Творческого режима). */
    public static final class Holder implements InventoryHolder {
        private Inventory inventory;
        private int page = 1;
        @Override public Inventory getInventory() { return inventory; }
    }

    private final FateCore plugin;
    private final YamlStore store;

    public PersonalChestGui(FateCore plugin) {
        this.plugin = plugin;
        this.store = new YamlStore(plugin, "enderchest.yml");
    }

    /** Сколько страниц доступно игроку по правам. */
    public static int pagesFor(Player p) {
        if (p.hasPermission("fatecore.ec.pages.4")) return 4;
        if (p.hasPermission("fatecore.ec.pages.2")) return 2;
        return 1;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String trimmed = e.getMessage().trim();
        if (trimmed.length() < 3 || trimmed.indexOf(' ') >= 0) return; // /enderchest <игрок> — не наш случай
        if (!ALIASES.contains(trimmed.substring(1).toLowerCase(Locale.ROOT))) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("essentials.enderchest")) return;
        e.setCancelled(true);
        open(p, 1);
    }

    public void open(Player p) {
        open(p, 1);
    }

    private void open(Player p, int page) {
        int pages = pagesFor(p);
        int pg = Math.max(1, Math.min(page, pages));
        Holder holder = new Holder();
        holder.page = pg;
        Inventory inv = Bukkit.createInventory(holder, SIZE, title(pg, pages));
        holder.inventory = inv;
        inv.setContents(new ItemStack[SIZE]);
        ItemStack[] items = load(p, pg);
        for (int i = 0; i < ITEM_SLOTS; i++) inv.setItem(i, items[i]);
        for (int i = ITEM_SLOTS; i < SIZE; i++) inv.setItem(i, Items.make(Material.BLACK_STAINED_GLASS_PANE, " "));
        if (pg > 1) inv.setItem(SLOT_PREV, Items.make(Material.ARROW, "&eНазад", "&7Страница " + (pg - 1)));
        inv.setItem(SLOT_INFO, Items.make(Material.ENDER_CHEST, "&6Страница " + pg + "/" + pages,
                pages == 1 ? "&7Больше страниц — с привилегией" : "&7Листай стрелками"));
        if (pg < pages) inv.setItem(SLOT_NEXT, Items.make(Material.ARROW, "&eВперёд", "&7Страница " + (pg + 1)));
        p.openInventory(inv);
    }

    private static Component title(int page, int pages) {
        return LegacyComponentSerializer.legacySection().deserialize(
                pages > 1 ? "§8Персональный сундук §7(" + page + "/" + pages + ")" : "§8Персональный сундук");
    }

    // ---------- хранение ----------

    private ItemStack[] load(Player p, int page) {
        ItemStack[] out = new ItemStack[ITEM_SLOTS];
        if (page == 1) {
            ItemStack[] ec = p.getEnderChest().getContents();
            System.arraycopy(ec, 0, out, 0, Math.min(ec.length, ITEM_SLOTS));
            return out;
        }
        List<?> saved = store.cfg().getList(path(p.getUniqueId(), page));
        if (saved != null) {
            for (int i = 0; i < ITEM_SLOTS && i < saved.size(); i++) {
                if (saved.get(i) instanceof ItemStack s) out[i] = s;
            }
        }
        return out;
    }

    private static String path(UUID id, int page) {
        return "players." + id + ".page" + page;
    }

    private void save(Player p, int page, Inventory inv) {
        if (page == 1) {
            ItemStack[] ec = new ItemStack[p.getEnderChest().getSize()];
            for (int i = 0; i < ITEM_SLOTS && i < ec.length; i++) ec[i] = inv.getItem(i);
            p.getEnderChest().setContents(ec);
            return;
        }
        List<ItemStack> list = new ArrayList<>(ITEM_SLOTS);
        boolean empty = true;
        for (int i = 0; i < ITEM_SLOTS; i++) {
            ItemStack s = inv.getItem(i);
            list.add(s);
            if (s != null && s.getType() != Material.AIR) empty = false;
        }
        store.cfg().set(path(p.getUniqueId(), page), empty ? null : list);
        store.dirty();
    }

    /** Сохранить открытые сейчас меню (вызывается при выключении плагина). */
    public void saveAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof Holder h) {
                save(p, h.page, p.getOpenInventory().getTopInventory());
            }
        }
    }

    // ---------- события ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder h) || !(e.getWhoClicked() instanceof Player p)) return;
        // двойной клик «собрать на курсор» вытащил бы кнопки-заглушки из нижнего ряда
        if (e.getAction() == InventoryAction.COLLECT_TO_CURSOR) {
            e.setCancelled(true);
            return;
        }
        int raw = e.getRawSlot();
        if (raw >= ITEM_SLOTS && raw < SIZE) { // нижний ряд меню — только кнопки
            e.setCancelled(true);
            int pages = pagesFor(p);
            int target = raw == SLOT_PREV && h.page > 1 ? h.page - 1 : raw == SLOT_NEXT && h.page < pages ? h.page + 1 : 0;
            if (target > 0) {
                save(p, h.page, top);
                Bukkit.getScheduler().runTask(plugin, () -> open(p, target));
            }
            return;
        }
        if (e.isCancelled()) return;
        Bukkit.getScheduler().runTask(plugin, () -> save(p, h.page, top)); // после применения клика
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder h) || !(e.getWhoClicked() instanceof Player p)) return;
        for (int slot : e.getRawSlots()) {
            if (slot >= ITEM_SLOTS && slot < SIZE) {
                e.setCancelled(true);
                return;
            }
        }
        Bukkit.getScheduler().runTask(plugin, () -> save(p, h.page, top));
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getInventory().getHolder() instanceof Holder h && e.getPlayer() instanceof Player p) {
            save(p, h.page, e.getInventory());
        }
    }
}
