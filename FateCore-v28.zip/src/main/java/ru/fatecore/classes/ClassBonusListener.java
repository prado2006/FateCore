package ru.fatecore.classes;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Animals;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.event.entity.EntityBreedEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.BrewEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.BrewerInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.fatecore.classes.ClassManager.FateClass;
import ru.fatecore.util.Items;
import ru.fatecore.util.Modes;
import ru.fatecore.util.Msg;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Пассивные бонусы классов. Работают ТОЛЬКО в мирах Выживания (hub, hub_nether, hub_the_end),
 * чтобы не влиять на мини-игры, и не меняют начисление Эхо (кроме бонуса Торговца к квестам).
 */
public final class ClassBonusListener implements Listener {
    private static final UUID HEALTH_ID = UUID.fromString("5f0b7c3e-61d4-4a52-9a1e-fa7ec0de0001");
    private static final String HEALTH_NAME = "fatecore_voin_health";

    private static final Set<Material> ORES = EnumSet.of(
            Material.COAL_ORE, Material.DEEPSLATE_COAL_ORE, Material.IRON_ORE, Material.DEEPSLATE_IRON_ORE,
            Material.COPPER_ORE, Material.DEEPSLATE_COPPER_ORE, Material.GOLD_ORE, Material.DEEPSLATE_GOLD_ORE,
            Material.REDSTONE_ORE, Material.DEEPSLATE_REDSTONE_ORE, Material.LAPIS_ORE, Material.DEEPSLATE_LAPIS_ORE,
            Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE, Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE,
            Material.NETHER_GOLD_ORE, Material.NETHER_QUARTZ_ORE);

    private static final Set<Material> CROPS = EnumSet.of(
            Material.WHEAT, Material.CARROTS, Material.POTATOES, Material.BEETROOTS, Material.NETHER_WART);

    private final Plugin plugin;
    private final ClassManager classes;
    /** Кто последним открывал варочную стойку (для бонуса Алхимика): координаты -> игрок. */
    private final Map<Location, UUID> brewers = new HashMap<>();

    public ClassBonusListener(Plugin plugin, ClassManager classes) {
        this.plugin = plugin;
        this.classes = classes;
    }

    private boolean is(Player p, FateClass c) {
        return p != null && Modes.isSurvivalFamily(p.getWorld()) && classes.getClass(p.getUniqueId()) == c;
    }

    private static boolean chance(double p) {
        return ThreadLocalRandom.current().nextDouble() < p;
    }

    // ---------- Кузнец ----------

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onOreDrop(BlockDropItemEvent e) {
        Player p = e.getPlayer();
        if (!is(p, FateClass.KUZNEC)) return;
        if (!ORES.contains(e.getBlockState().getType())) return;
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (tool.containsEnchantment(Enchantment.SILK_TOUCH)) return; // руда-блок не удваиваем
        if (!chance(0.15)) return;
        List<ItemStack> extra = new ArrayList<>();
        for (org.bukkit.entity.Item it : e.getItems()) extra.add(it.getItemStack().clone());
        for (ItemStack s : extra) Items.give(p, s); // бонус кладётся в инвентарь (или под ноги, если полон)
    }

    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        if (!(e.getView().getPlayer() instanceof Player p) || !is(p, FateClass.KUZNEC)) return;
        AnvilInventory inv = e.getInventory();
        int cost = inv.getRepairCost();
        if (cost <= 1) return;
        inv.setRepairCost(Math.max(1, (int) Math.floor(cost * 0.8)));
    }

    // ---------- Воин ----------

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        Entity d = e.getDamager();
        Player p = null;
        if (d instanceof Player pl) p = pl;
        else if (d instanceof Projectile pr && pr.getShooter() instanceof Player pl) p = pl;
        if (p == null || !is(p, FateClass.VOIN)) return;
        e.setDamage(e.getDamage() * 1.10);
    }

    /** Приводит максимум здоровья в соответствие: +4 (2 сердца) только Воину в Выживании. */
    public void syncHealth(Player p) {
        AttributeInstance a = p.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (a == null) return;
        AttributeModifier cur = null;
        for (AttributeModifier m : a.getModifiers()) {
            if (m.getUniqueId().equals(HEALTH_ID)) cur = m;
        }
        boolean want = is(p, FateClass.VOIN);
        if (want && cur == null) {
            a.addModifier(new AttributeModifier(HEALTH_ID, HEALTH_NAME, 4.0, AttributeModifier.Operation.ADD_NUMBER));
        } else if (!want && cur != null) {
            a.removeModifier(cur);
            if (p.getHealth() > a.getValue()) p.setHealth(a.getValue());
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTask(plugin, () -> syncHealth(e.getPlayer()));
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        Bukkit.getScheduler().runTask(plugin, () -> syncHealth(e.getPlayer()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        AttributeInstance a = e.getPlayer().getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (a == null) return;
        for (AttributeModifier m : new ArrayList<>(a.getModifiers())) {
            if (m.getUniqueId().equals(HEALTH_ID)) a.removeModifier(m);
        }
    }

    // ---------- Фермер ----------

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onHarvestDrop(BlockDropItemEvent e) {
        Player p = e.getPlayer();
        if (!is(p, FateClass.FERMER)) return;
        BlockData data = e.getBlockState().getBlockData();
        if (!CROPS.contains(e.getBlockState().getType()) || !(data instanceof Ageable ag)) return;
        if (ag.getAge() < ag.getMaximumAge()) return; // только спелый урожай
        if (!chance(0.20)) return;
        for (org.bukkit.entity.Item it : new ArrayList<>(e.getItems())) {
            Items.give(p, it.getItemStack().clone());
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreed(EntityBreedEvent e) {
        if (!(e.getBreeder() instanceof Player p) || !is(p, FateClass.FERMER)) return;
        Entity mother = e.getMother();
        Entity father = e.getFather();
        // перерыв размножения (возраст > 0) снимаем на следующем тике
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (mother instanceof Animals a && a.isValid()) a.setAge(0);
            if (father instanceof Animals a && a.isValid()) a.setAge(0);
        });
    }

    // ---------- Алхимик ----------

    @EventHandler(ignoreCancelled = true)
    public void onPotionDrink(PlayerItemConsumeEvent e) {
        Player p = e.getPlayer();
        if (!is(p, FateClass.ALHIMIK)) return;
        ItemStack item = e.getItem();
        if (item.getType() != Material.POTION || !(item.getItemMeta() instanceof PotionMeta pm)) return;
        List<PotionEffectType> types = new ArrayList<>();
        if (pm.getBasePotionData().getType().getEffectType() != null) types.add(pm.getBasePotionData().getType().getEffectType());
        for (PotionEffect pe : pm.getCustomEffects()) types.add(pe.getType());
        if (types.isEmpty()) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (PotionEffectType t : types) {
                PotionEffect cur = p.getPotionEffect(t);
                if (cur == null || cur.getDuration() <= 0 || cur.getDuration() >= 1_000_000) continue;
                p.addPotionEffect(new PotionEffect(t, (int) Math.round(cur.getDuration() * 1.25),
                        cur.getAmplifier(), cur.isAmbient(), cur.hasParticles(), cur.hasIcon()));
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    public void onStandOpen(InventoryOpenEvent e) {
        if (!(e.getInventory() instanceof BrewerInventory bi) || !(e.getPlayer() instanceof Player p)) return;
        Location l = bi.getLocation();
        if (l == null) return;
        brewers.put(l.getBlock().getLocation(), p.getUniqueId());
        if (brewers.size() > 500) brewers.clear();
    }

    @EventHandler(ignoreCancelled = true)
    public void onBrew(BrewEvent e) {
        Block b = e.getBlock();
        UUID owner = brewers.get(b.getLocation());
        if (owner == null) return;
        Player p = Bukkit.getPlayer(owner);
        if (!is(p, FateClass.ALHIMIK) || !chance(0.15)) return;
        ItemStack sample = null;
        for (ItemStack r : e.getResults()) {
            if (r != null && r.getType() != Material.AIR) { sample = r.clone(); break; }
        }
        if (sample == null) return;
        ItemStack extra = sample;
        // результаты применяются после события — выдаём бонусное зелье на следующем тике
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            Items.give(p, extra);
            Msg.send(p, "&d[Алхимик] &fБонус класса: сварено ещё одно зелье!");
        });
    }
}
