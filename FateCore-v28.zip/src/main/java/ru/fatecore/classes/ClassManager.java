package ru.fatecore.classes;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Inventory;
import ru.fatecore.FateCore;
import ru.fatecore.api.IDataStore;
import ru.fatecore.gui.FateHolder;
import ru.fatecore.learn.PlaytimeTask;
import ru.fatecore.util.Items;
import ru.fatecore.util.Msg;
import ru.fatecore.util.YamlStore;

import java.util.UUID;

/** Классы: Кузнец / Воин / Фермер / Алхимик / Торговец. Смена раз в 7 дней. Бонусы — только в Выживании. */
public final class ClassManager {

    public enum FateClass {
        KUZNEC("kuznec", "Кузнец", Material.ANVIL, 11,
                "&7Мастер ремесла и ковки.",
                "&a+ &f15% шанс двойной добычи руды",
                "&a+ &f−20% к стоимости ремонта на наковальне"),
        VOIN("voin", "Воин", Material.IRON_SWORD, 12,
                "&7Мастер боя и защиты.",
                "&a+ &f+10% к наносимому урону",
                "&a+ &f+2 сердца к максимальному здоровью"),
        FERMER("fermer", "Фермер", Material.GOLDEN_CARROT, 13,
                "&7Хозяин полей и ферм.",
                "&a+ &f20% шанс двойного урожая",
                "&a+ &fЖивотные размножаются без перерыва"),
        ALHIMIK("alhimik", "Алхимик", Material.EXPERIENCE_BOTTLE, 14,
                "&7Знаток зелий и эликсиров.",
                "&a+ &f+25% к длительности зелий",
                "&a+ &f15% шанс сварить 2 зелья вместо одного"),
        TORGOVETS("torgovets", "Торговец", Material.EMERALD, 15,
                "&7Знаток выгодных сделок.",
                "&a+ &f+5% Эхо за выполненные квесты",
                "&a+ &f−10% на улучшения в /shop");

        public final String id;
        public final String title;
        public final Material icon;
        public final int slot;
        public final String desc;
        public final String[] perks;

        FateClass(String id, String title, Material icon, int slot, String desc, String... perks) {
            this.id = id;
            this.title = title;
            this.icon = icon;
            this.slot = slot;
            this.desc = desc;
            this.perks = perks;
        }

        public static FateClass byId(String id) {
            for (FateClass c : values()) if (c.id.equalsIgnoreCase(id)) return c;
            return null;
        }

        public static FateClass bySlot(int slot) {
            for (FateClass c : values()) if (c.slot == slot) return c;
            return null;
        }
    }

    /** Новичкам (меньше стольких минут игры) право fatecore.class.use не требуется. */
    public static final long NEWBIE_MINUTES = 120;
    public static final String HINT = "&7Классы дают пассивные бонусы в Выживании.";

    private final FateCore plugin;
    private final IDataStore data;
    private final YamlStore store;

    public ClassManager(FateCore plugin, IDataStore data) {
        this.plugin = plugin;
        this.data = data;
        this.store = new YamlStore(plugin, "classes.yml");
    }

    public FateClass getClass(UUID id) {
        String v = store.cfg().getString("players." + id + ".class");
        return v == null ? null : FateClass.byId(v);
    }

    public String getTitle(UUID id) {
        FateClass c = getClass(id);
        return c == null ? "—" : c.title;
    }

    private long changeDays() {
        return store.cfg().getLong("change-days", plugin.getConfig().getLong("classes.change-days", 7));
    }

    private long cooldownMs() {
        return changeDays() * 24L * 60 * 60 * 1000;
    }

    /** Сколько мс осталось до возможности смены (0 — можно). */
    public long remainingMs(UUID id) {
        if (getClass(id) == null) return 0;
        long changedAt = store.cfg().getLong("players." + id + ".changedAt");
        return Math.max(0, changedAt + cooldownMs() - System.currentTimeMillis());
    }

    /**
     * Можно ли выбирать/менять класс: с правом fatecore.class.use; без права — только пока игрок
     * отыграл меньше 2 часов (PlaytimeTask.KEY) или ещё не выбрал класс вообще.
     */
    public boolean canChoose(Player p) {
        if (p.hasPermission("fatecore.class.use")) return true;
        if (getClass(p.getUniqueId()) == null) return true;
        return data.getLong(p.getUniqueId(), PlaytimeTask.KEY, 0) < NEWBIE_MINUTES;
    }

    private java.util.function.Consumer<Player> back;
    private java.util.function.Consumer<Player> onChange;

    /** Вызывается после смены класса (обновить здоровье Воина и т.п.). */
    public void setOnChange(java.util.function.Consumer<Player> onChange) { this.onChange = onChange; }

    /** Действие кнопки «Назад» (открыть главное меню). */
    public void setBack(java.util.function.Consumer<Player> back) { this.back = back; }

    private static final int SLOT_BACK = 22;

    public void openGui(Player p) {
        FateHolder holder = new FateHolder("class");
        Inventory inv = Bukkit.createInventory(holder, 27, Msg.c("&8Выбери класс"));
        holder.bind(inv);
        Items.fill(inv); // чёрное стекло
        ItemStack frame = Items.make(Material.ORANGE_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) {
            if (i < 9 || i >= 18 || i % 9 == 0 || i % 9 == 8) inv.setItem(i, frame);
        }
        FateClass cur = getClass(p.getUniqueId());
        for (FateClass c : FateClass.values()) {
            java.util.List<String> lore = new java.util.ArrayList<>();
            lore.add(c.desc);
            lore.add("");
            lore.addAll(java.util.Arrays.asList(c.perks));
            lore.add("");
            lore.add(cur == c ? "&aТвой текущий класс" : "&eКлик — выбрать");
            lore.add("&8Смена класса — раз в " + changeDays() + " дней");
            lore.add("&8Бонусы работают в Выживании");
            inv.setItem(c.slot, Items.make(c.icon, "&6" + c.title, lore.toArray(new String[0])));
        }
        inv.setItem(SLOT_BACK, Items.make(Material.ARROW, "&eНазад", "&7Вернуться в главное меню"));
        p.openInventory(inv);
    }

    public void handleClick(Player p, int slot) {
        if (slot == SLOT_BACK) {
            if (back != null) back.accept(p); else p.closeInventory();
            return;
        }
        FateClass c = FateClass.bySlot(slot);
        if (c == null) return;
        select(p, c);
    }

    private void select(Player p, FateClass c) {
        UUID id = p.getUniqueId();
        if (!canChoose(p)) {
            Msg.send(p, "&cПосле 2 часов игры смена класса доступна только с правом &efatecore.class.use&c.");
            return;
        }
        if (getClass(id) == c) {
            Msg.send(p, "&7Это уже твой класс.");
            return;
        }
        long left = remainingMs(id);
        if (left > 0) {
            long hours = left / 3_600_000L;
            Msg.send(p, "&cСменить класс можно через " + (hours / 24) + " д. " + (hours % 24) + " ч.");
            return;
        }
        store.cfg().set("players." + id + ".class", c.id);
        store.cfg().set("players." + id + ".changedAt", System.currentTimeMillis());
        store.dirty();
        p.closeInventory();
        Msg.send(p, "&aТы выбрал класс: &6" + c.title);
        if (onChange != null) onChange.accept(p);
    }
}
