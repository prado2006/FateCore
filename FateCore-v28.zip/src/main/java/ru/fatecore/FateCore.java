package ru.fatecore;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import ru.fatecore.admin.FateCommand;
import ru.fatecore.afk.AfkManager;
import ru.fatecore.api.EchoServiceAdapter;
import ru.fatecore.api.IDataStore;
import ru.fatecore.api.IEchoService;
import ru.fatecore.api.PlayerDataStore;
import ru.fatecore.classes.ClassBonusListener;
import ru.fatecore.classes.ClassListener;
import ru.fatecore.classes.ClassManager;
import ru.fatecore.combat.CombatListener;
import ru.fatecore.combat.CombatManager;
import ru.fatecore.creative.CreativeProtection;
import ru.fatecore.earn.EarnListener;
import ru.fatecore.earn.EarnService;
import ru.fatecore.chat.ChatListener;
import ru.fatecore.chat.JoinLeaveListener;
import ru.fatecore.chat.TitleCommand;
import ru.fatecore.echo.EchoCommand;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.echo.EchoNotifier;
import ru.fatecore.gui.GuiListener;
import ru.fatecore.learn.*;
import ru.fatecore.menu.*;
import ru.fatecore.onboarding.AntiBotListener;
import ru.fatecore.onboarding.OnboardingListener;
import ru.fatecore.perks.AuctionSlots;
import ru.fatecore.perks.AutoPickup;
import ru.fatecore.perks.DurabilityCommand;
import ru.fatecore.perks.FeatherCommand;
import ru.fatecore.perks.HomeBonus;
import ru.fatecore.perks.PerkListener;
import ru.fatecore.perks.TierRules;
import ru.fatecore.portal.PortalListener;
import ru.fatecore.portal.PortalManager;
import ru.fatecore.quest.*;
import ru.fatecore.rotation.RotationManager;
import ru.fatecore.stats.StatsCommand;
import ru.fatecore.stats.StatsListener;
import ru.fatecore.stats.StatsService;
import ru.fatecore.trade.TradeCommand;
import ru.fatecore.trade.TradeGui;
import ru.fatecore.util.Modes;
import ru.fatecore.util.StartupCheck;
import ru.fatecore.util.SurvivalVoidListener;
import ru.fatecore.util.VoidListener;
import ru.fatecore.util.YamlStore;
import ru.fatecore.world.MobSpawnListener;
import ru.fatecore.world.WorldChangeListener;

import java.util.ArrayList;
import java.util.List;

public final class FateCore extends JavaPlugin {
    private final List<YamlStore> stores = new ArrayList<>();
    private PortalManager portals;
    private QuestNpc npc;
    private FatePlaceholders placeholders;
    private IDataStore dataStore;
    private TradeGui tradeGui;
    private PersonalChestGui personalChest;
    private FeatherCommand feather;
    private EarnService earn;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Modes.load(getConfig());

        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            getLogger().severe("Vault-экономика не найдена (нужен EssentialsX). Плагин выключен.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        PluginManager pm = getServer().getPluginManager();

        EchoManager echoManager = new EchoManager(this, rsp.getProvider());
        EchoNotifier echoNotifier = new EchoNotifier();
        pm.registerEvents(echoNotifier, this);

        IEchoService echoService = new EchoServiceAdapter(echoManager, echoNotifier);
        dataStore = new PlayerDataStore(this);

        CombatManager combat = new CombatManager();
        combat.start(this);

        RotationManager rotation = new RotationManager(dataStore);
        earn = new EarnService(this, echoManager, rotation, dataStore);
        ClassManager classes = new ClassManager(this, dataStore);
        QuestManager quests = new QuestManager(this, echoManager, dataStore);
        quests.setClasses(classes);
        npc = new QuestNpc(this);
        QuestGui questGui = new QuestGui(quests);
        BoostsManager boosts = new BoostsManager(this, echoManager, dataStore, quests);
        ShopGui shop = new ShopGui(this, echoManager, dataStore, boosts);
        shop.setClasses(classes);
        OnboardingListener onboarding = new OnboardingListener(this);
        HelpCommand help = new HelpCommand(this);
        portals = new PortalManager(this);
        BountyManager bounties = new BountyManager(this);
        DailyService daily = new DailyService(this, dataStore, echoService);

        pm.registerEvents(rotation, this);

        pm.registerEvents(new GuiListener(classes, shop), this);
        pm.registerEvents(new ClassListener(this, classes), this);
        ClassBonusListener classBonus = new ClassBonusListener(this, classes);
        pm.registerEvents(classBonus, this);
        classes.setOnChange(classBonus::syncHealth);
        pm.registerEvents(new EarnListener(earn, echoManager), this);
        pm.registerEvents(onboarding, this);
        pm.registerEvents(new QuestListener(quests, npc, questGui), this);
        pm.registerEvents(new BlockBreakListener(quests), this);
        pm.registerEvents(new QuestActivityListener(quests), this);
        pm.registerEvents(new QuestExploreListener(quests), this);
        pm.registerEvents(new PlayerDeathListener(quests), this);
        pm.registerEvents(new PortalListener(), this);
        pm.registerEvents(portals, this);
        pm.registerEvents(new PerkListener(this), this);
        pm.registerEvents(new TierRules(this), this);
        pm.registerEvents(help, this);
        pm.registerEvents(new VoidListener(this), this);
        SurvivalVoidListener survivalVoid = new SurvivalVoidListener(this);
        pm.registerEvents(survivalVoid, this);
        survivalVoid.applyToLoadedChunks();
        pm.registerEvents(new CombatListener(combat), this);
        pm.registerEvents(new ChatAntiSpam(), this);
        pm.registerEvents(new JoinLeaveListener(), this);
        TitleCommand titleCommand = new TitleCommand(this, dataStore);
        pm.registerEvents(new ChatListener(titleCommand), this);
        AntiBotListener antiBot = new AntiBotListener(this);
        pm.registerEvents(antiBot, this);
        pm.registerEvents(new CaseOpeningListener(this, echoManager), this);
        personalChest = new PersonalChestGui(this);
        pm.registerEvents(personalChest, this);
        AutoPickup autoPickup = new AutoPickup(this, dataStore);
        pm.registerEvents(autoPickup, this);
        feather = new FeatherCommand(this);
        pm.registerEvents(feather, this);
        AuctionSlots auctionSlots = new AuctionSlots(this);
        pm.registerEvents(auctionSlots, this);
        auctionSlots.start();
        pm.registerEvents(new WorldChangeListener(), this);
        pm.registerEvents(new MobSpawnListener(this), this);
        pm.registerEvents(new TpaBypassListener(this, combat), this);

        MenuItems menuItems = new MenuItems(this);
        DonateGui donateGui = new DonateGui(this);
        HelpGui helpGui = new HelpGui(this, donateGui, onboarding);
        TeleportGui teleportGui = new TeleportGui(this, combat);
        MainMenuGui mainMenuGui = new MainMenuGui(this, classes, helpGui, donateGui, teleportGui, shop);
        helpGui.setBack(mainMenuGui::open);
        teleportGui.setBack(mainMenuGui::open);
        classes.setBack(mainMenuGui::open);
        PlayerItemListener itemListener = new PlayerItemListener(this, menuItems, classes, helpGui, donateGui, mainMenuGui, combat);

        pm.registerEvents(itemListener, this);
        pm.registerEvents(new CreativeProtection(this, itemListener::giveMissingLater), this);
        tradeGui = new TradeGui(this, echoManager, menuItems, combat);
        pm.registerEvents(tradeGui, this);
        StatsService stats = new StatsService(dataStore);
        StatsCommand statsCommand = new StatsCommand(stats, dataStore);
        pm.registerEvents(new StatsListener(stats), this);
        pm.registerEvents(statsCommand, this);
        pm.registerEvents(helpGui, this);
        pm.registerEvents(donateGui, this);
        pm.registerEvents(mainMenuGui, this);
        pm.registerEvents(teleportGui, this);
        pm.registerEvents(new MinigameJoinListener(this), this);

        boolean authMe = pm.isPluginEnabled("AuthMe");
        AchievementListener achievements = new AchievementListener(this, echoManager, dataStore);
        if (!authMe) pm.registerEvents(achievements, this);
        shop.setPurchaseHook(achievements::onFirstPurchase);
        quests.setCompletionHook(achievements::onFirstQuest);
        DailyListener dailyListener = new DailyListener(this, daily, !authMe);
        BountyListener bountyListener = new BountyListener(this, bounties, echoService, !authMe);
        pm.registerEvents(dailyListener, this);
        pm.registerEvents(bountyListener, this);

        if (authMe) {
            pm.registerEvents(new AuthMeLoginBridge(this, p -> {
                dailyListener.notifyIfAvailable(p);
                bountyListener.notifyBounty(p);
                itemListener.giveMissingLater(p);
                achievements.onFirstJoin(p);
            }), this);
        }

        getCommand("notrobot").setExecutor(antiBot);
        getCommand("auto").setExecutor(autoPickup);
        getCommand("feather").setExecutor(feather);
        getCommand("durability").setExecutor(new DurabilityCommand());
        getCommand("echo").setExecutor(new EchoCommand(echoManager, rotation, earn));
        getCommand("help").setExecutor(help);
        getCommand("shop").setExecutor(new ShopCommand(shop));
        getCommand("quests").setExecutor(new QuestCommand(questGui));
        getCommand("donate").setExecutor(new DonateCommand(this));
        getCommand("rules").setExecutor(new RulesCommand(this));
        getCommand("fatecore").setExecutor(new FateCommand(this, classes, npc, quests, earn, echoManager, stats, dataStore, () -> {
            Modes.load(getConfig());
            portals.reload();
        }));
        getCommand("menu").setExecutor(new MenuCommand(itemListener));
        getCommand("lobby").setExecutor(new LobbyCommand(this, combat));
        getCommand("daily").setExecutor(new DailyCommand(daily));
        getCommand("playtime").setExecutor(new PlaytimeCommand(this, dataStore));
        getCommand("trade").setExecutor(new TradeCommand(tradeGui));
        getCommand("stats").setExecutor(statsCommand);
        getCommand("title").setExecutor(titleCommand);
        getCommand("bounty").setExecutor(new BountyCommand(this, echoService, bounties, dataStore));

        new AfkManager(this, echoService, dataStore).start();

        npc.spawnWhenReady();
        onboarding.placeSigns();
        new TipsTask(this).start();
        new DailyResetTask(this, quests).start();

        java.util.function.Predicate<Player> eligible = authMe
                ? ru.fatecore.util.Auth::isAuthed
                : p -> true;
        getServer().getScheduler().runTaskTimer(this, new PlaytimeTask(this, dataStore, echoManager, earn, eligible), 1200L, 1200L);

        new BukkitRunnable() {
            @Override public void run() { quests.checkPrefixExpiryOnline(); }
        }.runTaskTimer(this, 1200L, 1200L);

        new BukkitRunnable() {
            @Override public void run() { flushAll(); }
        }.runTaskTimer(this, 1200L, 1200L);

        if (pm.getPlugin("PlaceholderAPI") != null) {
            placeholders = new FatePlaceholders(this, quests, echoManager, classes, rotation, new HomeBonus(this), dataStore, daily, bounties, combat);
            placeholders.register();
        }
        StartupCheck.run(this);
        getLogger().info("FateCore включён.");
    }

    @Override
    public void onDisable() {
        getServer().getScheduler().cancelTasks(this);
        if (tradeGui != null) tradeGui.closeAll();
        if (personalChest != null) personalChest.saveAll();
        if (feather != null) feather.shutdown();
        if (earn != null) earn.shutdown();
        if (npc != null) npc.removeAll();
        HandlerList.unregisterAll(this);
        if (placeholders != null) {
            placeholders.unregister();
            placeholders = null;
        }
        // при выключении — синхронно, планировщик уже недоступен; flushNow дописывает и недозаписанные async-снимки
        if (dataStore != null) dataStore.save();
        for (YamlStore s : stores) s.flushNow();
    }

    /** Автосохранение: снимок на главном потоке, запись файлов — асинхронно (YamlStore.flush). */
    private void flushAll() {
        for (YamlStore s : stores) s.flush();
    }

    public List<YamlStore> stores() {
        return stores;
    }

    public NamespacedKey key(String name) {
        return new NamespacedKey(this, name);
    }
}
