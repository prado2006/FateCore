package ru.fatecore.util;

import org.bukkit.configuration.file.FileConfiguration;
import ru.fatecore.FateCore;
import ru.fatecore.classes.ClassManager.FateClass;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Проверка при старте: 9 привилегий и 5 классов должны быть полностью описаны в конфиге/коде; проблемы — в консоль. */
public final class StartupCheck {
    private StartupCheck() {}

    public static final List<String> TIERS = List.of(
            "wanderer", "premium", "favorite", "chosen", "master", "legend", "hero", "overlord", "absolute");
    private static final List<String> SECTIONS = List.of(
            "donate.tiers", "donate-multipliers", "home-limits", "tax-discounts", "sethome-tiers", "auction.slots");
    private static final List<String> COMMANDS = List.of(
            "notrobot", "echo", "help", "shop", "quests", "donate", "fatecore", "menu", "auto", "feather", "durability");

    public static void run(FateCore plugin) {
        FileConfiguration cfg = plugin.getConfig();
        int problems = 0;
        int okTiers = 0;
        for (String id : TIERS) {
            boolean ok = true;
            for (String sec : SECTIONS) {
                String path = sec + "." + id;
                if (!cfg.contains(path)) {
                    plugin.getLogger().warning("config.yml: нет " + path + " (привилегия '" + id + "')");
                    ok = false;
                    problems++;
                }
            }
            if (cfg.getStringList("donate.tiers." + id + ".perks").isEmpty()) {
                plugin.getLogger().warning("config.yml: пустое описание donate.tiers." + id + ".perks");
                ok = false;
                problems++;
            }
            if (ok) okTiers++;
        }
        int okClasses = 0;
        Set<Integer> slots = new HashSet<>();
        Set<String> ids = new HashSet<>();
        for (FateClass c : FateClass.values()) {
            boolean ok = c.perks.length > 0 && c.slot >= 0 && c.slot < 27 && slots.add(c.slot) && ids.add(c.id);
            if (ok) okClasses++;
            else {
                plugin.getLogger().warning("Класс " + c.id + " описан неверно (слот/бонусы/дубликат id).");
                problems++;
            }
        }
        for (String cmd : COMMANDS) {
            if (plugin.getCommand(cmd) == null || plugin.getCommand(cmd).getExecutor() == plugin) {
                plugin.getLogger().warning("Команда /" + cmd + " не зарегистрирована в plugin.yml/onEnable.");
                problems++;
            }
        }
        plugin.getLogger().info("Проверка запуска: привилегий " + okTiers + "/" + TIERS.size()
                + ", классов " + okClasses + "/" + FateClass.values().length
                + (problems == 0 ? " — всё в порядке." : " — проблем: " + problems + " (см. предупреждения выше)."));
    }
}
