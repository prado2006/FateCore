package ru.fatecore.perks;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import ru.fatecore.util.Msg;

/** /durability — процент оставшейся прочности предмета в руке с цветовой индикацией. */
public final class DurabilityCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Msg.send(sender, "&cКоманда только для игроков.");
            return true;
        }
        ItemStack it = p.getInventory().getItemInMainHand();
        if (it.getType() == Material.AIR || it.getType().getMaxDurability() <= 0) {
            Msg.send(p, "&cВ руке нет предмета с прочностью.");
            return true;
        }
        if (it.getItemMeta() != null && it.getItemMeta().isUnbreakable()) {
            Msg.send(p, "&bПредмет неразрушимый.");
            return true;
        }
        int max = it.getType().getMaxDurability();
        int damage = it.getItemMeta() instanceof Damageable d ? d.getDamage() : 0;
        int left = Math.max(0, max - damage);
        int percent = (int) Math.round(left * 100.0 / max);
        String color = percent > 60 ? "&a" : percent > 30 ? "&e" : percent > 10 ? "&6" : "&c";
        int filled = Math.max(0, Math.min(20, (int) Math.round(percent / 5.0)));
        String bar = color + "|".repeat(filled) + "&8" + "|".repeat(20 - filled);
        Msg.send(p, "&7Прочность: " + color + percent + "% &7(" + left + "/" + max + ") " + bar);
        return true;
    }
}
