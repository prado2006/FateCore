package ru.fatecore.perks;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.permissions.PermissionAttachment;
import ru.fatecore.FateCore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Слоты аукциона по группе LuckPerms. Если установлен аукционный плагин (auction.plugins в config.yml),
 * игроку выдаётся временное право по шаблону auction.permission-template (например zauctionhouse.max.15),
 * где число берётся из таблицы auction.slots по лучшей группе игрока. Работает без LuckPerms-команд;
 * пересчитывается при входе и раз в auction.refresh-seconds (покупка привилегии подхватывается сама).
 * Право должно быть объявлено в конфиге аукциона (у zAuctionHouse — permissions.auction).
 */
public final class AuctionSlots implements Listener {
    private final FateCore plugin;
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();
    private final Map<UUID, Integer> applied = new HashMap<>();
    private boolean warned;

    public AuctionSlots(FateCore plugin) {
        this.plugin = plugin;
    }

    public void start() {
        long period = Math.max(10, plugin.getConfig().getLong("auction.refresh-seconds", 30)) * 20L;
        Bukkit.getScheduler().runTaskTimer(plugin, this::refreshAll, 100L, period);
    }

    private boolean auctionInstalled() {
        List<String> names = plugin.getConfig().getStringList("auction.plugins");
        for (String n : names) {
            if (Bukkit.getPluginManager().isPluginEnabled(n)) return true;
        }
        return false;
    }

    /** Сколько слотов положено игроку по его группам. */
    public int slotsFor(Player p) {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("auction.slots");
        int def = plugin.getConfig().getInt("auction.slots.default", 5);
        Set<String> groups = Tiers.groups(p);
        return Tiers.max(groups, sec, def);
    }

    private void refreshAll() {
        if (!plugin.getConfig().getBoolean("auction.enabled", true)) return;
        if (!auctionInstalled()) {
            if (!warned) {
                plugin.getLogger().info("Аукцион не найден (auction.plugins) — слоты аукциона не выдаются.");
                warned = true;
            }
            return;
        }
        for (Player p : Bukkit.getOnlinePlayers()) apply(p);
    }

    private void apply(Player p) {
        int slots = slotsFor(p);
        Integer cur = applied.get(p.getUniqueId());
        if (cur != null && cur == slots) return;
        remove(p);
        String node = plugin.getConfig().getString("auction.permission-template", "zauctionhouse.max.%d").formatted(slots);
        attachments.put(p.getUniqueId(), p.addAttachment(plugin, node, true));
        applied.put(p.getUniqueId(), slots);
    }

    private void remove(Player p) {
        PermissionAttachment old = attachments.remove(p.getUniqueId());
        if (old != null) p.removeAttachment(old);
        applied.remove(p.getUniqueId());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        // группы LuckPerms загружаются чуть позже входа
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && plugin.getConfig().getBoolean("auction.enabled", true) && auctionInstalled()) apply(p);
        }, 40L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        remove(e.getPlayer());
    }
}
