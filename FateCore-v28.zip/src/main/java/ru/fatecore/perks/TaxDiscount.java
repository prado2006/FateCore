package ru.fatecore.perks;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.query.QueryOptions;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Скидка на налог /trade (5 Эхо) и комиссию /bounty (10%) по группе LuckPerms.
 * Проценты скидки — config.yml → tax-discounts (wanderer 10 … legend 50, overlord 60, absolute 60).
 * Берётся лучшая скидка из всех групп игрока. Группы только читаются, не изменяются.
 */
public final class TaxDiscount {
    private TaxDiscount() {}

    /** Скидка игрока в процентах (0-100). */
    public static double percent(Plugin plugin, Player p) {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("tax-discounts");
        if (sec == null) return 0;
        try {
            LuckPerms lp = LuckPermsProvider.get();
            User user = lp.getUserManager().getUser(p.getUniqueId());
            if (user == null) return 0;
            Set<String> groups = user.getInheritedGroups(QueryOptions.nonContextual()).stream()
                    .map(Group::getName).map(String::toLowerCase).collect(Collectors.toSet());
            double best = 0;
            for (String key : sec.getKeys(false)) {
                if (groups.contains(key.toLowerCase(Locale.ROOT))) best = Math.max(best, sec.getDouble(key, 0));
            }
            return Math.min(100, Math.max(0, best));
        } catch (IllegalStateException e) {
            return 0;
        }
    }

    /** base со скидкой: apply(5, 10) = 4.5. */
    public static double apply(double base, double discountPercent) {
        return base * (1.0 - discountPercent / 100.0);
    }

    /** Число без лишних нулей, до 2 знаков: 4.5, 4.25, 5. */
    public static String fmt(double v) {
        String s = String.format(Locale.US, "%.2f", v);
        if (s.contains(".")) s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s;
    }
}
