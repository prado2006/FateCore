package ru.fatecore.perks;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import ru.fatecore.util.Cmd;
import ru.fatecore.util.Msg;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * /feather — парение (джетпак). Включил режим, подпрыгнул и ДВАЖДЫ нажал пробел в воздухе — плавный подъём
 * (до feather.max-seconds секунд), затем мягкое падение. Shift останавливает подъём. Повторный запуск — после приземления.
 * Не конфликтует с /fly Essentials: при вводе /fly режим парения выключается. В perks.restricted-worlds не работает.
 * Примечание: Bukkit 1.20.1 не передаёт «зажатый» пробел, поэтому используется двойное нажатие (как у креатив-полёта).
 */
public final class FeatherCommand implements CommandExecutor, Listener {
    private final Plugin plugin;
    private final Set<UUID> enabled = new HashSet<>();
    /** Игроки, которым allowFlight включили МЫ (чтобы вернуть как было). */
    private final Set<UUID> ownedFlight = new HashSet<>();
    private final Set<UUID> needLand = new HashSet<>();
    private final Map<UUID, BukkitTask> boosting = new HashMap<>();

    public FeatherCommand(Plugin plugin) {
        this.plugin = plugin;
    }

    private static boolean survivalLike(Player p) {
        return p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Msg.send(sender, "&cКоманда только для игроков.");
            return true;
        }
        if (enabled.contains(p.getUniqueId())) {
            disable(p);
            Msg.send(p, "&eПарение выключено.");
            return true;
        }
        if (PerkListener.isRestricted(plugin, p.getWorld())) {
            Msg.send(p, "&cВ этом мире нельзя использовать парение.");
            return true;
        }
        if (!survivalLike(p)) {
            Msg.send(p, "&cПарение работает в режиме выживания/приключения.");
            return true;
        }
        enabled.add(p.getUniqueId());
        if (!p.getAllowFlight()) {
            p.setAllowFlight(true);
            ownedFlight.add(p.getUniqueId());
        }
        Msg.send(p, "&aПарение включено! &7Подпрыгни и дважды нажми пробел в воздухе. Shift — остановить подъём.");
        return true;
    }

    private void disable(Player p) {
        UUID id = p.getUniqueId();
        enabled.remove(id);
        needLand.remove(id);
        BukkitTask t = boosting.remove(id);
        if (t != null) t.cancel();
        if (ownedFlight.remove(id) && survivalLike(p)) {
            p.setFlying(false);
            p.setAllowFlight(false);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (!e.isFlying() || !enabled.contains(id) || !ownedFlight.contains(id) || !survivalLike(p)) return;
        e.setCancelled(true);
        if (needLand.contains(id) || boosting.containsKey(id)) return;
        if (PerkListener.isRestricted(plugin, p.getWorld())) {
            disable(p);
            return;
        }
        startBoost(p);
    }

    private void startBoost(Player p) {
        UUID id = p.getUniqueId();
        int maxTicks = (int) (plugin.getConfig().getDouble("feather.max-seconds", 3.0) * 20);
        double maxUp = plugin.getConfig().getDouble("feather.max-speed", 0.30);
        BukkitTask task = new org.bukkit.scheduler.BukkitRunnable() {
            int ticks;
            @Override public void run() {
                if (!p.isOnline() || !enabled.contains(id) || p.isSneaking() || ticks++ >= maxTicks
                        || PerkListener.isRestricted(plugin, p.getWorld())) {
                    finish();
                    return;
                }
                Vector v = p.getVelocity();
                v.setY(Math.min(maxUp, v.getY() + 0.06));
                p.setVelocity(v);
                p.setFallDistance(0f);
            }
            private void finish() {
                cancel();
                boosting.remove(id);
                needLand.add(id);
                if (p.isOnline()) {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 100, 0, false, false, false));
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
        boosting.put(id, task);
    }

    /** Приземлился — можно взлетать снова. Обработчик дешёвый: срабатывает только для игроков в needLand. */
    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (needLand.isEmpty() || !needLand.contains(e.getPlayer().getUniqueId())) return;
        if (e.getPlayer().isOnGround()) needLand.remove(e.getPlayer().getUniqueId());
    }

    /** /fly Essentials переключает полёт по allowFlight — наш флаг ему мешает, поэтому парение снимаем заранее. */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String cmd = Cmd.base(e.getMessage());
        if (!(cmd.equals("fly") || cmd.equals("efly"))) return;
        Player p = e.getPlayer();
        if (enabled.contains(p.getUniqueId())) {
            disable(p);
            Msg.send(p, "&eПарение выключено (включается /fly).");
        }
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        if (enabled.contains(e.getPlayer().getUniqueId()) && PerkListener.isRestricted(plugin, e.getPlayer().getWorld())) {
            disable(e.getPlayer());
            Msg.send(e.getPlayer(), "&eПарение выключено: в этом мире оно недоступно.");
        }
    }

    @EventHandler
    public void onGameMode(PlayerGameModeChangeEvent e) {
        if (enabled.contains(e.getPlayer().getUniqueId())) {
            Player p = e.getPlayer();
            Bukkit.getScheduler().runTask(plugin, () -> {
                enabled.remove(p.getUniqueId());
                ownedFlight.remove(p.getUniqueId());
                needLand.remove(p.getUniqueId());
                BukkitTask t = boosting.remove(p.getUniqueId());
                if (t != null) t.cancel();
            });
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        disable(e.getPlayer());
    }

    /** Выключение плагина: вернуть allowFlight всем. */
    public void shutdown() {
        for (UUID id : new HashSet<>(enabled)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) disable(p);
        }
    }
}
