package ru.fatecore.perks;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import ru.fatecore.api.IDataStore;
import ru.fatecore.util.Msg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * /auto — переключатель автоподбора: дроп с блоков и убитых мобов сразу падает в инвентарь.
 * Включение хранится в IDataStore (ключ auto_pickup). В мирах perks.restricted-worlds не работает.
 * Предметы, которые не влезли, выпадают как обычно (с предупреждением раз в 5 секунд).
 */
public final class AutoPickup implements CommandExecutor, Listener {
    private static final String KEY = "auto_pickup";

    private final Plugin plugin;
    private final IDataStore data;
    private final Map<UUID, Long> fullWarned = new HashMap<>();

    public AutoPickup(Plugin plugin, IDataStore data) {
        this.plugin = plugin;
        this.data = data;
    }

    private boolean on(Player p) {
        return data.getLong(p.getUniqueId(), KEY, 0) == 1L;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Msg.send(sender, "&cКоманда только для игроков.");
            return true;
        }
        boolean now = !on(p);
        data.setLong(p.getUniqueId(), KEY, now ? 1L : 0L);
        Msg.send(p, now ? "&aАвтоподбор включён: добыча и дроп мобов сразу попадают в инвентарь."
                : "&eАвтоподбор выключен.");
        return true;
    }

    private boolean active(Player p) {
        return p != null && on(p) && !PerkListener.isRestricted(plugin, p.getWorld());
    }

    /** Кладёт в инвентарь всё, что влезает; остаток возвращается в список. true — что-то не влезло. */
    private boolean absorb(Player p, Iterator<ItemStack> it, java.util.List<ItemStack> leftovers) {
        boolean full = false;
        while (it.hasNext()) {
            ItemStack s = it.next();
            Map<Integer, ItemStack> left = p.getInventory().addItem(s.clone());
            it.remove();
            if (!left.isEmpty()) {
                leftovers.addAll(left.values());
                full = true;
            }
        }
        return full;
    }

    private void warnFull(Player p) {
        long now = System.currentTimeMillis();
        Long last = fullWarned.get(p.getUniqueId());
        if (last != null && now - last < 5000) return;
        fullWarned.put(p.getUniqueId(), now);
        Msg.send(p, "&cИнвентарь полон! Часть предметов выпала на землю.");
    }

    // HIGHEST: после бонусов классов (HIGH), которые смотрят на список предметов
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockDrop(BlockDropItemEvent e) {
        Player p = e.getPlayer();
        if (!active(p)) return;
        for (Item item : new java.util.ArrayList<>(e.getItems())) {
            Map<Integer, ItemStack> left = p.getInventory().addItem(item.getItemStack().clone());
            if (left.isEmpty()) {
                e.getItems().remove(item);
            } else {
                item.setItemStack(left.values().iterator().next());
                warnFull(p);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMobDeath(EntityDeathEvent e) {
        if (e.getEntity() instanceof Player) return;
        Player killer = e.getEntity().getKiller();
        if (!active(killer)) return;
        java.util.List<ItemStack> leftovers = new java.util.ArrayList<>();
        boolean full = absorb(killer, e.getDrops().iterator(), leftovers);
        e.getDrops().addAll(leftovers);
        if (full) warnFull(killer);
    }
}
