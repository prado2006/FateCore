package ru.fatecore.util;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

public final class HubTeleport {
    private HubTeleport() {}

    /** Точка главного лобби (onboarding.spawn) или null, если мир не загружен. */
    public static Location location(Plugin plugin) {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("onboarding.spawn");
        World w = Bukkit.getWorld(s != null ? s.getString("world", Modes.mainLobby()) : Modes.mainLobby());
        if (w == null) return null;
        return s == null
                ? w.getSpawnLocation()
                : new Location(w, s.getDouble("x") + 0.5, s.getDouble("y"), s.getDouble("z") + 0.5,
                        (float) s.getDouble("yaw", 0), (float) s.getDouble("pitch", 0));
    }

    public static boolean toHub(Plugin plugin, Player p) {
        Location loc = location(plugin);
        if (loc == null) return false;

        p.setFallDistance(0f);
        p.setVelocity(new Vector(0, 0, 0));
        return p.teleport(loc);
    }
}
