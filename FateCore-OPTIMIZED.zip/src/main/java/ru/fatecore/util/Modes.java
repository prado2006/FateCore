package ru.fatecore.util;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import java.util.List;

/**
 * Режимы и имена миров. Имена берутся из config.yml (секция worlds) и перечитываются при /fatecore reload.
 * <pre>
 * main-lobby    — главный лобби (хаб сервера)
 * survival      — мир выживания
 * bedwars-lobby — лобби BedWars (NPC входа в игру)
 * skywars-lobby — лобби SkyWars
 * bedwars-arena / skywars-arena — миры арен (выгружаются, когда пусты)
 * </pre>
 */
public final class Modes {
    public static final String SURVIVAL = "survival";
    public static final String BEDWARS = "bedwars";
    public static final String SKYWARS = "skywars";

    public static final List<String> MODES = List.of(SURVIVAL, BEDWARS, SKYWARS);

    private static volatile String mainLobby = "main_lobby";
    private static volatile String survivalWorld = "hub";
    private static volatile String bedwarsLobby = "bedwars_lobby";
    private static volatile String skywarsLobby = "skywars_lobby";
    private static volatile String bedwarsArena = "world_bedwars";
    private static volatile String skywarsArena = "world_skywars";

    private Modes() {}

    /** Читает секцию worlds из конфига (отсутствующие ключи — значения по умолчанию). */
    public static void load(ConfigurationSection cfg) {
        ConfigurationSection w = cfg == null ? null : cfg.getConfigurationSection("worlds");
        mainLobby = name(w, "main-lobby", "main_lobby");
        survivalWorld = name(w, "survival", "hub");
        bedwarsLobby = name(w, "bedwars-lobby", "bedwars_lobby");
        skywarsLobby = name(w, "skywars-lobby", "skywars_lobby");
        bedwarsArena = name(w, "bedwars-arena", "world_bedwars");
        skywarsArena = name(w, "skywars-arena", "world_skywars");
    }

    private static String name(ConfigurationSection s, String key, String def) {
        if (s == null) return def;
        String v = s.getString(key, def);
        return v == null || v.isBlank() ? def : v.trim();
    }

    public static String mainLobby() { return mainLobby; }
    public static String survivalWorld() { return survivalWorld; }
    public static String bedwarsLobby() { return bedwarsLobby; }
    public static String skywarsLobby() { return skywarsLobby; }
    public static String bedwarsArena() { return bedwarsArena; }
    public static String skywarsArena() { return skywarsArena; }

    /** Код режима ("survival"/"bedwars"/"skywars") по миру игры (не лобби) или null. */
    public static String of(World w) {
        if (w == null) return null;
        String n = w.getName();
        if (n.equals(survivalWorld)) return SURVIVAL;
        if (n.equals(bedwarsArena)) return BEDWARS;
        if (n.equals(skywarsArena)) return SKYWARS;
        return null;
    }

    public static boolean isArena(World w) {
        String m = of(w);
        return BEDWARS.equals(m) || SKYWARS.equals(m);
    }

    /** Любой мир мини-игр: лобби и арены BedWars/SkyWars. */
    public static boolean isMinigameWorld(World w) {
        if (w == null) return false;
        String n = w.getName();
        return n.equals(bedwarsLobby) || n.equals(skywarsLobby)
                || n.equals(bedwarsArena) || n.equals(skywarsArena);
    }

    /** Число игроков в перечисленных мирах (незагруженные миры считаются как 0). */
    public static int players(String... worlds) {
        int total = 0;
        for (String name : worlds) {
            World w = Bukkit.getWorld(name);
            if (w != null) total += w.getPlayers().size();
        }
        return total;
    }

    /** Название режима для игрока. */
    public static String display(String mode) {
        if (mode == null) return "";
        return switch (mode.toLowerCase()) {
            case SURVIVAL -> "Survival";
            case BEDWARS -> "BedWars";
            case SKYWARS -> "SkyWars";
            default -> mode;
        };
    }
}
