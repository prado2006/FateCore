package ru.fatecore.util;

import org.bukkit.configuration.file.YamlConfiguration;
import ru.fatecore.FateCore;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.function.Supplier;

/**
 * YAML-хранилище с отложенной АСИНХРОННОЙ записью.
 * <ul>
 *   <li>{@link #flush()} — вызывается планировщиком: снимок данных делается на главном потоке (быстро, потокобезопасно),
 *       а запись на диск идёт в {@code runTaskAsynchronously} — главный поток диском не блокируется;</li>
 *   <li>{@link #flushNow()} — синхронная запись (onDisable), дожидается/дописывает всё, что ещё не успело уйти на диск;</li>
 *   <li>файл пишется через временный файл + атомарное переименование — при сбое файл не остаётся полузаписанным.</li>
 * </ul>
 */
public final class YamlStore {
    private final FateCore plugin;
    private final File file;
    private final YamlConfiguration cfg;

    private final Object writeLock = new Object();
    private volatile boolean dirty;
    /** Номер последнего снимка (под synchronized(this)). */
    private long submitted;
    /** Номер последнего записанного на диск снимка (меняется под writeLock). */
    private volatile long written;
    /** Если задан — содержимое файла формируется им (в потоке записи), а не из cfg. */
    private volatile Supplier<String> serializer;

    public YamlStore(FateCore plugin, String name) {
        this.plugin = plugin;
        File dir = plugin.getDataFolder();
        dir.mkdirs();
        this.file = new File(dir, name);
        if (!file.exists()) {
            if (plugin.getResource(name) != null) {
                plugin.saveResource(name, false);
            } else {
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    plugin.getLogger().warning("Не удалось создать " + name + ": " + e.getMessage());
                }
            }
        }
        this.cfg = YamlConfiguration.loadConfiguration(file);
        plugin.stores().add(this);
    }

    public YamlConfiguration cfg() {
        return cfg;
    }

    public void dirty() {
        dirty = true;
    }

    /**
     * Хранилище само отвечает за сериализацию (данные живут не в cfg). Supplier вызывается в потоке записи,
     * поэтому должен читать только потокобезопасные структуры.
     */
    public void useSerializer(Supplier<String> serializer) {
        this.serializer = serializer;
    }

    /** Асинхронное сохранение (если есть что сохранять). */
    public void flush() {
        if (!dirty) return;
        if (!plugin.isEnabled()) { // планировщик уже недоступен
            flushNow();
            return;
        }
        final long seq;
        final String data;
        synchronized (this) {
            if (!dirty) return;
            dirty = false;
            seq = ++submitted;
            data = serializer == null ? cfg.saveToString() : null;
        }
        try {
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> write(seq, data));
        } catch (RuntimeException e) { // плагин выключается — пишем прямо здесь
            write(seq, data);
        }
    }

    /** Синхронное сохранение: onDisable и аварийные случаи. */
    public void flushNow() {
        final long seq;
        final String data;
        synchronized (this) {
            // не dirty, но асинхронная запись ещё не завершена (или была отменена при выключении) — пишем заново
            if (!dirty && submitted <= written) return;
            dirty = false;
            seq = ++submitted;
            data = serializer == null ? cfg.saveToString() : null;
        }
        write(seq, data);
    }

    private void write(long seq, String data) {
        synchronized (writeLock) {
            if (seq <= written) return; // более новый снимок уже на диске
            try {
                Supplier<String> s = serializer;
                String content = data != null ? data : s.get();
                Path target = file.toPath();
                Path tmp = target.resolveSibling(file.getName() + ".tmp");
                Files.writeString(tmp, content, StandardCharsets.UTF_8);
                try {
                    Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (AtomicMoveNotSupportedException e) {
                    Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
                }
                written = seq;
            } catch (IOException | RuntimeException e) {
                dirty = true; // повторим при следующем flush
                plugin.getLogger().warning("Не удалось сохранить " + file.getName() + ": " + e.getMessage());
            }
        }
    }
}
