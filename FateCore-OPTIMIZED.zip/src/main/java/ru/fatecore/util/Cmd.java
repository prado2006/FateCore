package ru.fatecore.util;

import java.util.Arrays;

/** Разбор строки команды из PlayerCommandPreprocessEvent. */
public final class Cmd {
    private Cmd() {}

    /** Имя команды в нижнем регистре без слэша и без префикса "plugin:". Пусто, если команды нет. */
    public static String base(String message) {
        String m = message.trim();
        if (m.startsWith("/")) m = m.substring(1);
        if (m.isEmpty()) return "";
        // первое слово без регулярного выражения (пробельные символы как у \\s: пробел, \t, \n, \x0B, \f, \r)
        int end = 0;
        while (end < m.length() && " \t\n\u000B\f\r".indexOf(m.charAt(end)) < 0) end++;
        String first = m.substring(0, end).toLowerCase();
        int colon = first.lastIndexOf(':');
        return colon >= 0 ? first.substring(colon + 1) : first;
    }

    /** Аргументы после имени команды. */
    public static String[] args(String message) {
        String m = message.trim();
        if (m.startsWith("/")) m = m.substring(1);
        String[] parts = m.split("\\s+");
        return parts.length <= 1 ? new String[0] : Arrays.copyOfRange(parts, 1, parts.length);
    }
}
