package ru.fatecore.util;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.plugin.Plugin;

import java.io.File;

/** Загрузка миров «по требованию» (арены выгружаются, когда пусты — см. TeleportGui). */
public final class Worlds {
    private Worlds() {}

    /**
     * Возвращает загруженный мир или загружает его с диска (если папка мира с level.dat существует).
     * Генератор (VoidGen и т.п.) берётся из bukkit.yml / настроек Multiverse. null — мира нет.
     */
    public static World getOrLoad(Plugin plugin, String name) {
        World w = Bukkit.getWorld(name);
        if (w != null) return w;
        File level = new File(new File(Bukkit.getWorldContainer(), name), "level.dat");
        if (!level.exists()) return null;
        plugin.getLogger().info("Загружаю мир " + name + " обратно в память...");
        try {
            return Bukkit.createWorld(new WorldCreator(name));
        } catch (Exception e) {
            plugin.getLogger().warning("Не удалось загрузить мир " + name + ": " + e.getMessage());
            return null;
        }
    }
}
