package ru.fatecore.util;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.plugin.Plugin;

/**
 * Выживание в VoidGen-мире (survival-мир из worlds.survival, по умолчанию hub).
 * <ul>
 *   <li>Смерть в пустоте НЕ отменяется (как на обычном сервере) — слушаем только возрождение.</li>
 *   <li>Защита от петли смерти: если игрок возрождается в мире Выживания ниже survival.respawn-min-y
 *       или «в воздухе» (под ногами нет опоры), он переносится в главное лобби.</li>
 *   <li>survival.bedrock-floor: слой бедрока на высоте survival.bedrock-floor-y (по умолчанию -64)
 *       создаётся в каждом загружаемом чанке мира (и во всех уже загруженных при старте).</li>
 * </ul>
 */
public final class SurvivalVoidListener implements Listener {
    /** Сколько блоков под ногами проверяем на наличие опоры. */
    private static final int SUPPORT_DEPTH = 4;

    private final Plugin plugin;

    public SurvivalVoidListener(Plugin plugin) {
        this.plugin = plugin;
    }

    // ---------- возрождение ----------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent e) {
        Location spawn = e.getRespawnLocation();
        World w = spawn.getWorld();
        if (w == null || !w.getName().equals(Modes.survivalWorld())) return;
        if (!isUnsafe(spawn, w)) return;

        Location lobby = HubTeleport.location(plugin);
        if (lobby == null) {
            plugin.getLogger().warning("Спавн Выживания небезопасен, но главное лобби (" + Modes.mainLobby()
                    + ") не загружено — игрок возрождён как обычно.");
            return;
        }
        e.setRespawnLocation(lobby);
        org.bukkit.entity.Player p = e.getPlayer();
        // сообщение — на следующем тике, когда клиент уже закончил возрождение
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) p.sendMessage("§cСпавн Выживания не настроен. Вы перемещены в главное лобби.");
        });
    }

    private boolean isUnsafe(Location l, World w) {
        if (l.getY() < plugin.getConfig().getDouble("survival.respawn-min-y", -10)) return true;
        int x = l.getBlockX();
        int y = l.getBlockY();
        int z = l.getBlockZ();
        for (int i = 1; i <= SUPPORT_DEPTH; i++) {
            Material m = w.getBlockAt(x, y - i, z).getType();
            if (m.isSolid() || m == Material.WATER) return false;
        }
        return true; // висит в пустоте
    }

    // ---------- слой бедрока ----------

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        World w = e.getWorld();
        if (w.getName().equals(Modes.survivalWorld())) fillFloor(e.getChunk(), w);
    }

    /** При старте плагина: чанки, уже загруженные в мире Выживания. */
    public void applyToLoadedChunks() {
        World w = plugin.getServer().getWorld(Modes.survivalWorld());
        if (w == null) return;
        for (Chunk c : w.getLoadedChunks()) fillFloor(c, w);
    }

    private void fillFloor(Chunk chunk, World w) {
        if (!plugin.getConfig().getBoolean("survival.bedrock-floor", false)) return;
        int y = plugin.getConfig().getInt("survival.bedrock-floor-y", -64);
        if (y < w.getMinHeight() || y >= w.getMaxHeight()) return;
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                Block b = chunk.getBlock(x, y, z);
                if (b.getType().isAir()) b.setType(Material.BEDROCK, false); // существующие блоки не трогаем
            }
        }
    }
}
