package ru.fatecore.perks;

import com.earth2me.essentials.IEssentials;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import ru.fatecore.FateCore;
import ru.fatecore.util.Cmd;
import ru.fatecore.util.Msg;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * МОДУЛЬ 9 — донат-перки и киты не работают в запрещённых мирах (perks.restricted-worlds) и в бою.
 * Перки работают в main_lobby и hub; в лобби/аренах BedWars и SkyWars отключены полностью.
 * Чат, префиксы, ники и TAB этот класс НЕ трогает — их ведут LuckPerms, TAB и EssentialsXChat.
 * Сами команды выполняет EssentialsX; здесь только блокировка (дублирует blocked-cmds WorldGuard).
 */
public final class PerkListener implements Listener {
    /** Миры по умолчанию, если perks.restricted-worlds не задан в config.yml. */
    private static final java.util.List<String> DEFAULT_RESTRICTED =
            java.util.List.of("bedwars_lobby", "skywars_lobby", "world_bedwars", "world_skywars");

    /** Кэш списка запрещённых миров (в нижнем регистре); пересобирается, когда reloadConfig() подменяет конфигурацию. */
    private static volatile FileConfiguration cachedConfig;
    private static volatile Set<String> cachedRestricted = Set.of();

    private static Set<String> restrictedWorlds(org.bukkit.plugin.Plugin plugin) {
        FileConfiguration cfg = plugin.getConfig();
        if (cfg != cachedConfig) {
            java.util.List<String> list = cfg.isList("perks.restricted-worlds")
                    ? cfg.getStringList("perks.restricted-worlds") : DEFAULT_RESTRICTED;
            Set<String> set = new HashSet<>();
            for (String name : list) set.add(name.toLowerCase(Locale.ROOT));
            cachedRestricted = set;
            cachedConfig = cfg;
        }
        return cachedRestricted;
    }

    /** Перки запрещены в мире из списка perks.restricted-worlds (config.yml, без перекомпиляции). */
    public static boolean isRestricted(org.bukkit.plugin.Plugin plugin, org.bukkit.World w) {
        if (w == null) return false;
        return restrictedWorlds(plugin).contains(w.getName().toLowerCase(Locale.ROOT));
    }

    /** Команды-перки, блокируемые в запрещённых мирах. */
    private static final Set<String> ARENA_BLOCKED = Set.of(
            "fly", "efly", "god", "egod", "tgod",
            "speed", "espeed", "flyspeed", "eflyspeed", "walkspeed", "ewalkspeed",
            "feed", "efeed", "eat", "eeat",
            "heal", "eheal",
            "repair", "erepair", "fix", "efix",
            "back", "eback", "return", "ereturn",
            "kit", "ekit", "kits", "ekits",
            "tpa", "etpa", "call", "ecall", "tpask", "etpask",
            "tpahere", "etpahere");

    /** Блок при PvP (урон за последние N секунд) в любом мире. */
    private static final Set<String> COMBAT_BLOCKED = Set.of(
            "fly", "efly", "god", "egod", "tgod",
            "speed", "espeed", "flyspeed", "eflyspeed", "walkspeed", "ewalkspeed",
            "kit", "ekit",
            "tpa", "etpa", "call", "ecall", "tpask", "etpask",
            "tpahere", "etpahere");

    private final FateCore plugin;
    private final Map<UUID, Long> lastCombat = new HashMap<>();

    public PerkListener(FateCore plugin) {
        this.plugin = plugin;
    }

    private boolean inCombat(Player p) {
        Long t = lastCombat.get(p.getUniqueId());
        long window = plugin.getConfig().getLong("perks.combat-seconds", 10) * 1000L;
        return t != null && System.currentTimeMillis() - t < window;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String cmd = Cmd.base(e.getMessage());
        if (cmd.isEmpty()) return;
        Player p = e.getPlayer();

        if (ARENA_BLOCKED.contains(cmd) && isRestricted(plugin, p.getWorld())) {
            e.setCancelled(true);
            p.sendMessage("§cВ этом мире нельзя использовать перки.");
            stripPerks(p);
            return;
        }
        if (COMBAT_BLOCKED.contains(cmd) && inCombat(p)) {
            e.setCancelled(true);
            Msg.send(p, "&cНедоступно в бою");
        }
    }

    /** Фиксируем PvP и снимаем полёт/god с обоих участников. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = null;
        Entity d = e.getDamager();
        if (d instanceof Player pl) {
            attacker = pl;
        } else if (d instanceof Projectile proj && proj.getShooter() instanceof Player shooter) {
            attacker = shooter;
        }
        if (attacker == null || attacker.equals(victim)) return;
        long now = System.currentTimeMillis();
        lastCombat.put(victim.getUniqueId(), now);
        lastCombat.put(attacker.getUniqueId(), now);
        stripPerks(victim);
        stripPerks(attacker);
    }

    /** Вход в запрещённый мир: сбрасываем полёт, god и скорость. */
    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        if (isRestricted(plugin, e.getPlayer().getWorld())) stripPerks(e.getPlayer());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (p.isOnline() && isRestricted(plugin, p.getWorld())) stripPerks(p);
        });
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        if (!isRestricted(plugin, e.getRespawnLocation().getWorld())) return;
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) stripPerks(p);
        }, 2L);
    }

    /** Не даём включить полёт в запрещённом мире (например, из другого плагина). */
    @EventHandler(ignoreCancelled = true)
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        Player p = e.getPlayer();
        GameMode gm = p.getGameMode();
        if (e.isFlying() && (gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE) && isRestricted(plugin, p.getWorld())) {
            e.setCancelled(true);
            p.setAllowFlight(false);
            p.setFlying(false);
            p.sendMessage("§cВ этом мире нельзя использовать перки.");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        lastCombat.remove(e.getPlayer().getUniqueId());
    }

    /** Выключает полёт, режим бога (god — через IEssentials) и сбрасывает скорость (/speed). */
    private void stripPerks(Player p) {
        GameMode gm = p.getGameMode();
        if (gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE) {
            if (p.getAllowFlight() || p.isFlying()) {
                p.setFlying(false);
                p.setAllowFlight(false);
            }
            if (isRestricted(plugin, p.getWorld())) {
                p.setWalkSpeed(0.2f);
                p.setFlySpeed(0.1f);
            }
        }
        try {
            if (Bukkit.getPluginManager().getPlugin("Essentials") instanceof IEssentials ess) {
                var user = ess.getUser(p);
                if (user != null && user.isGodModeEnabled()) {
                    user.setGodModeEnabled(false);
                }
            }
        } catch (Exception ex) {
            plugin.getLogger().warning("Не удалось снять god: " + ex.getMessage());
        }
    }
}
