package ru.fatecore.menu;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class MenuItems {

    public enum Kind { COMPASS, DONATE }

    private static final LegacyComponentSerializer AMP = LegacyComponentSerializer.legacyAmpersand();

    private final NamespacedKey key;
    /** Шаблоны предметов меню: создаются один раз, выдаётся clone(). */
    private final Map<Kind, ItemStack> templates = new EnumMap<>(Kind.class);

    public MenuItems(Plugin plugin) {
        this.key = new NamespacedKey(plugin, "menu_item");
    }

    /** Строка с кодами & или § -> Component без курсива (для названий и лора). */
    public static Component text(String legacy) {
        return AMP.deserialize(legacy.replace('§', '&')).decoration(TextDecoration.ITALIC, false);
    }

    /** Кнопка GUI: название + лор (лор не задаётся, если список пуст). */
    public static ItemStack button(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        item.editMeta(m -> {
            m.displayName(text(name));
            if (!lore.isEmpty()) m.lore(lore.stream().map(MenuItems::text).toList());
        });
        return item;
    }

    public static ItemStack button(Material mat, String name, String... lore) {
        return button(mat, name, Arrays.asList(lore));
    }

    /** Декоративная панель-заполнитель без названия. */
    public static ItemStack filler(Material pane) {
        return button(pane, "&r", List.of());
    }

    public ItemStack create(Kind kind) {
        ItemStack tpl = templates.get(kind);
        if (tpl == null) {
            tpl = new ItemStack(kind == Kind.COMPASS ? Material.COMPASS : Material.NETHER_STAR);
            tpl.editMeta(meta -> {
                if (kind == Kind.COMPASS) {
                    meta.displayName(text("§6Меню игрока"));
                    meta.lore(List.of(
                            text("§7ПКМ - Главное меню"),
                            text("§7ЛКМ - Помощь и команды")));
                } else {
                    meta.displayName(text("§eПривилегии (Донат)"));
                    meta.lore(List.of(
                            text("§7Узнай о привилегиях и поддержи"),
                            text("§7проект!"),
                            text("§aНажми ПКМ")));
                }
                meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, kind.name());
            });
            templates.put(kind, tpl);
        }
        return tpl.clone();
    }

    public Kind kindOf(ItemStack item) {
        if (item == null) return null;
        // Предметы меню бывают только этих материалов: отсекаем остальные, не клонируя ItemMeta
        // (метод вызывается на каждый клик/взаимодействие на сервере).
        Material type = item.getType();
        if (type != Material.COMPASS && type != Material.NETHER_STAR) return null;
        if (!item.hasItemMeta()) return null;
        String v = item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (v == null) return null;
        try {
            return Kind.valueOf(v);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public boolean isMenuItem(ItemStack item) {
        return kindOf(item) != null;
    }
}
