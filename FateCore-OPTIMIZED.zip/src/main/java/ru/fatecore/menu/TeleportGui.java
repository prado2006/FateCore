package ru.fatecore.menu;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import ru.fatecore.combat.CombatManager;
import ru.fatecore.util.Auth;
import ru.fatecore.util.Modes;
import ru.fatecore.util.Worlds;

import java.util.Arrays;
import java.util.List;

/**
 * Меню телепортации (27 слотов): Выживание, BedWars, SkyWars — мгновенный ТП в соответствующий мир-лобби.
 * После ТП пустые арены (world_bedwars / world_skywars) выгружаются из памяти.
 */
public final class TeleportGui implements Listener {
    private static final int SIZE = 27;
    private static final int SLOT_SURVIVAL = 11;
    private static final int SLOT_BEDWARS = 13;
    private static final int SLOT_SKYWARS = 15;
    private static final int SLOT_CLOSE = 22;
    private static final long UNLOAD_DELAY_TICKS = 40L;

    public static final class Holder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    private final Plugin plugin;
    private final CombatManager combat;

    public TeleportGui(Plugin plugin, CombatManager combat) {
        this.plugin = plugin;
        this.combat = combat;
    }

    private static final Component TITLE = MenuItems.text("&8Телепортация");

    private ItemStack[] base;
    private final ItemStack[] modeButtons = new ItemStack[3];
    private int[] lastCounts;

    public void open(Player p) {
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.inventory = inv;

        ItemStack[] tpl = base;
        if (tpl == null) {
            tpl = new ItemStack[SIZE];
            Arrays.fill(tpl, MenuItems.filler(Material.BLACK_STAINED_GLASS_PANE));
            tpl[SLOT_CLOSE] = MenuItems.button(Material.BARRIER, "&cЗакрыть");
            base = tpl;
        }
        inv.setContents(tpl);

        // кнопки режимов зависят от онлайна — пересобираем, только если числа изменились
        int[] counts = {
                Modes.players(Modes.survivalWorld()),
                Modes.players(Modes.bedwarsLobby(), Modes.bedwarsArena()),
                Modes.players(Modes.skywarsLobby(), Modes.skywarsArena())};
        if (!Arrays.equals(counts, lastCounts)) {
            modeButtons[0] = button(Material.GRASS_BLOCK, "&aВыживание", "&7Строй, добывай и исследуй мир.", counts[0]);
            modeButtons[1] = button(Material.RED_BED, "&cBedWars", "&7PvP за кровати: защити свою и сломай чужие.", counts[1]);
            modeButtons[2] = button(Material.ENDER_EYE, "&bSkyWars", "&7Острова в небе: лут, риск и победа.", counts[2]);
            lastCounts = counts;
        }
        inv.setItem(SLOT_SURVIVAL, modeButtons[0]);
        inv.setItem(SLOT_BEDWARS, modeButtons[1]);
        inv.setItem(SLOT_SKYWARS, modeButtons[2]);

        p.openInventory(inv);
    }

    private static ItemStack button(Material mat, String name, String description, int online) {
        return MenuItems.button(mat, name, description, "", "&7Игроков: &f" + online, "&aНажми, чтобы телепортироваться");
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;

        switch (e.getSlot()) {
            case SLOT_SURVIVAL -> teleport(p, Modes.survivalWorld(), "&aВы телепортированы в Выживание.");
            case SLOT_BEDWARS -> teleport(p, Modes.bedwarsLobby(), "&aВы телепортированы в лобби BedWars.");
            case SLOT_SKYWARS -> teleport(p, Modes.skywarsLobby(), "&aВы телепортированы в лобби SkyWars.");
            case SLOT_CLOSE -> p.closeInventory();
            default -> { }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    private void teleport(Player p, String worldName, String okMessage) {
        p.closeInventory();
        if (!Auth.isAuthed(p)) {
            p.sendMessage(MenuItems.text("&cСначала /login"));
            return;
        }
        if (combat.isTagged(p.getUniqueId())) {
            p.sendMessage(MenuItems.text("&cВы в бою! Телепортация запрещена."));
            return;
        }
        World w = Worlds.getOrLoad(plugin, worldName);
        if (w == null) {
            p.sendMessage(MenuItems.text("&cМир сейчас недоступен. Попробуйте позже."));
            return;
        }
        Location spawn = w.getSpawnLocation().add(0.5, 0, 0.5);
        p.setFallDistance(0f);
        // Если ТП отменён (нет /login или права портала) — PortalListener уже сообщил причину.
        if (p.teleport(spawn)) {
            p.sendMessage(MenuItems.text(okMessage));
            Bukkit.getScheduler().runTaskLater(plugin, this::unloadEmptyArenas, UNLOAD_DELAY_TICKS);
        }
    }

    /** Выгружает арены BedWars/SkyWars, если в них не осталось игроков (экономия ОЗУ). */
    private void unloadEmptyArenas() {
        if (!plugin.getConfig().getBoolean("memory.unload-empty-arenas", true)) return;
        World main = Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0);
        for (String name : List.of(Modes.bedwarsArena(), Modes.skywarsArena())) {
            World w = Bukkit.getWorld(name);
            if (w == null || !w.getPlayers().isEmpty()) continue;
            if (w.equals(main)) continue; // основной мир сервера выгрузить нельзя
            if (Bukkit.unloadWorld(w, true)) {
                plugin.getLogger().info("Пустой мир выгружен из памяти: " + name);
            } else {
                plugin.getLogger().warning("Не удалось выгрузить пустой мир " + name
                        + " (его удерживает другой плагин). Выгрузите вручную: /mv unload " + name);
            }
        }
    }
}
