package ru.fatecore.menu;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import ru.fatecore.classes.ClassManager;
import ru.fatecore.learn.BountyCommand;
import ru.fatecore.learn.ShopGui;
import ru.fatecore.trade.TradeGui;
import ru.fatecore.util.Modes;

import java.util.Arrays;

/** Главное меню (Компас, ПКМ): классы, телепортация, магазин Эхо, баунти, помощь, кланы, пати, /ah, /trade, привилегии. */
public final class MainMenuGui implements Listener {
    private static final int SIZE = 36;
    private static final int SLOT_CLASS = 10;
    private static final int SLOT_TELEPORT = 12;
    private static final int SLOT_SHOP = 14;      // магазин за Эхо (ShopGui)
    private static final int SLOT_BOUNTY = 16;    // подсказка про /bounty
    private static final int SLOT_HELP = 20;
    private static final int SLOT_CLAN = 22;      // Кланы (Семьи): /clan
    private static final int SLOT_PARTY = 24;     // Группы (Пати): /party
    private static final int SLOT_AH = 28;
    private static final int SLOT_TRADE = 30;
    private static final int SLOT_DONATE = 32;

    public static final class Holder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    private final Plugin plugin;
    private final ClassManager classes;
    private final HelpGui helpGui;
    private final DonateGui donateGui;
    private final TeleportGui teleportGui;
    private final ShopGui shop;

    public MainMenuGui(Plugin plugin, ClassManager classes, HelpGui helpGui, DonateGui donateGui, TeleportGui teleportGui, ShopGui shop) {
        this.shop = shop;
        this.plugin = plugin;
        this.classes = classes;
        this.helpGui = helpGui;
        this.donateGui = donateGui;
        this.teleportGui = teleportGui;
    }

    /** Заголовок и неизменяемые кнопки создаются один раз; при открытии меняются только «живые» кнопки. */
    private static final Component TITLE = MenuItems.text("&8Главное меню");

    private ItemStack[] base;
    private ItemStack tradeButton;
    private int tradeTax = Integer.MIN_VALUE;
    private ItemStack teleportButton;
    private int[] teleportCounts;

    private ItemStack[] buildBase() {
        ItemStack[] tpl = new ItemStack[SIZE];
        Arrays.fill(tpl, MenuItems.filler(Material.BLACK_STAINED_GLASS_PANE));

        tpl[SLOT_CLASS] = MenuItems.button(Material.IRON_SWORD, "&6Выбор класса",
                "&7Выбери свой путь: Кузнец, Воин или Странник.");
        tpl[SLOT_SHOP] = MenuItems.button(Material.EMERALD_BLOCK, "&6Магазин Эхо",
                "&7Косметика, кейсы и бусты за Эхо.", "&7Команда: &e/shop", "", "&aНажми, чтобы открыть");
        tpl[SLOT_BOUNTY] = MenuItems.button(Material.SKELETON_SKULL, "&cБаунти",
                "&7Назначь награду за голову игрока.", "&7Минимум: &e" + BountyCommand.MIN_AMOUNT + " Эхо&7, комиссия: &e"
                        + BountyCommand.COMMISSION_PERCENT + "%", "", "&aНажми, чтобы узнать команду");
        tpl[SLOT_CLAN] = MenuItems.button(Material.WHITE_BANNER, "&6Кланы (Семьи)",
                "&7Создай семью или вступи в неё.", "&7Команда: &e/clan", "", "&aНажми, чтобы открыть");
        tpl[SLOT_PARTY] = MenuItems.button(Material.PLAYER_HEAD, "&6Группы (Пати)",
                "&7Играй вместе с друзьями.", "&7Команда: &e/party", "", "&aНажми, чтобы открыть");
        tpl[SLOT_AH] = MenuItems.button(Material.EMERALD, "&6Аукцион",
                "&7Покупай и продавай предметы игрокам.", "&7Команда: &e/ah", "", "&aНажми, чтобы открыть");
        tpl[SLOT_HELP] = MenuItems.button(Material.BOOK, "&6Помощь и правила",
                "&7Все команды сервера и полезные советы.");
        tpl[SLOT_DONATE] = MenuItems.button(Material.NETHER_STAR, "&6Привилегии",
                "&7Множитель Эхо, перки Выживания и косметика.", "&7Скидка на налог Обмена и Баунти.");
        return tpl;
    }

    public void open(Player p) {
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.inventory = inv;

        ItemStack[] tpl = base;
        if (tpl == null) base = tpl = buildBase();
        inv.setContents(tpl);

        // кнопка телепорта зависит от онлайна режимов — пересобираем, только если числа изменились
        int[] counts = {
                Modes.players(Modes.survivalWorld()),
                Modes.players(Modes.bedwarsLobby(), Modes.bedwarsArena()),
                Modes.players(Modes.skywarsLobby(), Modes.skywarsArena())};
        if (teleportButton == null || !Arrays.equals(counts, teleportCounts)) {
            teleportButton = MenuItems.button(Material.COMPASS, "&6Телепортация",
                    "&7Выбери режим:",
                    "&aВыживание &7(Игроков: " + counts[0] + ")",
                    "&cBedWars &7(Игроков: " + counts[1] + ")",
                    "&bSkyWars &7(Игроков: " + counts[2] + ")");
            teleportCounts = counts;
        }
        inv.setItem(SLOT_TELEPORT, teleportButton);

        // налог берётся из config.yml (trade.tax-echo): кнопку пересобираем при изменении
        int tax = TradeGui.tax(plugin);
        if (tradeButton == null || tax != tradeTax) {
            tradeButton = MenuItems.button(Material.PAPER, "&6Обмен с игроком",
                    "&7Безопасный обмен предметами:", "&e/trade <ник>",
                    "&7Налог: &e" + tax + " Эхо &7(со скидкой привилегии — меньше).");
            tradeTax = tax;
        }
        inv.setItem(SLOT_TRADE, tradeButton);

        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;

        switch (e.getSlot()) {
            case SLOT_CLASS -> { p.closeInventory(); classes.openGui(p); }
            case SLOT_TELEPORT -> {
                p.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> teleportGui.open(p));
            }
            case SLOT_SHOP -> {
                p.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> shop.openMain(p));
            }
            case SLOT_BOUNTY -> {
                p.closeInventory();
                p.sendMessage(MenuItems.text("&6Баунти: &e/bounty <ник> <сумма> &7— награда за голову игрока. Минимум &e"
                        + BountyCommand.MIN_AMOUNT + " Эхо&7, комиссия &e" + BountyCommand.COMMISSION_PERCENT + "%&7 (у привилегий ниже)."));
            }
            case SLOT_CLAN -> {
                p.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> p.performCommand("clan"));
            }
            case SLOT_PARTY -> {
                p.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> p.performCommand("party"));
            }
            case SLOT_AH -> {
                p.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> p.performCommand("ah"));
            }
            case SLOT_TRADE -> {
                p.closeInventory();
                p.sendMessage(MenuItems.text("&6Обмен: &e/trade <ник> &7— отправить игроку запрос на безопасный обмен."));
            }
            case SLOT_HELP -> { p.closeInventory(); helpGui.open(p); }
            case SLOT_DONATE -> { p.closeInventory(); donateGui.open(p); }
            default -> { }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
