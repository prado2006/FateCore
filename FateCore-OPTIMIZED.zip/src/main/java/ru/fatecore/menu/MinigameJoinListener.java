package ru.fatecore.menu;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.Plugin;
import ru.fatecore.util.Modes;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Вход в мини-игру через портал: когда игрок УСПЕШНО телепортируется (из другого мира) в арену,
 * от его имени выполняется команда входа: world_bedwars → bw join arena1, world_skywars → swm join sky1
 * (config: minigames.*). Только от имени игрока, не от консоли.
 * Защита от петли: сама команда входа тоже телепортирует в арену — пока игрок «в процессе входа»,
 * повторные срабатывания игнорируются.
 */
public final class MinigameJoinListener implements Listener {
    private static final long JOIN_DELAY_TICKS = 5L;
    private static final long GUARD_TICKS = 100L;

    private final Plugin plugin;
    private final Set<UUID> joining = new HashSet<>();

    public MinigameJoinListener(Plugin plugin) {
        this.plugin = plugin;
    }

    private String commandFor(String world) {
        if (world.equals(Modes.bedwarsArena())) {
            return plugin.getConfig().getString("minigames.bedwars-join", "bw join arena1");
        }
        if (world.equals(Modes.skywarsArena())) {
            return plugin.getConfig().getString("minigames.skywars-join", "swm join sky1");
        }
        return null;
    }

    // MONITOR + ignoreCancelled: реагируем только на ТП, которые не отменили PortalListener и др.
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        if (e.getTo() == null || e.getTo().getWorld() == null) return;
        if (e.getFrom().getWorld() == e.getTo().getWorld()) return; // перемещения внутри арены не считаем
        String cmd = commandFor(e.getTo().getWorld().getName());
        if (cmd == null || cmd.isBlank()) return;

        Player p = e.getPlayer();
        if (!joining.add(p.getUniqueId())) return; // уже входит в игру

        String command = cmd.startsWith("/") ? cmd.substring(1) : cmd;
        String arena = e.getTo().getWorld().getName();
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && p.getWorld().getName().equals(arena)) p.performCommand(command);
        }, JOIN_DELAY_TICKS);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> joining.remove(p.getUniqueId()), GUARD_TICKS);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        joining.remove(e.getPlayer().getUniqueId());
    }
}
