package ru.fatecore.quest;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.fatecore.FateCore;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.util.Items;
import ru.fatecore.util.Msg;
import ru.fatecore.util.YamlStore;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * МОДУЛЬ 6 — ежедневные квесты. Пул из 30 квестов (quests.yml → pool), каждый день в 00:00 МСК
 * случайно выбираются {@value #DAILY_COUNT} квеста (одни и те же для всех игроков).
 * Награда квеста — Эхо (диапазон зависит от сложности); за все квесты дня — «плюшка».
 * Прогресс игроков хранится там же (progress.<uuid>.q.<id>). Донат-группы выдать нельзя.
 */
public final class QuestManager {
    public static final String QUEST_GROUP = "quest";
    public static final ZoneId MSK = ZoneId.of("Europe/Moscow");
    public static final int DAILY_COUNT = 3;

    public enum Difficulty {
        EASY("&a", "Лёгкий", 15, 25),
        MEDIUM("&e", "Средний", 35, 50),
        HARD("&c", "Сложный", 70, 90);

        public final String color;
        public final String label;
        public final int minEcho;
        public final int maxEcho;

        Difficulty(String color, String label, int minEcho, int maxEcho) {
            this.color = color;
            this.label = label;
            this.minEcho = minEcho;
            this.maxEcho = maxEcho;
        }
    }

    /** Что считает квест. */
    public enum Type {
        BREAK_LOG(Material.OAK_LOG),
        PLACE_BLOCK(Material.BRICKS),
        BREAK_BLOCK(Material.IRON_PICKAXE),
        KILL_MOB(Material.IRON_SWORD),
        FISH(Material.FISHING_ROD),
        CRAFT(Material.CRAFTING_TABLE),
        BEDWARS_WIN(Material.RED_BED),
        BEDWARS_KILL(Material.RED_BED),
        SKYWARS_WIN(Material.ENDER_EYE),
        SKYWARS_KILL(Material.DIAMOND_SWORD);

        public final Material icon;

        Type(Material icon) {
            this.icon = icon;
        }
    }

    public record Def(String id, String title, Type type, Difficulty difficulty, int target, int echo,
                      Set<String> filter, Material icon) {
        /** Засчитывается ли событие с такими ключами (названия блока/моба/предмета, HOSTILE, ANIMAL). */
        public boolean matches(String... keys) {
            if (filter.isEmpty()) return true;
            for (String k : keys) {
                if (k != null && filter.contains(k.toUpperCase(Locale.ROOT))) return true;
            }
            return false;
        }
    }

    private final FateCore plugin;
    private final EchoManager echo;
    private final YamlStore store;

    private Map<String, Def> pool;
    private YamlConfiguration jarDefaults;
    private String activeDate;
    private List<Def> activeList = List.of();

    public QuestManager(FateCore plugin, EchoManager echo) {
        this.plugin = plugin;
        this.echo = echo;
        this.store = new YamlStore(plugin, "quests.yml");
    }

    // ---------- определения (pool, plushka) ----------

    /** Определения берутся из quests.yml на сервере; если там старый формат (без pool) — из quests.yml внутри плагина. */
    private ConfigurationSection defs() {
        if (store.cfg().isConfigurationSection("pool")) return store.cfg();
        if (jarDefaults == null) {
            InputStream in = plugin.getResource("quests.yml");
            jarDefaults = in == null ? new YamlConfiguration()
                    : YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
            plugin.getLogger().warning("quests.yml на сервере в старом формате (нет pool) — используется пул из плагина. "
                    + "Удалите старый quests.yml, чтобы получить новый файл.");
        }
        return jarDefaults;
    }

    public Map<String, Def> pool() {
        if (pool == null) pool = parsePool();
        return pool;
    }

    private Map<String, Def> parsePool() {
        Map<String, Def> out = new LinkedHashMap<>();
        ConfigurationSection root = defs().getConfigurationSection("pool");
        if (root == null) return out;
        for (String id : root.getKeys(false)) {
            ConfigurationSection c = root.getConfigurationSection(id);
            if (c == null) continue;
            Type type;
            Difficulty diff;
            try {
                type = Type.valueOf(c.getString("type", "").toUpperCase(Locale.ROOT));
                diff = Difficulty.valueOf(c.getString("difficulty", "").toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("quests.yml: квест " + id + " пропущен (неверный type/difficulty)");
                continue;
            }
            int echoAmount = c.getInt("echo", diff.minEcho);
            if (echoAmount < diff.minEcho || echoAmount > diff.maxEcho) {
                plugin.getLogger().warning("quests.yml: награда квеста " + id + " (" + echoAmount + ") вне диапазона "
                        + diff + " " + diff.minEcho + "-" + diff.maxEcho);
            }
            Set<String> filter = new HashSet<>();
            for (String f : c.getStringList("filter")) filter.add(f.toUpperCase(Locale.ROOT));
            Material icon = Material.matchMaterial(c.getString("icon", ""));
            out.put(id, new Def(id, c.getString("title", id), type, diff, Math.max(1, c.getInt("target", 1)),
                    echoAmount, filter, icon != null ? icon : type.icon));
        }
        return out;
    }

    // ---------- квесты дня ----------

    /** День МСК и границы его суток в мс: строку даты пересчитываем только при смене суток, а не на каждое событие. */
    private record DayCache(String day, long startMs, long endMs) {}

    private static volatile DayCache dayCache = new DayCache("", 0L, 0L);

    private static String today() {
        long now = System.currentTimeMillis();
        DayCache c = dayCache;
        if (now >= c.startMs() && now < c.endMs()) return c.day();
        LocalDate d = LocalDate.now(MSK);
        c = new DayCache(d.toString(),
                d.atStartOfDay(MSK).toInstant().toEpochMilli(),
                d.plusDays(1).atStartOfDay(MSK).toInstant().toEpochMilli());
        dayCache = c;
        return c.day();
    }

    /** Активные квесты сегодняшнего дня (при смене даты МСК выбираются заново). */
    public List<Def> activeQuests() {
        String today = today();
        if (today.equals(activeDate)) return activeList;

        Map<String, Def> all = pool();
        ConfigurationSection a = store.cfg().getConfigurationSection("active");
        if (a != null && today.equals(a.getString("date"))) {
            List<Def> saved = new ArrayList<>();
            for (String id : a.getStringList("ids")) {
                Def d = all.get(id);
                if (d != null) saved.add(d);
            }
            if (saved.size() == Math.min(DAILY_COUNT, all.size())) {
                activeDate = today;
                activeList = Collections.unmodifiableList(saved);
                return activeList;
            }
        }
        return roll(today, all);
    }

    private List<Def> roll(String today, Map<String, Def> all) {
        List<Def> shuffled = new ArrayList<>(all.values());
        Collections.shuffle(shuffled, ThreadLocalRandom.current());
        List<Def> picked = new ArrayList<>(shuffled.subList(0, Math.min(DAILY_COUNT, shuffled.size())));
        List<String> ids = new ArrayList<>();
        for (Def d : picked) ids.add(d.id());
        store.cfg().set("active.date", today);
        store.cfg().set("active.ids", ids);
        store.dirty();
        activeDate = today;
        activeList = Collections.unmodifiableList(picked);
        plugin.getLogger().info("Квесты дня " + today + ": " + ids);
        return activeList;
    }

    public String rewardText(Def d) {
        return d.echo() + " Эхо";
    }

    /** Подписи вариантов «Плюшки» из quests.yml (plushka[].label). */
    public List<String> plushkaLabels() {
        List<String> out = new ArrayList<>();
        for (Map<?, ?> v : defs().getMapList("plushka")) out.add(String.valueOf(v.get("label")));
        return out;
    }

    // ---------- данные игрока ----------

    private ConfigurationSection sec(UUID id) {
        String path = "progress." + id;
        ConfigurationSection s = store.cfg().getConfigurationSection(path);
        return s != null ? s : store.cfg().createSection(path);
    }

    public void resetQuestsIfNewDay(UUID id) {
        String today = today();
        ConfigurationSection s = sec(id);
        if (today.equals(s.getString("lastReset"))) return;
        s.set("q", null);
        s.set("dayCompleted", 0);
        s.set("rewarded", null);
        s.set("plushka", false);
        s.set("lastReset", today);
        store.dirty();
    }

    /** Полночь МСК: выбираем новые квесты дня и сбрасываем прогресс игроков онлайн. */
    public void resetOnline() {
        activeQuests();
        plugin.getServer().getOnlinePlayers().forEach(p -> resetQuestsIfNewDay(p.getUniqueId()));
    }

    public int progress(UUID id, Def d) {
        resetQuestsIfNewDay(id);
        return sec(id).getInt("q." + d.id());
    }

    public int dayCompleted(UUID id) {
        resetQuestsIfNewDay(id);
        return sec(id).getInt("dayCompleted");
    }

    public boolean plushkaGiven(UUID id) {
        resetQuestsIfNewDay(id);
        return sec(id).getBoolean("plushka");
    }

    public String progressString(UUID id) {
        StringBuilder sb = new StringBuilder();
        for (Def d : activeQuests()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(d.title()).append(' ').append(progress(id, d)).append('/').append(d.target());
        }
        return sb.toString();
    }

    // ---------- прогресс ----------

    /**
     * Засчитывает событие всем активным квестам данного типа, которым подходят ключи
     * (название блока/моба/предмета, HOSTILE, ANIMAL).
     */
    public void addProgress(Player p, Type type, int amount, String... keys) {
        List<Def> active = activeQuests();
        boolean relevant = false; // быстрый выход: ни один квест дня не считает этот тип событий (ломание/установка блоков — очень частые)
        for (Def d : active) {
            if (d.type() == type) {
                relevant = true;
                break;
            }
        }
        if (!relevant) return;
        UUID id = p.getUniqueId();
        resetQuestsIfNewDay(id);
        ConfigurationSection s = sec(id);
        for (Def d : active) {
            if (d.type() != type || !d.matches(keys)) continue;
            int cur = s.getInt("q." + d.id());
            if (cur >= d.target()) continue;
            int now = Math.min(d.target(), cur + amount);
            s.set("q." + d.id(), now);
            store.dirty();
            if (now >= d.target()) complete(p, d, s);
        }
    }

    private java.util.function.Consumer<Player> completionHook;

    /** Вызывается после каждого выполненного квеста (для достижений). */
    public void setCompletionHook(java.util.function.Consumer<Player> hook) {
        this.completionHook = hook;
    }

    private void complete(Player p, Def d, ConfigurationSection s) {
        if (s.getBoolean("rewarded." + d.id())) return;
        s.set("rewarded." + d.id(), true);
        int done = s.getInt("dayCompleted") + 1;
        s.set("dayCompleted", done);
        store.dirty();

        echo.addEcho(p, d.echo());
        Msg.send(p, "&aКвест выполнен: " + d.difficulty().color + "[" + d.difficulty().label + "] &6" + d.title()
                + "&a. Награда: &e" + rewardText(d));
        if (completionHook != null) completionHook.accept(p);

        if (done >= activeQuests().size() && !s.getBoolean("plushka")) {
            s.set("plushka", true);
            store.dirty();
            giveBonus(p);
        }
    }

    /** «Плюшка» за все квесты дня: случайный вариант из quests.yml → plushka. */
    private void giveBonus(Player p) {
        List<Map<?, ?>> variants = defs().getMapList("plushka");
        if (variants.isEmpty()) return;
        Map<?, ?> v = variants.get(ThreadLocalRandom.current().nextInt(variants.size()));
        Msg.send(p, "&d&lВсе квесты выполнены! &fТвоя плюшка: &e" + v.get("label"));
        Object rewards = v.get("rewards");
        if (rewards instanceof List<?> list) applyRewards(p, list);
    }

    // ---------- награды ----------

    private void applyRewards(Player p, List<?> rewards) {
        for (Object o : rewards) {
            if (o instanceof Map<?, ?> m) applyReward(p, m);
        }
    }

    private static double num(Map<?, ?> r, String k, double def) {
        Object o = r.get(k);
        return o instanceof Number n ? n.doubleValue() : def;
    }

    private static String str(Map<?, ?> r, String k) {
        Object o = r.get(k);
        return o == null ? "" : o.toString();
    }

    private void applyReward(Player p, Map<?, ?> r) {
        String type = str(r, "type").toLowerCase();
        switch (type) {
            case "echo" -> echo.addEcho(p, num(r, "amount", 0));
            case "item" -> {
                Material m = Material.matchMaterial(str(r, "material"));
                if (m == null) {
                    plugin.getLogger().warning("quests.yml: неизвестный материал " + str(r, "material"));
                    return;
                }
                Items.give(p, new ItemStack(m, (int) num(r, "amount", 1)));
            }
            case "effect" -> {
                PotionEffectType t = PotionEffectType.getByName(str(r, "effect"));
                if (t == null) {
                    plugin.getLogger().warning("quests.yml: неизвестный эффект " + str(r, "effect"));
                    return;
                }
                p.addPotionEffect(new PotionEffect(t, (int) num(r, "seconds", 60) * 20, (int) num(r, "amplifier", 0)));
            }
            case "key" -> {
                for (int i = 0; i < (int) num(r, "amount", 1); i++) {
                    ItemStack key = Items.make(Material.TRIPWIRE_HOOK, "&6Ключ", "&7Для открытия кейса");
                    ItemMeta meta = key.getItemMeta();
                    meta.getPersistentDataContainer().set(plugin.key("key"), PersistentDataType.BYTE, (byte) 1);
                    key.setItemMeta(meta);
                    Items.give(p, key);
                }
            }
            case "tools" -> giveTools(p, r);
            case "quest_prefix" -> grantQuestPrefix(p, (long) num(r, "hours", 24));
            case "echo_boost" -> echo.addBoost(p.getUniqueId(), num(r, "multiplier", 1.1), (long) num(r, "seconds", 3600));
            default -> plugin.getLogger().warning("quests.yml: тип награды «" + type + "» не разрешён и пропущен");
        }
    }

    private void giveTools(Player p, Map<?, ?> r) {
        Object items = r.get("items");
        Object enchants = r.get("enchants");
        if (!(items instanceof List<?> list)) return;
        for (Object name : list) {
            Material mat = Material.matchMaterial(String.valueOf(name));
            if (mat == null) continue;
            ItemStack it = new ItemStack(mat);
            if (enchants instanceof Map<?, ?> em) {
                for (Map.Entry<?, ?> en : em.entrySet()) {
                    // getByKey работает на 1.20.1 и новее (константы EFFICIENCY/UNBREAKING есть только в новых API)
                    Enchantment ench = Enchantment.getByKey(
                            NamespacedKey.minecraft(String.valueOf(en.getKey()).toLowerCase()));
                    if (ench != null && en.getValue() instanceof Number n) {
                        it.addUnsafeEnchantment(ench, n.intValue());
                    }
                }
            }
            Items.give(p, it);
        }
    }

    // ---------- префикс [Quest]: только группа "quest", на ограниченное время ----------

    /** Единственная группа, которую выдают квесты: косметический префикс [Quest], НЕ донат-ранг. */
    public void grantQuestPrefix(Player p, long hours) {
        LuckPerms lp = LuckPermsProvider.get();
        Instant until = Instant.now().plus(Duration.ofHours(hours));
        lp.getUserManager().modifyUser(p.getUniqueId(), user -> {
            user.data().clear(NodeType.INHERITANCE.predicate(n -> n.getGroupName().equals(QUEST_GROUP)));
            user.data().add(InheritanceNode.builder(QUEST_GROUP).expiry(until).build());
        });
        sec(p.getUniqueId()).set("questPrefixUntil", until.toEpochMilli());
        store.dirty();
    }

    /** Планировщик: снимает группу quest, когда срок вышел. */
    public void checkPrefixExpiry(Player p) {
        // только чтение: не создаём пустую секцию игрока каждую минуту
        long until = store.cfg().getLong("progress." + p.getUniqueId() + ".questPrefixUntil");
        if (until <= 0 || System.currentTimeMillis() < until) return;
        LuckPerms lp = LuckPermsProvider.get();
        lp.getUserManager().modifyUser(p.getUniqueId(), user ->
                user.data().clear(NodeType.INHERITANCE.predicate(n -> n.getGroupName().equals(QUEST_GROUP))));
        sec(p.getUniqueId()).set("questPrefixUntil", 0);
        store.dirty();
    }

    public void checkPrefixExpiryOnline() {
        plugin.getServer().getOnlinePlayers().forEach(this::checkPrefixExpiry);
    }
}
