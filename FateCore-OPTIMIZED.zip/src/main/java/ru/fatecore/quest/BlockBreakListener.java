package ru.fatecore.quest;

import org.bukkit.GameMode;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import ru.fatecore.quest.QuestManager.Type;
import ru.fatecore.util.Modes;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Квесты Выживания: бревно (BREAK_LOG), любой добытый блок с фильтром (BREAK_BLOCK), поставленный блок (PLACE_BLOCK).
 * Блок, поставленный игроком, при ломании не засчитывается (защита от «поставил-сломал»; память до перезапуска).
 * Считается только в мире Выживания и не в креативе.
 */
public final class BlockBreakListener implements Listener {
    private static final int MAX_TRACKED = 5000;

    private final QuestManager quests;
    private final Set<Long> placed = new LinkedHashSet<>();

    public BlockBreakListener(QuestManager quests) {
        this.quests = quests;
    }

    private static long key(Block b) {
        return (((long) b.getX() & 0x3FFFFFFL) << 38) | (((long) b.getZ() & 0x3FFFFFFL) << 12) | ((long) b.getY() & 0xFFFL);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Block b = e.getBlockPlaced();
        if (!Modes.SURVIVAL.equals(Modes.of(b.getWorld())) || e.getPlayer().getGameMode() == GameMode.CREATIVE) return;
        placed.add(key(b));
        if (placed.size() > MAX_TRACKED) {
            Iterator<Long> it = placed.iterator();
            it.next();
            it.remove();
        }
        quests.addProgress(e.getPlayer(), Type.PLACE_BLOCK, 1, b.getType().name());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (!Modes.SURVIVAL.equals(Modes.of(b.getWorld())) || e.getPlayer().getGameMode() == GameMode.CREATIVE) return;
        if (placed.remove(key(b))) return;
        String name = b.getType().name();
        if (Tag.LOGS.isTagged(b.getType())) quests.addProgress(e.getPlayer(), Type.BREAK_LOG, 1, name);
        quests.addProgress(e.getPlayer(), Type.BREAK_BLOCK, 1, name);
    }
}
