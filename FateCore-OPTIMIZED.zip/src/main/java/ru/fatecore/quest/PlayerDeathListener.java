package ru.fatecore.quest;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import ru.fatecore.quest.QuestManager.Type;
import ru.fatecore.util.Modes;

/** Квесты «Убей игроков»: убийство ИГРОКА в арене SkyWars / BedWars (мобы и самоубийства не считаются). */
public final class PlayerDeathListener implements Listener {
    private final QuestManager quests;

    public PlayerDeathListener(QuestManager quests) {
        this.quests = quests;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;
        String mode = Modes.of(victim.getWorld());
        if (Modes.SKYWARS.equals(mode)) {
            quests.addProgress(killer, Type.SKYWARS_KILL, 1);
        } else if (Modes.BEDWARS.equals(mode)) {
            quests.addProgress(killer, Type.BEDWARS_KILL, 1);
        }
    }
}
