package ru.fatecore.quest;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import ru.fatecore.gui.FateHolder;
import ru.fatecore.quest.QuestManager.Def;
import ru.fatecore.util.Items;
import ru.fatecore.util.Msg;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * GUI Квестового Мастера (27 слотов): слоты 11 / 13 / 15 — три квеста дня, 22 — «Плюшка», 26 — «Закрыть».
 * Открывается кликом по NPC и командой /quests. В каждой награде: «Привилегии не выдаются.»
 */
public final class QuestGui {
    private static final String NO_PRIV = "&7Привилегии не выдаются.";
    private static final int[] SLOTS = {11, 13, 15};

    private final QuestManager quests;

    public QuestGui(QuestManager quests) {
        this.quests = quests;
    }

    public void open(Player p) {
        UUID id = p.getUniqueId();
        FateHolder holder = new FateHolder("quests");
        Inventory inv = Bukkit.createInventory(holder, 27, Msg.c("&8Квестовый Мастер"));
        holder.bind(inv);
        Items.fill(inv);

        List<Def> active = quests.activeQuests();
        for (int i = 0; i < active.size() && i < SLOTS.length; i++) {
            inv.setItem(SLOTS[i], questItem(id, active.get(i)));
        }
        inv.setItem(22, plushkaItem(id, active.size()));
        inv.setItem(26, Items.closeButton());
        p.openInventory(inv);
    }

    private ItemStack plushkaItem(UUID id, int total) {
        int done = quests.dayCompleted(id);
        boolean given = quests.plushkaGiven(id);
        List<String> lore = new ArrayList<>();
        lore.add("&7Выполни все " + total + " квеста дня — получишь случайную плюшку:");
        for (String label : quests.plushkaLabels()) lore.add("&f • " + label);
        lore.add("&eВыполнено: " + done + "/" + total);
        lore.add(given ? "&aПлюшка получена" : "&cПлюшка ещё не получена");
        lore.add(NO_PRIV);
        // серая, пока не выполнены все квесты дня
        return given
                ? Items.make(Material.BOOK, "&dПлюшка", lore.toArray(new String[0]))
                : Items.make(Material.GRAY_DYE, "&7Плюшка", lore.toArray(new String[0]));
    }

    private ItemStack questItem(UUID id, Def d) {
        int cur = quests.progress(id, d);
        boolean done = cur >= d.target();
        return Items.make(d.icon(), d.difficulty().color + d.title(),
                "&7Сложность: " + d.difficulty().color + d.difficulty().label,
                "&7Прогресс: &f" + cur + "/" + d.target(),
                done ? "&aВыполнено" : "&cВ процессе",
                "&6Награда: &f" + quests.rewardText(d),
                NO_PRIV,
                "&8Новые квесты в 00:00 МСК");
    }
}
