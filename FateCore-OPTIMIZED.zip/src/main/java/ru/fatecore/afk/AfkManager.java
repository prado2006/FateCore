package ru.fatecore.afk;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import ru.fatecore.FateCore;
import ru.fatecore.api.IDataStore;
import ru.fatecore.api.IEchoService;
import ru.fatecore.quest.QuestManager;
import ru.fatecore.util.Auth;
import ru.fatecore.util.Modes;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * АФК-зона в главном лобби: игрок, который непрерывно находится в зоне interval-minutes минут (5),
 * получает reward-echo Эхо (10); не больше daily-limit Эхо (100) в сутки (сброс в 00:00 МСК).
 * Зона и параметры — config.yml, секция afk (включается enabled: true после указания координат).
 * Донат-множители не применяются.
 */
public final class AfkManager {
    private static final String K_DAY = "afk.day";
    private static final String K_EARNED = "afk.earned";

    private final FateCore plugin;
    private final IEchoService echo;
    private final IDataStore store;
    private final Map<UUID, Integer> minutes = new HashMap<>();

    public AfkManager(FateCore plugin, IEchoService echo, IDataStore store) {
        this.plugin = plugin;
        this.echo = echo;
        this.store = store;
    }

    public void start() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 1200L, 1200L);
    }

    private void tick() {
        ConfigurationSection c = plugin.getConfig().getConfigurationSection("afk");
        if (c == null || !c.getBoolean("enabled", false)) {
            minutes.clear();
            return;
        }
        ConfigurationSection p1 = c.getConfigurationSection("pos1");
        ConfigurationSection p2 = c.getConfigurationSection("pos2");
        if (p1 == null || p2 == null) return;
        String world = c.getString("world", Modes.mainLobby());
        int interval = Math.max(1, c.getInt("interval-minutes", 5));
        // параметры зоны и награды читаем один раз за тик, а не для каждого игрока
        double ax = p1.getDouble("x"), ay = p1.getDouble("y"), az = p1.getDouble("z");
        double bx = p2.getDouble("x"), by = p2.getDouble("y"), bz = p2.getDouble("z");
        long rewardEcho = c.getLong("reward-echo", 10);
        long dailyLimit = c.getLong("daily-limit", 100);

        minutes.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            if (!inZone(p, world, ax, ay, az, bx, by, bz) || !Auth.isAuthed(p)) {
                minutes.remove(id);
                continue;
            }
            int m = minutes.merge(id, 1, Integer::sum);
            if (m >= interval) {
                minutes.put(id, 0);
                reward(p, rewardEcho, dailyLimit);
            }
        }
    }

    private static boolean inZone(Player p, String world, double ax, double ay, double az,
                                  double bx, double by, double bz) {
        if (!p.getWorld().getName().equals(world)) return false; // дешёвая проверка мира до создания Location
        Location l = p.getLocation();
        return between(l.getX(), ax, bx) && between(l.getY(), ay, by) && between(l.getZ(), az, bz);
    }

    private static boolean between(double v, double a, double b) {
        return v >= Math.min(a, b) && v <= Math.max(a, b) + 1; // +1: граница включает весь блок
    }

    private void reward(Player p, long amount, long dailyLimit) {
        UUID id = p.getUniqueId();
        long today = LocalDate.now(QuestManager.MSK).toEpochDay();
        if (store.getLong(id, K_DAY, -1) != today) {
            store.setLong(id, K_DAY, today);
            store.setLong(id, K_EARNED, 0);
        }
        long earned = store.getLong(id, K_EARNED, 0);
        long pay = Math.min(amount, dailyLimit - earned);
        if (pay <= 0) return;
        store.setLong(id, K_EARNED, earned + pay);
        echo.give(id, pay);
        if (earned + pay >= dailyLimit) {
            p.sendMessage("§7Дневной лимит награды за АФК-зону достигнут (§e" + dailyLimit + " Эхо§7). Завтра — снова!");
        }
    }
}
