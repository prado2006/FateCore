package ru.fatecore.trade;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** /trade <ник> — запрос на обмен; /trade accept | deny — ответ на запрос. */
public final class TradeCommand implements CommandExecutor {
    private final TradeGui gui;

    public TradeCommand(TradeGui gui) {
        this.gui = gui;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Только для игроков.");
            return true;
        }
        if (args.length == 0) {
            p.sendMessage("§7Использование: §e/trade <ник> §7— предложить обмен; §e/trade accept §7/ §e/trade deny");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "accept", "принять" -> gui.accept(p);
            case "deny", "decline", "отклонить" -> gui.deny(p);
            default -> {
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null) {
                    p.sendMessage("§cИгрок не в сети.");
                    return true;
                }
                gui.request(p, target);
            }
        }
        return true;
    }
}
