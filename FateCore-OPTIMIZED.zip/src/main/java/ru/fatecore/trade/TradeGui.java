package ru.fatecore.trade;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType.SlotType;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import ru.fatecore.combat.CombatManager;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.menu.MenuItems;
import ru.fatecore.util.Auth;
import ru.fatecore.util.Modes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Безопасный обмен /trade (GUI на 54 слота).
 *
 * Схема окна (у каждого участника своё окно):
 *   колонки 0-3, ряды 0-4  — ВАШЕ предложение (клик по предмету — убрать);
 *   колонки 5-8, ряды 0-4  — предложение партнёра (только просмотр);
 *   нижний ряд: 45 — отмена, 47 — «Готов» (галочка), 49 — информация, 51 — статус партнёра.
 * Предмет добавляется кликом по нему в СВОЁМ инвентаре (нижняя часть окна).
 *
 * Защита:
 *  - предметы физически остаются у владельцев до момента сделки (при сбое/выходе ничего не теряется);
 *  - ЛЮБОЕ изменение предложения любой из сторон сбрасывает обе галочки;
 *  - при сделке всё перепроверяется: предметы на месте и без изменений, Эхо на налог, место в инвентарях;
 *  - налог (trade.tax-echo) списывается с каждого участника; все клики в окне отменяются.
 */
public final class TradeGui implements Listener {
    private static final int SIZE = 54;
    private static final int PER_SIDE = 20; // 4 колонки x 5 рядов
    private static final int SLOT_CANCEL = 45;
    private static final int SLOT_READY = 47;
    private static final int SLOT_INFO = 49;
    private static final int SLOT_PARTNER = 51;

    /** Налог за сделку (с каждого участника), config: trade.tax-echo. */
    public static int tax(Plugin plugin) {
        return Math.max(0, plugin.getConfig().getInt("trade.tax-echo", 5));
    }

    /** Налог конкретного игрока с учётом скидки привилегии (tax-discounts): 5 -> 4.5 ... 2.5. */
    public static double tax(Plugin plugin, org.bukkit.entity.Player p) {
        return ru.fatecore.perks.TaxDiscount.apply(tax(plugin), ru.fatecore.perks.TaxDiscount.percent(plugin, p));
    }

    private record Entry(int slot, ItemStack snapshot) {}

    private record Request(UUID from, long expiresAt) {}

    private static final class Session {
        final Player[] players = new Player[2];
        final Inventory[] invs = new Inventory[2];
        final List<List<Entry>> offers = List.of(new ArrayList<Entry>(), new ArrayList<Entry>());
        final boolean[] ready = new boolean[2];
        /** Налог каждого участника для отображения: считается один раз при старте (в complete() пересчитывается заново). */
        final double[] shownTax = new double[2];
        boolean finished;
    }

    private static final class Holder implements InventoryHolder {
        final Session session;
        final int side;
        Inventory inventory;

        Holder(Session session, int side) {
            this.session = session;
            this.side = side;
        }

        @Override public Inventory getInventory() { return inventory; }
    }

    private final Plugin plugin;
    private final EchoManager echo;
    private final MenuItems menuItems;
    private final CombatManager combat;
    private final Map<UUID, Session> sessions = new HashMap<>();
    private final Map<UUID, Request> requests = new HashMap<>(); // ключ — получатель запроса

    // Статичные элементы окна: создаются один раз, инвентарь копирует предмет при setItem
    private final ItemStack paneBlack = MenuItems.filler(Material.BLACK_STAINED_GLASS_PANE);
    private final ItemStack paneGray = MenuItems.filler(Material.GRAY_STAINED_GLASS_PANE);
    private final ItemStack btnCancel = MenuItems.button(Material.BARRIER, "&cОтменить обмен");
    private final ItemStack btnReadyOn = MenuItems.button(Material.LIME_DYE, "&aВы готовы", "&7Нажмите, чтобы отменить готовность");
    private final ItemStack btnReadyOff = MenuItems.button(Material.GRAY_DYE, "&7Нажмите, когда будете готовы",
            "&7Любое изменение предметов сбрасывает готовность обеих сторон");
    private final ItemStack partnerReady = MenuItems.button(Material.LIME_STAINED_GLASS_PANE, "&aПартнёр готов");
    private final ItemStack partnerWaiting = MenuItems.button(Material.RED_STAINED_GLASS_PANE, "&cПартнёр ещё не готов");

    public TradeGui(Plugin plugin, EchoManager echo, MenuItems menuItems, CombatManager combat) {
        this.plugin = plugin;
        this.echo = echo;
        this.menuItems = menuItems;
        this.combat = combat;
    }

    // ======================= запросы =======================

    /** Возвращает текст ошибки, если обмен между игроками сейчас невозможен, иначе null. */
    private String problem(Player a, Player b) {
        if (a.equals(b)) return "§cНельзя обмениваться с самим собой.";
        if (!Auth.isAuthed(a)) return "§cСначала /login";
        if (!Auth.isAuthed(b)) return "§cИгрок " + b.getName() + " ещё не авторизовался.";
        if (sessions.containsKey(a.getUniqueId())) return "§cВы уже в обмене.";
        if (sessions.containsKey(b.getUniqueId())) return "§cИгрок " + b.getName() + " сейчас в другом обмене.";
        if (Modes.isMinigameWorld(a.getWorld()) || Modes.isMinigameWorld(b.getWorld())) {
            return "§cВ мини-играх обмен недоступен.";
        }
        if (combat.isTagged(a.getUniqueId()) || combat.isTagged(b.getUniqueId())) {
            return "§cВо время боя обмен недоступен.";
        }
        return null;
    }

    public void request(Player from, Player to) {
        String err = problem(from, to);
        if (err != null) {
            from.sendMessage(err);
            return;
        }
        long now = System.currentTimeMillis();

        // встречный запрос — сразу начинаем обмен
        Request reverse = requests.get(from.getUniqueId());
        if (reverse != null && reverse.from().equals(to.getUniqueId()) && reverse.expiresAt() > now) {
            requests.remove(from.getUniqueId());
            start(to, from);
            return;
        }

        long ttl = Math.max(5, plugin.getConfig().getLong("trade.request-seconds", 30));
        requests.put(to.getUniqueId(), new Request(from.getUniqueId(), now + ttl * 1000L));
        from.sendMessage("§6[Обмен] §7Запрос отправлен игроку §e" + to.getName() + "§7. Действует §e" + ttl + " сек.");
        to.sendMessage(Component.text("[Обмен] ", NamedTextColor.GOLD)
                .append(Component.text(from.getName(), NamedTextColor.YELLOW))
                .append(Component.text(" предлагает вам обмен предметами. ", NamedTextColor.GRAY))
                .append(Component.text("[ПРИНЯТЬ]", NamedTextColor.GREEN, TextDecoration.BOLD)
                        .clickEvent(ClickEvent.runCommand("/trade accept")))
                .append(Component.text(" "))
                .append(Component.text("[ОТКЛОНИТЬ]", NamedTextColor.RED, TextDecoration.BOLD)
                        .clickEvent(ClickEvent.runCommand("/trade deny"))));
    }

    public void accept(Player to) {
        Request r = requests.remove(to.getUniqueId());
        if (r == null || r.expiresAt() < System.currentTimeMillis()) {
            to.sendMessage("§cНет активных запросов на обмен.");
            return;
        }
        Player from = Bukkit.getPlayer(r.from());
        if (from == null || !from.isOnline()) {
            to.sendMessage("§cИгрок, приславший запрос, уже не в сети.");
            return;
        }
        String err = problem(from, to);
        if (err != null) {
            to.sendMessage(err);
            from.sendMessage(err);
            return;
        }
        start(from, to);
    }

    public void deny(Player to) {
        Request r = requests.remove(to.getUniqueId());
        if (r == null) {
            to.sendMessage("§cНет активных запросов на обмен.");
            return;
        }
        to.sendMessage("§7Запрос на обмен отклонён.");
        Player from = Bukkit.getPlayer(r.from());
        if (from != null) from.sendMessage("§6[Обмен] §e" + to.getName() + " §cотклонил ваш запрос.");
    }

    // ======================= окно =======================

    private void start(Player a, Player b) {
        Session s = new Session();
        s.players[0] = a;
        s.players[1] = b;
        for (int i = 0; i < 2; i++) {
            Holder h = new Holder(s, i);
            Player partner = s.players[1 - i];
            Inventory inv = Bukkit.createInventory(h, SIZE, MenuItems.text("&8Обмен с " + partner.getName()));
            h.inventory = inv;
            s.invs[i] = inv;
            sessions.put(s.players[i].getUniqueId(), s);
            s.shownTax[i] = tax(plugin, s.players[i]); // запрос прав в LuckPerms — один раз на сессию, а не на каждый клик
        }
        render(s);
        a.openInventory(s.invs[0]);
        b.openInventory(s.invs[1]);
        for (Player p : s.players) {
            p.sendMessage("§6[Обмен] §7Кликайте по предметам в своём инвентаре, чтобы предложить их. "
                    + "Когда всё устраивает — нажмите зелёную кнопку «Готов».");
        }
    }

    private static int ownSlot(int idx) { return (idx / 4) * 9 + (idx % 4); }

    private static int partnerSlot(int idx) { return (idx / 4) * 9 + 5 + (idx % 4); }

    private static int ownIndex(int slot) {
        int r = slot / 9;
        int c = slot % 9;
        return (r < 5 && c < 4) ? r * 4 + c : -1;
    }

    private void render(Session s) {
        for (int side = 0; side < 2; side++) {
            Inventory inv = s.invs[side];
            Player me = s.players[side];
            Player partner = s.players[1 - side];
            double tax = s.shownTax[side];
            inv.clear();
            for (int r = 0; r < 6; r++) {
                for (int c = 0; c < 9; c++) {
                    if (r < 5 && (c < 4 || c > 4)) continue; // зоны предметов
                    inv.setItem(r * 9 + c, r < 5 ? paneGray : paneBlack);
                }
            }
            List<Entry> mine = s.offers.get(side);
            List<Entry> theirs = s.offers.get(1 - side);
            for (int i = 0; i < mine.size() && i < PER_SIDE; i++) inv.setItem(ownSlot(i), mine.get(i).snapshot().clone());
            for (int i = 0; i < theirs.size() && i < PER_SIDE; i++) inv.setItem(partnerSlot(i), theirs.get(i).snapshot().clone());

            inv.setItem(SLOT_CANCEL, btnCancel);
            inv.setItem(SLOT_READY, s.ready[side] ? btnReadyOn : btnReadyOff);
            inv.setItem(SLOT_INFO, MenuItems.button(Material.PAPER, "&6Обмен: " + me.getName() + " ⇄ " + partner.getName(),
                    "&7Ваш налог: &e" + ru.fatecore.perks.TaxDiscount.fmt(tax) + " Эхо &7(скидка привилегии учтена)",
                    "&7Ваш баланс: &e" + echo.format(echo.getEcho(me)) + " Эхо",
                    "&7Слева — ваше предложение, справа — партнёра"));
            inv.setItem(SLOT_PARTNER, s.ready[1 - side] ? partnerReady : partnerWaiting);
        }
    }

    // ======================= клики =======================

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true); // всё перемещение делаем сами
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Session s = h.session;
        if (s.finished) return;
        int side = h.side;
        Inventory clicked = e.getClickedInventory();
        if (clicked == null) return;

        if (clicked == e.getView().getTopInventory()) {
            int slot = e.getSlot();
            if (slot == SLOT_CANCEL) {
                cancel(s, "§6[Обмен] §e" + p.getName() + " §cотменил обмен.");
            } else if (slot == SLOT_READY) {
                toggleReady(s, side);
            } else {
                int idx = ownIndex(slot);
                if (idx >= 0 && idx < s.offers.get(side).size()) {
                    s.offers.get(side).remove(idx);
                    resetReady(s);
                    render(s);
                }
            }
            return;
        }

        // нижняя часть — инвентарь игрока: добавляем стак в предложение
        if (clicked != p.getInventory()) return;
        SlotType t = e.getSlotType();
        if (t != SlotType.CONTAINER && t != SlotType.QUICKBAR) return;
        int slot = e.getSlot();
        if (slot < 0 || slot >= 36) return;
        ItemStack item = p.getInventory().getItem(slot);
        if (item == null || item.getType().isAir()) return;
        if (menuItems.isMenuItem(item)) {
            p.sendMessage("§cПредметы меню обменивать нельзя.");
            return;
        }
        List<Entry> mine = s.offers.get(side);
        for (Entry en : mine) if (en.slot() == slot) return; // уже предложен
        if (mine.size() >= PER_SIDE) {
            p.sendMessage("§cМаксимум " + PER_SIDE + " предметов в обмене.");
            return;
        }
        mine.add(new Entry(slot, item.clone()));
        resetReady(s);
        render(s);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        if (h.session.finished) return;
        cancel(h.session, "§6[Обмен] §e" + e.getPlayer().getName() + " §cзакрыл окно — обмен отменён.");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        requests.remove(id);
        requests.values().removeIf(r -> r.from().equals(id));
        Session s = sessions.get(id);
        if (s != null) cancel(s, "§6[Обмен] §e" + e.getPlayer().getName() + " §cвышел — обмен отменён.");
    }

    /** Закрывает все обмены (выключение плагина). Предметы остаются у владельцев — терять нечего. */
    public void closeAll() {
        for (Session s : new ArrayList<>(sessions.values())) cancel(s, "§6[Обмен] §cОбмен отменён: перезагрузка плагина.");
        requests.clear();
    }

    // ======================= логика сделки =======================

    private void resetReady(Session s) {
        s.ready[0] = false;
        s.ready[1] = false;
    }

    private void toggleReady(Session s, int side) {
        if (s.ready[side]) {
            s.ready[side] = false;
            render(s);
            return;
        }
        if (!verify(s.players[side], s.offers.get(side))) {
            cancel(s, "§6[Обмен] §cПредметы в инвентаре изменились — обмен отменён.");
            return;
        }
        s.ready[side] = true;
        if (s.ready[0] && s.ready[1]) {
            complete(s);
        } else {
            render(s);
        }
    }

    /** Предложенные предметы всё ещё лежат на своих местах без изменений. */
    private boolean verify(Player p, List<Entry> offer) {
        for (Entry en : offer) {
            ItemStack cur = p.getInventory().getItem(en.slot());
            if (cur == null || !cur.isSimilar(en.snapshot()) || cur.getAmount() != en.snapshot().getAmount()) return false;
        }
        return true;
    }

    /** Поместятся ли входящие предметы после того, как предложенные будут убраны из инвентаря. */
    private boolean fits(Player p, List<Entry> outgoing, List<ItemStack> incoming) {
        Inventory sim = Bukkit.createInventory(null, 36);
        ItemStack[] contents = p.getInventory().getStorageContents();
        for (int i = 0; i < 36 && i < contents.length; i++) {
            final int slot = i;
            if (outgoing.stream().anyMatch(en -> en.slot() == slot)) continue;
            if (contents[i] != null) sim.setItem(i, contents[i].clone());
        }
        ItemStack[] in = incoming.stream().map(ItemStack::clone).toArray(ItemStack[]::new);
        return sim.addItem(in).isEmpty();
    }

    private List<ItemStack> stacks(List<Entry> offer) {
        List<ItemStack> out = new ArrayList<>();
        for (Entry en : offer) out.add(en.snapshot().clone());
        return out;
    }

    private void complete(Session s) {
        Player a = s.players[0];
        Player b = s.players[1];
        if (!a.isOnline() || !b.isOnline()) {
            cancel(s, "§6[Обмен] §cИгрок вышел — обмен отменён.");
            return;
        }
        String err = recheck(a, b);
        if (err != null) {
            cancel(s, "§6[Обмен] " + err);
            return;
        }
        List<Entry> offerA = s.offers.get(0);
        List<Entry> offerB = s.offers.get(1);
        if (!verify(a, offerA) || !verify(b, offerB)) {
            cancel(s, "§6[Обмен] §cПредметы в инвентаре изменились — обмен отменён.");
            return;
        }
        double taxA = tax(plugin, a);
        double taxB = tax(plugin, b);
        if (echo.getEcho(a) < taxA || echo.getEcho(b) < taxB) {
            cancel(s, "§6[Обмен] §cУ одного из участников не хватает Эхо на налог.");
            return;
        }
        List<ItemStack> toA = stacks(offerB);
        List<ItemStack> toB = stacks(offerA);
        if (!fits(a, offerA, toA)) {
            cancel(s, "§6[Обмен] §cУ игрока " + a.getName() + " не хватает места в инвентаре.");
            return;
        }
        if (!fits(b, offerB, toB)) {
            cancel(s, "§6[Обмен] §cУ игрока " + b.getName() + " не хватает места в инвентаре.");
            return;
        }
        if (taxA > 0 || taxB > 0) {
            if (taxA > 0 && !echo.take(a, taxA)) {
                cancel(s, "§6[Обмен] §cНе удалось списать налог.");
                return;
            }
            if (taxB > 0 && !echo.take(b, taxB)) {
                echo.addEcho(a, taxA); // возврат
                cancel(s, "§6[Обмен] §cНе удалось списать налог.");
                return;
            }
        }

        // --- сама сделка (всё проверено, выполняется атомарно в одном тике) ---
        for (Entry en : offerA) a.getInventory().setItem(en.slot(), null);
        for (Entry en : offerB) b.getInventory().setItem(en.slot(), null);
        a.getInventory().addItem(toA.toArray(new ItemStack[0]));
        b.getInventory().addItem(toB.toArray(new ItemStack[0]));

        plugin.getLogger().info("Обмен: " + a.getName() + " " + describe(toB) + " <-> " + b.getName() + " " + describe(toA)
                + " (налог: " + a.getName() + " " + ru.fatecore.perks.TaxDiscount.fmt(taxA) + ", "
                + b.getName() + " " + ru.fatecore.perks.TaxDiscount.fmt(taxB) + " Эхо)");
        s.finished = true;
        sessions.remove(a.getUniqueId());
        sessions.remove(b.getUniqueId());
        a.closeInventory();
        b.closeInventory();
        a.sendMessage("§6[Обмен] §aОбмен с §e" + b.getName() + " §aзавершён. Налог: §e" + ru.fatecore.perks.TaxDiscount.fmt(taxA) + " Эхо§a.");
        b.sendMessage("§6[Обмен] §aОбмен с §e" + a.getName() + " §aзавершён. Налог: §e" + ru.fatecore.perks.TaxDiscount.fmt(taxB) + " Эхо§a.");
    }

    private String recheck(Player a, Player b) {
        if (Modes.isMinigameWorld(a.getWorld()) || Modes.isMinigameWorld(b.getWorld())) return "§cВ мини-играх обмен недоступен.";
        if (combat.isTagged(a.getUniqueId()) || combat.isTagged(b.getUniqueId())) return "§cВо время боя обмен недоступен.";
        return null;
    }

    private String describe(List<ItemStack> items) {
        StringBuilder sb = new StringBuilder("[");
        for (ItemStack it : items) {
            if (sb.length() > 1) sb.append(", ");
            sb.append(it.getAmount()).append('x').append(it.getType().name());
        }
        return sb.append(']').toString();
    }

    private void cancel(Session s, String message) {
        if (s.finished) return;
        s.finished = true;
        for (Player p : s.players) {
            sessions.remove(p.getUniqueId());
            if (p.isOnline()) {
                p.sendMessage(message);
                p.closeInventory();
            }
        }
    }
}
