package ru.fatecore.stats;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import ru.fatecore.api.IDataStore;
import ru.fatecore.learn.PlaytimeCommand;
import ru.fatecore.learn.PlaytimeTask;
import ru.fatecore.menu.MenuItems;

import java.util.Locale;
import java.util.UUID;

/** /stats [ник] — GUI со статистикой: убийства, смерти, победы, время игры. */
public final class StatsCommand implements CommandExecutor, Listener {
    private static final int SIZE = 27;
    private static final int SLOT_CLOSE = 22;

    private static final class Holder implements InventoryHolder {
        Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    private final StatsService stats;
    private final IDataStore data;

    public StatsCommand(StatsService stats, IDataStore data) {
        this.stats = stats;
        this.data = data;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player viewer)) {
            sender.sendMessage("Только для игроков.");
            return true;
        }
        OfflinePlayer target = viewer;
        if (args.length > 0) {
            Player online = Bukkit.getPlayerExact(args[0]);
            if (online != null) {
                target = online;
            } else {
                OfflinePlayer off = Bukkit.getOfflinePlayerIfCached(args[0]);
                if (off == null || !off.hasPlayedBefore()) {
                    viewer.sendMessage("§cИгрок не найден.");
                    return true;
                }
                target = off;
            }
        }
        open(viewer, target);
        return true;
    }

    private void open(Player viewer, OfflinePlayer target) {
        UUID id = target.getUniqueId();
        String name = target.getName() != null ? target.getName() : "игрок";
        long kills = stats.get(id, StatsService.KILLS);
        long deaths = stats.get(id, StatsService.DEATHS);
        long wins = stats.get(id, StatsService.WINS);
        long minutes = data.getLong(id, PlaytimeTask.KEY, 0);
        String kd = String.format(Locale.US, "%.2f", deaths == 0 ? (double) kills : (double) kills / deaths);

        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, MenuItems.text("&8Статистика: " + name));
        holder.inventory = inv;
        ItemStack filler = MenuItems.filler(Material.BLACK_STAINED_GLASS_PANE);
        for (int i = 0; i < SIZE; i++) inv.setItem(i, filler);

        inv.setItem(10, item(Material.IRON_SWORD, "&cУбийства", "&7Игроков убито: &f" + kills));
        inv.setItem(12, item(Material.SKELETON_SKULL, "&7Смерти", "&7Всего смертей: &f" + deaths, "&7K/D: &f" + kd));
        inv.setItem(14, item(Material.GOLD_BLOCK, "&6Победы", "&7Побед в мини-играх: &f" + wins));
        inv.setItem(16, item(Material.CLOCK, "&aВремя игры", "&7Отыграно: &f" + PlaytimeCommand.format(minutes)));
        inv.setItem(SLOT_CLOSE, item(Material.BARRIER, "&cЗакрыть"));
        viewer.openInventory(inv);
    }

    private static ItemStack item(Material mat, String name, String... lore) {
        return MenuItems.button(mat, name, lore);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == e.getView().getTopInventory() && e.getSlot() == SLOT_CLOSE) {
            e.getWhoClicked().closeInventory();
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
