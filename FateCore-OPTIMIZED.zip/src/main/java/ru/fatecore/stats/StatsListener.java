package ru.fatecore.stats;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

/** Считает смерти игрока и убийства других игроков. */
public final class StatsListener implements Listener {
    private final StatsService stats;

    public StatsListener(StatsService stats) {
        this.stats = stats;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        stats.add(victim.getUniqueId(), StatsService.DEATHS);
        Player killer = victim.getKiller();
        if (killer != null && !killer.equals(victim)) stats.add(killer.getUniqueId(), StatsService.KILLS);
    }
}
