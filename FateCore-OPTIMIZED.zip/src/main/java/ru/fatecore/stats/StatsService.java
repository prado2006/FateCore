package ru.fatecore.stats;

import ru.fatecore.api.IDataStore;

import java.util.UUID;

/** Счётчики статистики игрока (хранятся в players.yml через IDataStore). */
public final class StatsService {
    public static final String KILLS = "stats.kills";
    public static final String DEATHS = "stats.deaths";
    public static final String WINS = "stats.wins";

    private final IDataStore store;

    public StatsService(IDataStore store) {
        this.store = store;
    }

    public long get(UUID id, String key) {
        return store.getLong(id, key, 0);
    }

    public void add(UUID id, String key) {
        store.setLong(id, key, get(id, key) + 1);
    }

    public void addWin(UUID id) {
        add(id, WINS);
    }
}
