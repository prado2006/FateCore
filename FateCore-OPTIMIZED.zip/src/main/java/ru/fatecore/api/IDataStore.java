package ru.fatecore.api;
import java.util.UUID;

public interface IDataStore {
    long getLong(UUID id, String key, long def);
    void setLong(UUID id, String key, long value);
    /** Строковое значение игрока (например, custom_title). Реализация по умолчанию ничего не хранит. */
    default String getString(UUID id, String key, String def) { return def; }
    default void setString(UUID id, String key, String value) {}
    default void save() {}
}
