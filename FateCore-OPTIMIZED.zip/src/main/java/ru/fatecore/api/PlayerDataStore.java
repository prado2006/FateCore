package ru.fatecore.api;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import ru.fatecore.FateCore;
import ru.fatecore.util.YamlStore;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Данные игроков (players.yml). Формат файла прежний: {@code players.<uuid>.<ключ>: значение}.
 * <p>
 * Данные хранятся в памяти в потокобезопасных картах: чтение/запись — O(1) без разбора YAML-путей,
 * безопасно из любого потока (например, PlaceholderAPI). Сериализация и запись файла идут
 * асинхронно (см. {@link YamlStore#flush()}), главный поток не нагружается.
 */
public class PlayerDataStore implements IDataStore {
    private final YamlStore store;
    private final Map<UUID, Map<String, Object>> data = new ConcurrentHashMap<>();
    /** Ключи в players.*, не являющиеся UUID: не используются плагином, но сохраняются в файле как есть. */
    private final Map<String, Map<String, Object>> foreign = new ConcurrentHashMap<>();

    public PlayerDataStore(FateCore plugin) {
        this.store = new YamlStore(plugin, "players.yml");
        load(store.cfg().getConfigurationSection("players"));
        store.useSerializer(this::serialize);
    }

    private void load(ConfigurationSection players) {
        if (players == null) return;
        for (String key : players.getKeys(false)) {
            ConfigurationSection sec = players.getConfigurationSection(key);
            if (sec == null) continue;
            Map<String, Object> values = new ConcurrentHashMap<>();
            for (Map.Entry<String, Object> en : sec.getValues(true).entrySet()) {
                Object v = en.getValue();
                if (v == null || v instanceof ConfigurationSection) continue; // только листья
                values.put(en.getKey(), v);
            }
            if (values.isEmpty()) continue;
            try {
                data.put(UUID.fromString(key), values);
            } catch (IllegalArgumentException e) {
                foreign.put(key, values);
            }
        }
    }

    @Override
    public long getLong(UUID id, String key, long def) {
        Map<String, Object> m = data.get(id);
        if (m == null) return def;
        Object v = m.get(key);
        return v instanceof Number n ? n.longValue() : def;
    }

    @Override
    public void setLong(UUID id, String key, long value) {
        data.computeIfAbsent(id, k -> new ConcurrentHashMap<>()).put(key, value);
        store.dirty();
    }

    @Override
    public String getString(UUID id, String key, String def) {
        Map<String, Object> m = data.get(id);
        if (m == null) return def;
        Object v = m.get(key);
        return v != null ? v.toString() : def;
    }

    @Override
    public void setString(UUID id, String key, String value) {
        if (value == null) { // null удаляет ключ
            Map<String, Object> m = data.get(id);
            if (m != null) m.remove(key);
        } else {
            data.computeIfAbsent(id, k -> new ConcurrentHashMap<>()).put(key, value);
        }
        store.dirty();
    }

    /** Формирует содержимое players.yml (вызывается в потоке записи). */
    private String serialize() {
        YamlConfiguration out = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, Object>> player : data.entrySet()) {
            for (Map.Entry<String, Object> en : player.getValue().entrySet()) {
                out.set("players." + player.getKey() + "." + en.getKey(), en.getValue());
            }
        }
        for (Map.Entry<String, Map<String, Object>> other : foreign.entrySet()) {
            for (Map.Entry<String, Object> en : other.getValue().entrySet()) {
                out.set("players." + other.getKey() + "." + en.getKey(), en.getValue());
            }
        }
        return out.saveToString();
    }

    /** Синхронное сохранение (onDisable). Обычное автосохранение идёт асинхронно через YamlStore.flush(). */
    @Override
    public void save() {
        store.flushNow();
    }
}
