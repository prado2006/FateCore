package ru.fatecore.onboarding;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Защита от ботов: при входе открывается GUI на 27 слотов с часами «Я не робот» в слоте 13.
 * Пока игрок не нажал, движение, чат и команды заблокированы (закрыть меню тоже нельзя — оно откроется снова).
 * Нажал — меню закрывается, блокировки снимаются, игрок вводит /login.
 * Не нажал за antibot.timeout-seconds (30) — кик.
 * Настройки: antibot.* в config.yml (enabled, timeout-seconds, bypass-permission).
 */
public final class AntiBotListener implements Listener {

    private static final int SIZE = 27;
    private static final int SLOT_CLOCK = 13;
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();
    private static final Component TITLE = LEGACY.deserialize("§8Проверка: вы не робот?");
    private static final Component KICK_REASON = LEGACY.deserialize("§cПроверка не пройдена.");
    private static final Component EMPTY_NAME = LEGACY.deserialize("§r");
    private static final Component CLOCK_NAME = LEGACY.deserialize("§a§lЯ не робот (Нажми)");

    private static final class Holder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    private final Plugin plugin;
    /** Игроки, не прошедшие проверку, и их задачи-кики. */
    private final Map<UUID, BukkitTask> pending = new ConcurrentHashMap<>();
    /** Предметы GUI создаются один раз (инвентарь копирует их при setItem). */
    private ItemStack filler;
    private ItemStack clock;

    public AntiBotListener(Plugin plugin) {
        this.plugin = plugin;
    }

    public boolean isPending(Player p) {
        return pending.containsKey(p.getUniqueId());
    }

    // ---------- вход / выход ----------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        if (!plugin.getConfig().getBoolean("antibot.enabled", true)) return;
        Player p = e.getPlayer();
        String bypass = plugin.getConfig().getString("antibot.bypass-permission", "fatecore.antibot.bypass");
        if (bypass != null && !bypass.isEmpty() && p.hasPermission(bypass)) return;

        long ticks = Math.max(1, plugin.getConfig().getInt("antibot.timeout-seconds", 30)) * 20L;
        BukkitTask kick = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (pending.remove(p.getUniqueId()) != null && p.isOnline()) {
                p.kick(KICK_REASON);
            }
        }, ticks);
        BukkitTask old = pending.put(p.getUniqueId(), kick);
        if (old != null) old.cancel();

        Bukkit.getScheduler().runTask(plugin, () -> openGui(p));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        BukkitTask t = pending.remove(e.getPlayer().getUniqueId());
        if (t != null) t.cancel();
    }

    private void openGui(Player p) {
        if (!p.isOnline() || !isPending(p)) return;
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.inventory = inv;

        if (filler == null) {
            filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
            filler.editMeta(m -> m.displayName(EMPTY_NAME));
            clock = new ItemStack(Material.CLOCK);
            clock.editMeta(m -> m.displayName(CLOCK_NAME));
        }
        for (int i = 0; i < SIZE; i++) inv.setItem(i, filler);
        inv.setItem(SLOT_CLOCK, clock);

        p.openInventory(inv);
    }

    private void pass(Player p) {
        BukkitTask t = pending.remove(p.getUniqueId());
        if (t == null) return;
        t.cancel();
        p.closeInventory();
        p.sendMessage("§aПроверка пройдена! Введите /login.");
    }

    // ---------- GUI ----------

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        if (e.getSlot() == SLOT_CLOCK && e.getCurrentItem() != null && e.getCurrentItem().getType() == Material.CLOCK) {
            pass(p);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    /** Закрыл меню, не нажав на часы, — открываем снова. */
    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder)) return;
        if (!(e.getPlayer() instanceof Player p) || !isPending(p)) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> openGui(p), 2L);
    }

    // ---------- блокировки до прохождения проверки ----------

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (pending.isEmpty() || !isPending(e.getPlayer())) return; // самый частый event сервера
        if (e.getTo() == null) return;
        if (e.getFrom().getX() != e.getTo().getX() || e.getFrom().getY() != e.getTo().getY()
                || e.getFrom().getZ() != e.getTo().getZ()) {
            e.setCancelled(true);
        }
    }

    /** Только отменяет сообщение, формат чата и префиксы не трогает. */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        if (!pending.isEmpty() && isPending(e.getPlayer())) {
            e.setCancelled(true);
            e.getPlayer().sendMessage("§cСначала нажмите «Я не робот».");
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!pending.isEmpty() && isPending(e.getPlayer())) {
            e.setCancelled(true);
            e.getPlayer().sendMessage("§cСначала нажмите «Я не робот».");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!pending.isEmpty() && e.getEntity() instanceof Player p && isPending(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (!pending.isEmpty() && isPending(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (!pending.isEmpty() && isPending(e.getPlayer())) e.setCancelled(true);
    }
}
