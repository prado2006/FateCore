package ru.fatecore.learn;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import ru.fatecore.combat.CombatManager;

/**
 * Группа Premium и выше (право fatecore.tpa.bypass): /tpa телепортирует к игроку мгновенно, без запроса.
 * Не работает в мини-играх (BedWars/SkyWars — донат не влияет) и в бою: тогда обычный /tpa обрабатывается как есть.
 */
public final class TpaBypassListener implements Listener {
    private final org.bukkit.plugin.Plugin plugin;
    private final CombatManager combat;

    public TpaBypassListener(org.bukkit.plugin.Plugin plugin, CombatManager combat) {
        this.plugin = plugin;
        this.combat = combat;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        String msg = e.getMessage().toLowerCase();
        if (!(msg.startsWith("/tpa ") || msg.startsWith("/essentials:tpa "))) return;
        if (!p.hasPermission("fatecore.tpa.bypass")) return;
        if (combat.isTagged(p.getUniqueId()) || ru.fatecore.perks.PerkListener.isRestricted(plugin, p.getWorld())) return;

        String[] args = e.getMessage().trim().split("\\s+");
        if (args.length < 2) return;
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null || !target.isOnline() || target.equals(p)) return;
        if (combat.isTagged(target.getUniqueId()) || ru.fatecore.perks.PerkListener.isRestricted(plugin, target.getWorld())) return;

        p.teleport(target.getLocation());
        p.sendMessage("§a[Premium] Вы мгновенно телепортировались к §e" + target.getName());
        e.setCancelled(true);
    }
}
