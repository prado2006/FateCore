package ru.fatecore.learn;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import ru.fatecore.FateCore;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.gui.FateHolder;
import ru.fatecore.perks.HomeBonus;
import ru.fatecore.util.Items;
import ru.fatecore.util.Msg;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * МОДУЛЬ 10 — /shop: GUI 27 слотов, категории и товары из learn.shop, оплата Эхо через Vault (EssentialsX).
 * Выдача: команды консоли из shop.rewards.<id>; если список пуст — встроенная выдача.
 * Донат-тиры через магазин не выдаются (команды с «parent» пропускаются).
 */
public final class ShopGui {

    private record Category(String key, int slot, String title, Material icon) {}

    private record Item(String id, String category, String name, Material mat, int price, int slot, boolean enabled) {}

    /**
     * Запрещённое в консольных наградах shop.rewards: выдача рангов/групп, op, wildcard-права,
     * управление сервером. Разрешены только узкие права-косметика (lp user ... permission set fatecore.cosmetic.*).
     */
    private static final Pattern FORBIDDEN = Pattern.compile(
            "(?i)\\b(parent|group|op|deop|stop|restart|reload|ban|ban-ip|pardon|sudo|execute|pex|permissions)\\b|\\*");

    private final FateCore plugin;
    private final EchoManager echo;
    private final HomeBonus homeBonus;
    private java.util.function.Consumer<Player> purchaseHook;

    public ShopGui(FateCore plugin, EchoManager echo) {
        this.plugin = plugin;
        this.echo = echo;
        this.homeBonus = new HomeBonus(plugin);
    }

    /** Вызывается после успешной покупки (для достижения «первая покупка»). */
    public void setPurchaseHook(java.util.function.Consumer<Player> hook) {
        this.purchaseHook = hook;
    }

    // ---------- чтение learn.shop (разбор и предметы кэшируются до перезагрузки конфига) ----------

    /** Разобранный learn.shop и готовые предметы. Пересобирается, когда reloadConfig() подменяет объект конфигурации. */
    private static final class Snapshot {
        final FileConfiguration cfg;
        final String title;
        final List<Category> categories = new ArrayList<>();
        final List<ItemStack> categoryIcons = new ArrayList<>();
        final List<Item> items = new ArrayList<>();
        final List<ItemStack> itemIcons = new ArrayList<>();

        Snapshot(FileConfiguration cfg) {
            this.cfg = cfg;
            this.title = cfg.getString("learn.shop.title", "&8Магазин Эхо");
        }
    }

    private Snapshot snapshot;

    private Snapshot snap() {
        FileConfiguration cfg = plugin.getConfig();
        Snapshot s = snapshot;
        if (s == null || s.cfg != cfg) {
            s = build(cfg);
            snapshot = s;
        }
        return s;
    }

    private Snapshot build(FileConfiguration cfg) {
        Snapshot s = new Snapshot(cfg);

        ConfigurationSection cs = cfg.getConfigurationSection("learn.shop.categories");
        if (cs != null) {
            for (String key : cs.getKeys(false)) {
                ConfigurationSection c = cs.getConfigurationSection(key);
                if (c == null) continue;
                Material icon = Material.matchMaterial(c.getString("icon", "CHEST"));
                Category cat = new Category(key, c.getInt("slot"), c.getString("title", key),
                        icon == null ? Material.CHEST : icon);
                s.categories.add(cat);
                s.categoryIcons.add(Items.make(cat.icon(), "&6" + cat.title(), "&eКлик — открыть"));
            }
        }

        for (Map<?, ?> m : cfg.getMapList("learn.shop.items")) {
            Material mat = Material.matchMaterial(String.valueOf(m.get("icon")));
            Object price = m.get("price");
            Object slot = m.get("slot");
            if (mat == null || !(price instanceof Number) || !(slot instanceof Number)) {
                plugin.getLogger().warning("learn.shop.items: пропущен товар с неверными полями: " + m);
                continue;
            }
            Object en = m.get("enabled");
            Item it = new Item(String.valueOf(m.get("id")), String.valueOf(m.get("category")),
                    String.valueOf(m.get("name")), mat, ((Number) price).intValue(),
                    ((Number) slot).intValue(), !(en instanceof Boolean b) || b);
            s.items.add(it);
            s.itemIcons.add(it.enabled()
                    ? Items.make(it.mat(), "&6" + it.name(),
                            "&7Цена: &f" + it.price() + " Эхо",
                            "&eКлик — купить",
                            "&8Эхо не даёт силы в бою")
                    : Items.make(Material.GRAY_DYE, "&7" + it.name(),
                            "&cВременно недоступен"));
        }
        return s;
    }

    // ---------- GUI ----------

    public void openMain(Player p) {
        Snapshot s = snap();
        FateHolder holder = new FateHolder("shop");
        Inventory inv = Bukkit.createInventory(holder, 27, Msg.c(s.title));
        holder.bind(inv);
        Items.fill(inv);
        for (int i = 0; i < s.categories.size(); i++) {
            inv.setItem(s.categories.get(i).slot(), s.categoryIcons.get(i));
        }
        inv.setItem(22, Items.make(Material.GOLD_INGOT, "&6Твоё Эхо: &f" + echo.format(echo.getEcho(p)))); // баланс — живое значение
        inv.setItem(26, Items.closeButton());
        p.openInventory(inv);
    }

    private void openCategory(Player p, Category cat) {
        Snapshot s = snap();
        FateHolder holder = new FateHolder("shop:" + cat.key());
        Inventory inv = Bukkit.createInventory(holder, 27, Msg.c("&8Магазин: " + cat.title()));
        holder.bind(inv);
        Items.fill(inv);
        for (int i = 0; i < s.items.size(); i++) {
            Item it = s.items.get(i);
            if (it.category().equals(cat.key())) inv.setItem(it.slot(), s.itemIcons.get(i));
        }
        inv.setItem(22, backButton());
        inv.setItem(26, Items.closeButton());
        p.openInventory(inv);
    }

    private ItemStack back;

    private ItemStack backButton() {
        ItemStack b = back;
        if (b == null) back = b = Items.make(Material.ARROW, "&7Назад");
        return b;
    }

    public void handleMain(Player p, int slot) {
        if (slot == 26) {
            p.closeInventory();
            return;
        }
        for (Category c : snap().categories) {
            if (c.slot() == slot) {
                openCategory(p, c);
                return;
            }
        }
    }

    public void handleCategory(Player p, String catKey, int slot) {
        if (slot == 26) {
            p.closeInventory();
            return;
        }
        if (slot == 22) {
            openMain(p);
            return;
        }
        for (Item it : snap().items) {
            if (it.category().equals(catKey) && it.slot() == slot) {
                purchase(p, it);
                return;
            }
        }
    }

    // ---------- покупка ----------

    private void purchase(Player p, Item item) {
        if (!item.enabled()) {
            Msg.send(p, "&cТовар временно недоступен.");
            return;
        }
        if (item.id().equals("home_plus1") && plugin.getConfig().getStringList("shop.rewards.home_plus1").isEmpty()
                && !homeBonus.canGrant(p)) {
            Msg.send(p, "&cМаксимум домов уже достигнут.");
            return;
        }
        if (!echo.take(p, item.price())) {
            Msg.send(p, "&cНе хватает Эхо: нужно " + item.price() + ", у тебя " + echo.format(echo.getEcho(p)));
            return;
        }
        try {
            deliver(p, item);
            Msg.send(p, "&aКуплено: &6" + item.name() + " &7(-" + item.price() + " Эхо)");
            if (purchaseHook != null) purchaseHook.accept(p);
        } catch (Exception e) {
            echo.addEcho(p, item.price());
            Msg.send(p, "&cОшибка выдачи, Эхо возвращено.");
            plugin.getLogger().warning("Shop deliver " + item.id() + ": " + e.getMessage());
        }
    }

    private void deliver(Player p, Item item) {
        List<String> cmds = plugin.getConfig().getStringList("shop.rewards." + item.id());
        if (!cmds.isEmpty()) {
            runCommands(p, cmds);
            return;
        }
        switch (item.id()) {
            case "rename" -> Items.give(p, Items.make(Material.NAME_TAG, "&6Бирка переименования",
                    "&7Переименуй предмет на наковальне"));
            case "case_common" -> Items.give(p, CaseItems.make(plugin, false));
            case "case_rare" -> Items.give(p, CaseItems.make(plugin, true));
            case "boost_x2" -> echo.addBoost(p.getUniqueId(), 2.0, 3600);
            case "home_plus1" -> {
                if (!homeBonus.grant(p)) throw new IllegalStateException("лимит домов достигнут");
            }
            default -> throw new IllegalStateException("нет награды для " + item.id());
        }
    }

    private void runCommands(Player p, List<String> cmds) {
        for (String c : cmds) {
            String line = c.replace("%player%", p.getName());
            if (FORBIDDEN.matcher(line).find()) {
                plugin.getLogger().warning("Shop: запрещённая команда пропущена: " + line);
                continue;
            }
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), line);
        }
    }
}
