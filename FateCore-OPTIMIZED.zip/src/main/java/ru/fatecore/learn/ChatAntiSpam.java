package ru.fatecore.learn;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public final class ChatAntiSpam implements Listener {
    private final Map<UUID, Long> lastMessageTime = new ConcurrentHashMap<>();
    private final Map<UUID, String> lastMessage = new ConcurrentHashMap<>();

    private static final long COOLDOWN_MS = 1500;

    private static final Pattern URL_PATTERN = Pattern.compile(
            "(?i)\\b(?:https?:\\/\\/|www\\.)\\S+|(?i)\\b\\S+\\.(?:com|ru|net|org|io|me|tv|gg|xyz|link|site)\\b"
    );

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        String message = PlainTextComponentSerializer.plainText().serialize(e.message()).toLowerCase().trim();

        long now = System.currentTimeMillis();
        Long lastTime = lastMessageTime.get(id);
        String lastMsg = lastMessage.get(id);

        // regex может сработать только на тексте с точкой или «://»; право проверяем лишь для подозрительных сообщений
        if (looksLikeLink(message) && URL_PATTERN.matcher(message).find() && !p.hasPermission("fatecore.chat.links")) {
            e.setCancelled(true);
            p.sendMessage("§cСсылки в чате запрещены! Реклама и фишинг будут наказаны баном.");
            return;
        }

        if (lastTime != null && now - lastTime < COOLDOWN_MS) {
            e.setCancelled(true);
            p.sendMessage("§cНе так быстро! Подождите немного перед отправкой сообщения.");
            return;
        }

        if (lastMsg != null && lastMsg.equals(message)) {
            e.setCancelled(true);
            p.sendMessage("§cНе повторяйте одно и то же сообщение!");
            return;
        }

        lastMessageTime.put(id, now);
        lastMessage.put(id, message);
    }

    private static boolean looksLikeLink(String message) {
        return message.indexOf('.') >= 0 || message.contains("://");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        lastMessageTime.remove(e.getPlayer().getUniqueId());
        lastMessage.remove(e.getPlayer().getUniqueId());
    }
}
