package ru.fatecore.learn;

import fr.xephi.authme.events.LoginEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;

import java.util.function.Consumer;

/**
 * После успешной авторизации AuthMe (ввод пароля или вход после регистрации):
 * отправляет ВСЕМУ серверу сообщение join-message.text и вызывает afterLogin.
 * Обычное сообщение о входе скрывается (join-message.hide-vanilla), чтобы игроки видели одно, настоящее.
 */
public final class AuthMeLoginBridge implements Listener {
    private final Plugin plugin;
    private final Consumer<Player> afterLogin;

    public AuthMeLoginBridge(Plugin plugin, Consumer<Player> afterLogin) {
        this.plugin = plugin;
        this.afterLogin = afterLogin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onJoin(PlayerJoinEvent e) {
        FileConfiguration c = plugin.getConfig();
        if (c.getBoolean("join-message.enabled", true) && c.getBoolean("join-message.hide-vanilla", true)) {
            e.joinMessage(null);
        }
    }

    @EventHandler
    public void onLogin(LoginEvent e) {
        Player p = e.getPlayer();
        FileConfiguration c = plugin.getConfig();
        if (c.getBoolean("join-message.enabled", true)) {
            String text = c.getString("join-message.text", "&e[+] Игрок &f%player% &eприсоединился к серверу!")
                    .replace("%player%", p.getName()).replace('§', '&');
            Bukkit.getServer().sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(text));
        }
        afterLogin.accept(p);
    }
}
