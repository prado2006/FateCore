package ru.fatecore.learn;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;
import ru.fatecore.api.IDataStore;
import ru.fatecore.echo.EchoManager;

/**
 * Достижения: первый вход, первая покупка в /shop, первый выполненный квест.
 * Каждое даёт §6§l[Достижение!] и achievements.reward-echo (50) Эхо один раз; флаг хранится в IDataStore
 * (ключи ach.join / ach.shop / ach.quest). Только Эхо, звуков нет, донат-группы не выдаются.
 *
 * Первый вход: при AuthMe засчитывается после авторизации (onFirstJoin вызывает мост AuthMe),
 * без AuthMe — по PlayerJoinEvent.
 */
public final class AchievementListener implements Listener {
    private static final String K_JOIN = "ach.join";
    private static final String K_SHOP = "ach.shop";
    private static final String K_QUEST = "ach.quest";

    private final Plugin plugin;
    private final EchoManager echo;
    private final IDataStore store;

    public AchievementListener(Plugin plugin, EchoManager echo, IDataStore store) {
        this.plugin = plugin;
        this.echo = echo;
        this.store = store;
    }

    /** Только если AuthMe не установлен (иначе первый вход засчитывает onFirstJoin после /login). */
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) onFirstJoin(p);
        }, 40L);
    }

    public void onFirstJoin(Player p) {
        award(p, K_JOIN, "Первый вход на сервер!");
    }

    public void onFirstPurchase(Player p) {
        award(p, K_SHOP, "Первая покупка в магазине!");
    }

    public void onFirstQuest(Player p) {
        award(p, K_QUEST, "Первый выполненный квест!");
    }

    private void award(Player p, String key, String text) {
        if (store.getLong(p.getUniqueId(), key, 0) != 0) return;
        store.setLong(p.getUniqueId(), key, 1);
        double reward = plugin.getConfig().getDouble("achievements.reward-echo", 50);
        echo.addEcho(p, reward);
        p.sendMessage("§6§l[Достижение!] §e" + text + " §7+" + echo.format(reward) + " Эхо");
    }
}
