package ru.fatecore.chat;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import ru.fatecore.api.IDataStore;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * /title set <текст> и /title clear — кастомный титул донатера (право fatecore.title.use).
 * Максимум 16 символов, без цветовых кодов, с фильтром config.yml → chat-banned-words.
 * Титул хранится в IDataStore (ключ custom_title); для чата (асинхронного потока) держится кэш в памяти.
 */
public final class TitleCommand implements CommandExecutor {
    public static final String KEY = "custom_title";
    public static final String PERMISSION = "fatecore.title.use";
    public static final int MAX_LENGTH = 16;

    private final Plugin plugin;
    private final IDataStore store;
    private final Map<UUID, String> cache = new ConcurrentHashMap<>();

    public TitleCommand(Plugin plugin, IDataStore store) {
        this.plugin = plugin;
        this.store = store;
        for (Player p : Bukkit.getOnlinePlayers()) load(p);
    }

    /** Загружает титул игрока в кэш (вызывать из основного потока, например при входе). */
    public void load(Player p) {
        String t = store.getString(p.getUniqueId(), KEY, null);
        if (t == null || t.isBlank()) cache.remove(p.getUniqueId());
        else cache.put(p.getUniqueId(), t);
    }

    public void unload(UUID id) {
        cache.remove(id);
    }

    /** Титул из кэша (безопасно вызывать из любого потока); null — титула нет. */
    public String titleOf(UUID id) {
        return cache.get(id);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Только для игроков.");
            return true;
        }
        if (!p.hasPermission(PERMISSION)) {
            p.sendMessage("§cУ вас нет прав!");
            return true;
        }
        if (args.length == 0) {
            p.sendMessage("§7Использование: §e/title set <текст> §7(до " + MAX_LENGTH + " символов) §7или §e/title clear");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "clear" -> {
                store.setString(p.getUniqueId(), KEY, null);
                cache.remove(p.getUniqueId());
                p.sendMessage("§aТитул сброшен.");
            }
            case "set" -> {
                if (args.length < 2) {
                    p.sendMessage("§7Использование: §e/title set <текст>");
                    return true;
                }
                String text = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).trim();
                if (text.isEmpty()) {
                    p.sendMessage("§7Использование: §e/title set <текст>");
                    return true;
                }
                if (text.indexOf('&') >= 0 || text.indexOf('§') >= 0) {
                    p.sendMessage("§cЦветовые коды в титуле использовать нельзя.");
                    return true;
                }
                if (text.length() > MAX_LENGTH) {
                    p.sendMessage("§cТитул слишком длинный: максимум " + MAX_LENGTH + " символов.");
                    return true;
                }
                if (containsBanned(text)) {
                    p.sendMessage("§cЭтот титул содержит запрещенные слова!");
                    return true;
                }
                store.setString(p.getUniqueId(), KEY, text);
                cache.put(p.getUniqueId(), text);
                p.sendMessage("§aТитул установлен: §6[" + text + "]");
            }
            default -> p.sendMessage("§7Использование: §e/title set <текст> §7или §e/title clear");
        }
        return true;
    }

    /** Проверка по config.yml → chat-banned-words (регистр, пробелы, знаки и похожие латинские буквы не обходят фильтр). */
    private boolean containsBanned(String text) {
        List<String> words = plugin.getConfig().getStringList("chat-banned-words");
        String t = normalize(text);
        for (String w : words) {
            String n = normalize(w);
            if (!n.isEmpty() && t.contains(n)) return true;
        }
        return false;
    }

    private static String normalize(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toLowerCase(Locale.ROOT).toCharArray()) {
            if (c == 'ё') c = 'е';
            switch (c) { // латиница, похожая на кириллицу -> кириллица
                case 'a' -> c = 'а';
                case 'e' -> c = 'е';
                case 'o', '0' -> c = 'о';
                case 'p' -> c = 'р';
                case 'c' -> c = 'с';
                case 'x' -> c = 'х';
                case 'y' -> c = 'у';
                default -> { }
            }
            if (Character.isLetterOrDigit(c)) sb.append(c);
        }
        return sb.toString();
    }
}
