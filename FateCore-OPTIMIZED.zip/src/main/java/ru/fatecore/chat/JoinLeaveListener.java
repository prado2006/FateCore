package ru.fatecore.chat;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** Красивые сообщения о входе и выходе вместо стандартных. */
public final class JoinLeaveListener implements Listener {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onJoin(PlayerJoinEvent e) {
        e.joinMessage(null); // отменяем стандартное сообщение
        Bukkit.getServer().sendMessage(LEGACY.deserialize(
                "§a[+] §7Игрок §f" + e.getPlayer().getName() + " §7присоединился к игре!"));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onQuit(PlayerQuitEvent e) {
        e.quitMessage(null); // отменяем стандартное сообщение
        Bukkit.getServer().sendMessage(LEGACY.deserialize(
                "§c[-] §7Игрок §f" + e.getPlayer().getName() + " §7покинул игру."));
    }
}
