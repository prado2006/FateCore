package ru.fatecore.chat;

import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Формат чата для игроков с кастомным титулом и правом fatecore.title.use:
 *   §6[Титул] §r[Префикс LuckPerms] Ник: Сообщение
 * Если титула или права нет, событие НЕ трогается — чат остаётся стандартным (префиксы LuckPerms/Essentials).
 */
public final class ChatListener implements Listener {
    private static final LegacyComponentSerializer SECTION = LegacyComponentSerializer.legacySection();
    private static final LegacyComponentSerializer AMP = LegacyComponentSerializer.legacyAmpersand();

    private final TitleCommand titles;

    public ChatListener(TitleCommand titles) {
        this.titles = titles;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        titles.load(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        titles.unload(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        String title = titles.titleOf(p.getUniqueId());
        if (title == null || !p.hasPermission(TitleCommand.PERMISSION)) return;

        Component head = SECTION.deserialize("§6[" + title + "] §r");
        Component prefix = prefix(p);
        e.renderer(ChatRenderer.viewerUnaware((source, displayName, message) -> {
            Component line = head;
            if (prefix != null) line = line.append(prefix);
            return line.append(Component.text(source.getName() + ": ")).append(message);
        }));
    }

    /** Префикс из LuckPerms (&-коды), с одним пробелом на конце; null — префикса нет. */
    private static Component prefix(Player p) {
        try {
            User user = LuckPermsProvider.get().getUserManager().getUser(p.getUniqueId());
            if (user == null) return null;
            String prefix = user.getCachedData().getMetaData().getPrefix();
            if (prefix == null || prefix.isBlank()) return null;
            return AMP.deserialize(prefix.replace('§', '&').stripTrailing() + " ");
        } catch (IllegalStateException ex) {
            return null;
        }
    }
}
