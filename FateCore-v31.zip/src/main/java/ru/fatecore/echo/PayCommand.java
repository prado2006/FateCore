package ru.fatecore.echo;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import ru.fatecore.FateCore;
import ru.fatecore.api.IDataStore;
import ru.fatecore.perks.Access;
import ru.fatecore.quest.QuestManager;
import ru.fatecore.util.Msg;

import java.time.LocalDate;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * /pay <ник> <сумма> — перевод Эхо между игроками с жёсткими дневными лимитами (защита от фарма через твинков).
 * Команда перехватывается через PlayerCommandPreprocessEvent, поэтому заменяет /pay из EssentialsX независимо
 * от порядка загрузки плагинов.
 *
 * Правила:
 *  - economy.pay-send-limit    — максимум Эхо, которое игрок может ОТПРАВИТЬ за сутки (по умолчанию 2000);
 *  - economy.pay-receive-limit — максимум Эхо, которое игрок может ПОЛУЧИТЬ через /pay за сутки (по умолчанию 5000);
 *  - 0 в настройке = без лимита; сброс счётчиков в 00:00 по МСК;
 *  - перевод самому себе запрещён; сумма только целая и положительная; получатель должен быть онлайн;
 *  - доступ: право fatecore.pay ИЛИ привилегия не ниже command-tiers.pay (Странник); OP проходит проверку доступа;
 *  - лимиты действуют на всех, включая OP; пропускает их только явное право fatecore.pay.bypass.
 */
public final class PayCommand implements Listener {
    private static final Set<String> LABELS = Set.of("pay", "epay", "essentials:pay", "essentials:epay");

    private static final String K_SENT_DAY = "pay_sent_day";
    private static final String K_SENT = "pay_sent";
    private static final String K_RECV_DAY = "pay_recv_day";
    private static final String K_RECV = "pay_recv";

    private final FateCore plugin;
    private final EchoManager echo;
    private final IDataStore data;

    public PayCommand(FateCore plugin, EchoManager echo, IDataStore data) {
        this.plugin = plugin;
        this.echo = echo;
        this.data = data;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String msg = e.getMessage().trim();
        if (msg.length() < 2) return;
        String[] parts = msg.substring(1).split("\\s+");
        if (!LABELS.contains(parts[0].toLowerCase(Locale.ROOT))) return;
        e.setCancelled(true); // /pay из Essentials не выполняется — вся логика здесь
        try {
            pay(e.getPlayer(), parts);
        } catch (RuntimeException ex) {
            Msg.send(e.getPlayer(), "&cОшибка перевода. Эхо не списано, сообщите администратору.");
            plugin.getLogger().warning("/pay: " + ex);
        }
    }

    private void pay(Player p, String[] parts) {
        if (!Access.check(plugin, p, "pay")) return;
        if (parts.length != 3) {
            Msg.send(p, "&7Использование: &e/pay <ник> <сумма>");
            return;
        }
        long amount = parseAmount(parts[2]);
        if (amount <= 0) {
            Msg.send(p, "&cСумма должна быть целым положительным числом.");
            return;
        }
        if (parts[1].equalsIgnoreCase(p.getName())) {
            Msg.send(p, "&cНельзя переводить Эхо самому себе.");
            return;
        }
        Player target = Bukkit.getPlayerExact(parts[1]);
        if (target == null) {
            Msg.send(p, "&cИгрок &e" + parts[1] + " &cне в сети.");
            return;
        }
        if (target.getUniqueId().equals(p.getUniqueId())) {
            Msg.send(p, "&cНельзя переводить Эхо самому себе.");
            return;
        }

        boolean bypass = p.hasPermission("fatecore.pay.bypass"); // не Cmd.can: лимиты касаются и OP
        long sendLimit = bypass ? 0 : limit("economy.pay-send-limit", 2000);
        long recvLimit = limit("economy.pay-receive-limit", 5000);
        long sent = used(p.getUniqueId(), K_SENT_DAY, K_SENT);
        long received = used(target.getUniqueId(), K_RECV_DAY, K_RECV);

        if (sendLimit > 0) {
            if (sent >= sendLimit) {
                p.sendMessage("§cВы достигли дневного лимита на переводы/получение Эхо (" + sent + "/" + sendLimit
                        + "). Сброс в 00:00.");
                return;
            }
            if (sent + amount > sendLimit) {
                p.sendMessage("§cПеревод превышает дневной лимит (" + sent + "/" + sendLimit + "). Можно отправить ещё: §e"
                        + (sendLimit - sent) + " Эхо§c. Сброс в 00:00.");
                return;
            }
        }
        if (recvLimit > 0 && received + amount > recvLimit) {
            p.sendMessage("§cПолучатель достиг дневного лимита на получение Эхо и не может принять этот перевод. Сброс в 00:00.");
            return;
        }
        if (!echo.take(p, amount)) {
            Msg.send(p, "&cНе хватает Эхо: нужно " + amount + ", у тебя " + echo.format(echo.getEcho(p)) + ".");
            return;
        }
        try {
            echo.addEcho(target, (double) amount);
        } catch (RuntimeException ex) {
            echo.addEcho(p, (double) amount); // возврат отправителю
            throw ex;
        }
        data.setLong(p.getUniqueId(), K_SENT, sent + amount);
        data.setLong(target.getUniqueId(), K_RECV, received + amount);

        String left = sendLimit > 0 ? " §7(сегодня отправлено: " + (sent + amount) + "/" + sendLimit + ")" : "";
        p.sendMessage("§aВы перевели §e" + amount + " Эхо §aигроку §e" + target.getName() + "§a." + left);
        target.sendMessage("§aИгрок §e" + p.getName() + " §aперевёл вам §e" + amount + " Эхо§a.");
        plugin.getLogger().info("[pay] " + p.getName() + " -> " + target.getName() + ": " + amount);
    }

    private long limit(String path, long def) {
        return Math.max(0, plugin.getConfig().getLong(path, def));
    }

    /** Сумма за сутки (счётчик обнуляется при смене даты по МСК). */
    private long used(UUID id, String dayKey, String usedKey) {
        long today = LocalDate.now(QuestManager.MSK).toEpochDay();
        if (data.getLong(id, dayKey, -1) != today) {
            data.setLong(id, dayKey, today);
            data.setLong(id, usedKey, 0);
        }
        return data.getLong(id, usedKey, 0);
    }

    /** Только цифры, до 9 знаков; иначе -1. */
    private static long parseAmount(String s) {
        if (s.isEmpty() || s.length() > 9) return -1;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) < '0' || s.charAt(i) > '9') return -1;
        }
        return Long.parseLong(s);
    }
}
