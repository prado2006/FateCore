package ru.fatecore.echo;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import ru.fatecore.FateCore;
import ru.fatecore.util.YamlStore;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** МОДУЛЬ 2 — Эхо: баланс живёт в Vault-экономике (EssentialsX), своей экономики нет. */
public final class EchoManager {
    private final Economy eco;
    private final YamlStore boosts;

    public EchoManager(FateCore plugin, Economy eco) {
        this.eco = eco;
        this.boosts = new YamlStore(plugin, "boosts.yml");
    }

    /** Эхо — целая валюта: дробная часть баланса (старые данные) в отображении отбрасывается. */
    public double getEcho(OfflinePlayer p) {
        return Math.floor(eco.getBalance(p) + 1e-9);
    }

    /** Приводит баланс к целому, если в Vault остался дробный хвост (например, 133.8 -> 133). */
    private void normalize(OfflinePlayer p) {
        double bal = eco.getBalance(p);
        double frac = bal - Math.floor(bal + 1e-9);
        if (frac > 1e-6 && frac < 1 - 1e-6) eco.withdrawPlayer(p, frac);
    }

    public void addEcho(OfflinePlayer p, int amount) {
        addEcho(p, (double) amount);
    }

    /** Начисляет Эхо, округляя до целого (Math.round). Значения меньше 0.5 не начисляются. */
    public void addEcho(OfflinePlayer p, double amount) {
        long whole = Math.round(amount);
        if (whole <= 0) return;
        eco.depositPlayer(p, whole);
        normalize(p);
    }

    /** Списывает Эхо (сумма округляется до целого); false, если не хватает. */
    public boolean take(Player p, double amount) {
        long whole = Math.round(amount);
        if (whole < 0) return false;
        normalize(p);
        if (!eco.has(p, whole)) return false;
        return eco.withdrawPlayer(p, whole).transactionSuccess();
    }

    /** Множитель для показа: x1.5, x3, x3.25 (без лишних нулей). */
    public static String formatMult(double m) {
        String s = String.format(Locale.US, "%.2f", m);
        s = s.indexOf('.') >= 0 ? s.replaceAll("0+$", "").replaceAll("\\.$", "") : s;
        return s;
    }

    /** Целое число без дробной части (Эхо — целая валюта). */
    public String format(double v) {
        return String.valueOf(Math.round(v));
    }

    // ---- временные множители Эхо (формат записи "множитель:до_мс") ----

    public void addBoost(UUID id, double multiplier, long seconds) {
        List<String> list = active(id);
        list.add(multiplier + ":" + (System.currentTimeMillis() + seconds * 1000L));
        boosts.cfg().set(id.toString(), list);
        boosts.dirty();
    }

    /** Суммарная ДОБАВКА активных бустов: Σ(множитель − 1). Два x1.5 дают +1.0 (а не x2.25). */
    public double boostBonus(UUID id) {
        double bonus = 0.0;
        for (String entry : active(id)) {
            try {
                bonus += Double.parseDouble(entry.split(":")[0]) - 1.0;
            } catch (NumberFormatException ignored) {
                // повреждённая запись буста пропускается
            }
        }
        return Math.max(0, bonus);
    }

    /** Множитель бустов для показа игроку: 1.0 + добавка. */
    public double boostMultiplier(UUID id) {
        return 1.0 + boostBonus(id);
    }

    private List<String> active(UUID id) {
        long now = System.currentTimeMillis();
        List<String> all = boosts.cfg().getStringList(id.toString());
        List<String> alive = new ArrayList<>();
        for (String entry : all) {
            String[] parts = entry.split(":");
            if (parts.length == 2 && Long.parseLong(parts[1]) > now) alive.add(entry);
        }
        if (alive.size() != all.size()) {
            boosts.cfg().set(id.toString(), alive.isEmpty() ? null : alive);
            boosts.dirty();
        }
        return alive;
    }
}
