package ru.fatecore.echo;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.fatecore.earn.EarnService;
import ru.fatecore.rotation.RotationManager;
import ru.fatecore.util.Modes;
import ru.fatecore.util.Cmd;
import ru.fatecore.util.Msg;

public final class EchoCommand implements CommandExecutor {
    private final EchoManager echo;
    private final RotationManager rotation;
    private final EarnService earn;

    public EchoCommand(EchoManager echo, RotationManager rotation, EarnService earn) {
        this.echo = echo;
        this.rotation = rotation;
        this.earn = earn;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Player p = Cmd.player(sender);
        if (p == null) return true;
        Msg.send(p, "&6Эхо: &f" + echo.format(echo.getEcho(p)));
        Msg.raw(p, "&7Ваш бонус дня, Эхо x2: &e" + Modes.display(rotation.getBonusMode(p.getUniqueId())));
        Msg.raw(p, "&7Привилегия: &fx" + EchoManager.formatMult(earn.donateMultiplier(p))
                + " &7| Буст: &fx" + EchoManager.formatMult(echo.boostMultiplier(p.getUniqueId()))
                + " &7| Итого (сумма, кап x" + EchoManager.formatMult(earn.multiplierCap()) + "): &ax"
                + EchoManager.formatMult(earn.totalMultiplier(p, Modes.of(p.getWorld()))));
        return true;
    }
}
