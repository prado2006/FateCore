package ru.fatecore.util;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public final class Items {
    private Items() {}

    public static ItemStack make(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(Msg.c(name));
        if (lore.length > 0) {
            meta.setLore(Arrays.stream(lore).map(Msg::c).toList());
        }
        it.setItemMeta(meta);
        return it;
    }

    /** Общие неизменяемые «шаблоны»: создаются один раз, инвентарь при setItem копирует предмет. Не изменять! */
    private static ItemStack filler;
    private static ItemStack close;

    private static final java.util.Map<Material, ItemStack> PANES = new java.util.EnumMap<>(Material.class);

    /** Безымянная панель нужного цвета (кэшируется, только для inv.setItem). */
    public static synchronized ItemStack pane(Material m) {
        return PANES.computeIfAbsent(m, k -> make(k, " "));
    }

    public static void fill(Inventory inv) {
        ItemStack f = filler;
        if (f == null) filler = f = make(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, f);
    }

    /** Заливка всего инвентаря панелью одного цвета. */
    public static void fill(Inventory inv, Material pane) {
        ItemStack f = pane(pane);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, f);
    }

    /** Рамка по краю инвентаря из двух чередующихся цветов (для высоты от 3 рядов). Предметы ставьте ПОСЛЕ рамки. */
    public static void border(Inventory inv, Material a, Material b) {
        int rows = inv.getSize() / 9;
        ItemStack pa = pane(a);
        ItemStack pb = pane(b);
        for (int i = 0; i < inv.getSize(); i++) {
            int row = i / 9;
            int col = i % 9;
            if (row == 0 || row == rows - 1 || col == 0 || col == 8) inv.setItem(i, (i % 2 == 0) ? pa : pb);
        }
    }

    /** Кнопка «Закрыть» (красный краситель; красный барьер используется только в меню доната). */
    public static ItemStack closeButton() {
        ItemStack c = close;
        if (c == null) close = c = make(Material.RED_DYE, "&cЗакрыть");
        return c;
    }

    /** Выдаёт предмет, лишнее выбрасывает под ноги. */
    public static void give(Player p, ItemStack it) {
        p.getInventory().addItem(it).values()
                .forEach(left -> p.getWorld().dropItemNaturally(p.getLocation(), left));
    }
}
