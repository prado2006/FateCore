package ru.fatecore.util;

import org.bukkit.plugin.Plugin;

import java.util.logging.Level;

/** Изоляция ошибок: исключение одного игрока/задачи не должно останавливать остальных и плагин целиком. */
public final class Safe {
    private Safe() {}

    /** Выполняет действие; исключение логируется (с трассировкой) и не пробрасывается дальше. */
    public static void run(Plugin plugin, String what, Runnable action) {
        try {
            action.run();
        } catch (Exception ex) {
            plugin.getLogger().log(Level.WARNING, "Ошибка в «" + what + "»: " + ex, ex);
        }
    }
}
