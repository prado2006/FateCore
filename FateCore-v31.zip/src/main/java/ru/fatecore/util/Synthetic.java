package ru.fatecore.util;

import java.util.function.Supplier;

/**
 * Флаг «пробных» событий. /light и /sign перед действием вызывают BlockPlaceEvent / BlockBreakEvent / SignChangeEvent,
 * чтобы плагины защиты территорий могли запретить действие. Пока флаг поднят, слушатели FateCore, которые
 * начисляют Эхо или квестовый прогресс за блоки, такие события игнорируют.
 * События вызываются только на главном потоке, поэтому обычного поля достаточно.
 */
public final class Synthetic {
    private static boolean active;

    private Synthetic() {}

    public static boolean active() {
        return active;
    }

    /** Выполняет действие с поднятым флагом (флаг всегда сбрасывается). */
    public static <T> T run(Supplier<T> action) {
        boolean prev = active;
        active = true;
        try {
            return action.get();
        } finally {
            active = prev;
        }
    }
}
