package ru.fatecore.perks;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.Plugin;
import ru.fatecore.util.Msg;

import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Ограничивает /give (и /i, /item) для игроков с привилегией: можно выдавать только декоративные блоки и яйца призыва.
 * Ресурсы (алмазы, незерит, золото, оружие, броня и т.п.) выдать нельзя — донат не ломает экономику.
 * Списки — config.yml (give-guard.allow-suffixes / allow-exact). OP и право fatecore.give.bypass — без ограничений.
 * Консоль не затрагивается (это событие только для команд игроков).
 */
public final class GiveGuard implements Listener {
    private static final Set<String> COMMANDS = Set.of(
            "give", "egive", "essentials:give", "essentials:egive", "minecraft:give",
            "i", "item", "eitem", "essentials:i", "essentials:item");

    private final Plugin plugin;

    public GiveGuard(Plugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!plugin.getConfig().getBoolean("give-guard.enabled", true)) return;
        String msg = e.getMessage().trim();
        if (msg.length() < 2) return;
        String[] parts = msg.substring(1).split("\\s+");
        String name = parts[0].toLowerCase(Locale.ROOT);
        if (!COMMANDS.contains(name)) return;
        Player p = e.getPlayer();
        if (p.isOp() || p.hasPermission("fatecore.give.bypass")) return;

        // /give <игрок> <предмет> [кол-во]; /i <предмет> [кол-во]
        boolean give = name.endsWith("give");
        int idx = give ? 2 : 1;
        if (parts.length <= idx) return; // нет предмета — команда сама покажет подсказку
        String raw = parts[idx];
        int br = raw.indexOf('[');
        if (br >= 0) raw = raw.substring(0, br); // minecraft:item[nbt]
        Material m = Material.matchMaterial(raw);
        if (m == null || !allowed(m)) {
            e.setCancelled(true);
            Msg.send(p, "&cЧерез /" + name + " можно выдавать только декоративные блоки и яйца призыва.");
        }
    }

    private boolean allowed(Material m) {
        String n = m.name();
        List<String> exact = plugin.getConfig().getStringList("give-guard.allow-exact");
        if (exact.contains(n)) return true;
        for (String suffix : plugin.getConfig().getStringList("give-guard.allow-suffixes")) {
            if (n.endsWith(suffix)) return true;
        }
        return false;
    }
}
