package ru.fatecore.perks;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.fatecore.FateCore;
import ru.fatecore.util.Cmd;
import ru.fatecore.util.Msg;
import ru.fatecore.util.StartupCheck;

import java.util.List;
import java.util.Set;

/**
 * Доступ к командам FateCore (/auto, /feather, /durability): право fatecore.<команда> ИЛИ привилегия не ниже
 * указанной в config.yml (command-tiers.<команда>). Консоль и OP проходят всегда.
 * Так команда работает сразу после покупки привилегии (группа LuckPerms), без отдельных прав.
 * Команды в plugin.yml объявлены без permission, поэтому клиент не прячет их и не пишет «Неизвестная команда».
 */
public final class Access {
    private Access() {}

    public static boolean has(FateCore plugin, CommandSender sender, String command) {
        if (Cmd.can(sender, "fatecore." + command)) return true;
        if (!(sender instanceof Player p)) return false;
        String min = plugin.getConfig().getString("command-tiers." + command);
        if (min == null) return false;
        List<String> order = StartupCheck.TIERS;
        int need = order.indexOf(min.toLowerCase());
        if (need < 0) return false;
        Set<String> groups = Tiers.groups(p);
        for (int i = need; i < order.size(); i++) {
            if (groups.contains(order.get(i))) return true;
        }
        return false;
    }

    /** Проверка с сообщением об отказе. */
    public static boolean check(FateCore plugin, CommandSender sender, String command) {
        if (has(plugin, sender, command)) return true;
        Msg.send(sender, "&cУ вас нет прав! Команда /" + command + " доступна с привилегией выше.");
        return false;
    }
}
