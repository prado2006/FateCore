package ru.fatecore.perks;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.block.sign.Side;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.util.RayTraceResult;
import ru.fatecore.FateCore;
import ru.fatecore.util.Cmd;
import ru.fatecore.util.Modes;
import ru.fatecore.util.Msg;
import ru.fatecore.util.Synthetic;
import ru.fatecore.util.YamlStore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * /sign [back] <1-4> <текст> — правка строки уже поставленной таблички, на которую смотрит игрок (до 5 блоков).
 * /sign [back] clear <1-4> — очистить строку. Цвета через &amp;-коды.
 *
 * Защита от гриферства: FateCore запоминает владельца таблички (кто первым её подписал; файл signs.yml) и
 * разрешает править только свои. Таблички без записи (поставлены до установки плагина) и чужие может править
 * только персонал с правом fatecore.sign.others (OP). Вощёные таблички не правятся. Перед правкой вызывается
 * пробное SignChangeEvent, чтобы плагины защиты территорий могли запретить действие.
 * Только в мирах Выживания. Доступ: право fatecore.sign ИЛИ привилегия не ниже command-tiers.sign (Мастер).
 */
public final class SignCommand implements CommandExecutor, Listener {
    private static final int RANGE = 5;
    private static final int MAX_PLAIN = 45;
    private static final LegacyComponentSerializer AMP = LegacyComponentSerializer.legacyAmpersand();

    private final FateCore plugin;
    private final YamlStore owners;

    public SignCommand(FateCore plugin) {
        this.plugin = plugin;
        this.owners = new YamlStore(plugin, "signs.yml");
    }

    private static String key(Block b) {
        return b.getWorld().getName() + ";" + b.getX() + ";" + b.getY() + ";" + b.getZ();
    }

    /** Первый, кто подписал табличку, становится владельцем (повторные правки владельца не меняют). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSign(SignChangeEvent e) {
        if (Synthetic.active()) return;
        String k = "owners." + key(e.getBlock()).replace('.', '_');
        if (!owners.cfg().contains(k)) {
            owners.cfg().set(k, e.getPlayer().getUniqueId().toString());
            owners.dirty();
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (Synthetic.active()) return;
        if (!(e.getBlock().getState() instanceof Sign)) return;
        String k = "owners." + key(e.getBlock()).replace('.', '_');
        if (owners.cfg().contains(k)) {
            owners.cfg().set(k, null);
            owners.dirty();
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player p = Cmd.player(sender);
        if (p == null || !Access.check(plugin, sender, "sign")) return true;
        if (!Modes.isSurvivalFamily(p.getWorld())) {
            Msg.send(p, "&c/sign работает только в мире Выживания.");
            return true;
        }
        int i = 0;
        Side side = Side.FRONT;
        if (args.length > 0 && args[0].equalsIgnoreCase("back")) {
            side = Side.BACK;
            i = 1;
        }
        boolean clear = args.length > i && args[i].equalsIgnoreCase("clear");
        if (clear) i++;
        if (args.length <= i || (!clear && args.length <= i + 1)) {
            usage(p);
            return true;
        }
        int line;
        try {
            line = Integer.parseInt(args[i]);
        } catch (NumberFormatException ex) {
            usage(p);
            return true;
        }
        if (line < 1 || line > 4) {
            usage(p);
            return true;
        }
        String text = clear ? "" : String.join(" ", Arrays.copyOfRange(args, i + 1, args.length));
        Component comp = AMP.deserialize(text);
        if (PlainTextComponentSerializer.plainText().serialize(comp).length() > MAX_PLAIN) {
            Msg.send(p, "&cСлишком длинная строка (максимум " + MAX_PLAIN + " символов без цветовых кодов).");
            return true;
        }

        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceBlocks(eye, eye.getDirection(), RANGE, FluidCollisionMode.NEVER, false);
        Block b = r == null ? null : r.getHitBlock();
        if (b == null || !(b.getState() instanceof Sign sign)) {
            Msg.send(p, "&cСмотрите на табличку (до " + RANGE + " блоков).");
            return true;
        }
        if (sign.isWaxed()) {
            Msg.send(p, "&cТабличка вощёная — править её нельзя.");
            return true;
        }
        if (!mayEdit(p, b)) {
            Msg.send(p, "&cМожно править только свои таблички.");
            return true;
        }

        List<Component> lines = new ArrayList<>(sign.getSide(side).lines());
        while (lines.size() < 4) lines.add(Component.empty());
        lines.set(line - 1, comp);
        final Side fSide = side;
        final List<Component> fLines = lines;
        boolean allowed = Synthetic.run(() -> {
            SignChangeEvent ev = new SignChangeEvent(b, p, fLines, fSide);
            Bukkit.getPluginManager().callEvent(ev);
            return !ev.isCancelled();
        });
        if (!allowed) {
            Msg.send(p, "&cЗдесь нельзя править таблички.");
            return true;
        }
        sign.getSide(side).line(line - 1, comp);
        sign.update();
        Msg.send(p, "&aСтрока " + line + (side == Side.BACK ? " (обратная сторона)" : "") + " обновлена.");
        return true;
    }

    private boolean mayEdit(Player p, Block b) {
        if (Cmd.can(p, "fatecore.sign.others")) return true;
        String owner = owners.cfg().getString("owners." + key(b).replace('.', '_'));
        return owner != null && owner.equals(p.getUniqueId().toString());
    }

    private static void usage(Player p) {
        Msg.send(p, "&7Использование: &e/sign [back] <1-4> <текст> &7или &e/sign [back] clear <1-4>");
        Msg.send(p, "&7Смотрите на свою табличку. Цвета — знак амперсанда и код цвета (6 — золотой, c — красный).");
    }
}
