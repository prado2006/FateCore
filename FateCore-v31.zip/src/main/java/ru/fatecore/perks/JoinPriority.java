package ru.fatecore.perks;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.plugin.Plugin;

/**
 * Приоритетный вход (Владыка и Абсолют): если сервер полон, игрок с правом fatecore.join.priority заходит
 * сверх лимита мест, остальные получают сообщение join-priority.full-message («Сервер полон»).
 * Право выдаётся группам overlord и absolute в LuckPerms (см. docs/LUCKPERMS-v31.txt). OP проходит всегда.
 * Включается join-priority.enabled в config.yml. Не кикает уже играющих — только пускает сверх лимита,
 * поэтому оставляйте запас: join-priority.max-extra ограничивает, на сколько мест можно превысить лимит.
 */
public final class JoinPriority implements Listener {
    private final Plugin plugin;

    public JoinPriority(Plugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onLogin(PlayerLoginEvent e) {
        if (e.getResult() != PlayerLoginEvent.Result.KICK_FULL) return;
        if (!plugin.getConfig().getBoolean("join-priority.enabled", true)) return;
        boolean vip = e.getPlayer().isOp() || e.getPlayer().hasPermission("fatecore.join.priority");
        if (vip) {
            int extra = plugin.getConfig().getInt("join-priority.max-extra", 10);
            int over = plugin.getServer().getOnlinePlayers().size() - plugin.getServer().getMaxPlayers();
            if (extra <= 0 || over < extra) {
                e.allow();
                return;
            }
        }
        String msg = plugin.getConfig().getString("join-priority.full-message", "&cСервер полон");
        e.disallow(PlayerLoginEvent.Result.KICK_FULL,
                LegacyComponentSerializer.legacySection().deserialize(ru.fatecore.util.Msg.c(msg)));
    }
}
