package ru.fatecore.perks;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import ru.fatecore.FateCore;
import ru.fatecore.api.IDataStore;
import ru.fatecore.util.Items;
import ru.fatecore.util.Msg;
import ru.fatecore.util.Safe;
import ru.fatecore.util.StartupCheck;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

/**
 * Частицы-косметика вокруг игрока. Доступ привязан к привилегиям (config.yml, раздел particles):
 *  - 5 базовых частиц (basic: true): привилегия particles.tiers.basic (Герой), право fatecore.particles.basic
 *    или покупка «Частицы» в магазине (право fatecore.cosmetic.particles);
 *  - все частицы: привилегия particles.tiers.all (Абсолют) или право fatecore.particles.all (OP — тоже все).
 * Выбор — меню «Магазин → Косметика → Частицы» или команда /particles. Выбранная частица хранится в IDataStore
 * (ключ particle) и показывается задачей раз в particles.interval-ticks тиков. В мирах perks.restricted-worlds
 * (арены), в режиме наблюдателя и под невидимостью частицы не показываются. Силу в бою частицы не дают.
 */
public final class Particles implements CommandExecutor, Listener {
    private static final String KEY = "particle";
    private static final int[] SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
    private static final int SLOT_BACK = 30, SLOT_OFF = 31, SLOT_CLOSE = 32, SLOT_INFO = 4;

    /** Имена частиц отличаются между версиями API (до и после 1.20.5): пробуем обе. */
    private static final Map<String, String> ALIASES = Map.of(
            "VILLAGER_HAPPY", "HAPPY_VILLAGER", "HAPPY_VILLAGER", "VILLAGER_HAPPY",
            "ENCHANTMENT_TABLE", "ENCHANT", "ENCHANT", "ENCHANTMENT_TABLE",
            "SPELL_WITCH", "WITCH", "WITCH", "SPELL_WITCH",
            "FIREWORKS_SPARK", "FIREWORK", "FIREWORK", "FIREWORKS_SPARK",
            "TOTEM", "TOTEM_OF_UNDYING", "TOTEM_OF_UNDYING", "TOTEM");

    public record Entry(String id, String name, Material icon, Particle particle, boolean basic) {}

    private static final class Holder implements InventoryHolder {
        private Inventory inv;

        @Override public Inventory getInventory() { return inv; }
    }

    private final FateCore plugin;
    private final IDataStore data;
    private Consumer<Player> back;

    private List<Entry> cache;
    private Object cacheKey;

    public Particles(FateCore plugin, IDataStore data) {
        this.plugin = plugin;
        this.data = data;
    }

    /** Куда возвращает кнопка «Назад» (меню косметики магазина). */
    public void setBack(Consumer<Player> back) {
        this.back = back;
    }

    // ---------- список частиц ----------

    public List<Entry> entries() {
        Object key = plugin.getConfig();
        if (cache != null && cacheKey == key) return cache;
        List<Entry> out = new ArrayList<>();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("particles.list");
        if (sec != null) {
            for (String id : sec.getKeys(false)) {
                ConfigurationSection c = sec.getConfigurationSection(id);
                if (c == null) continue;
                Particle particle = resolve(c.getString("particle", ""));
                if (particle == null) {
                    plugin.getLogger().warning("particles.list." + id + ": неизвестная частица '" + c.getString("particle") + "', пропущена.");
                    continue;
                }
                Material icon = Material.matchMaterial(c.getString("icon", "BLAZE_POWDER"));
                out.add(new Entry(id, c.getString("name", id), icon == null ? Material.BLAZE_POWDER : icon,
                        particle, c.getBoolean("basic", false)));
                if (out.size() >= SLOTS.length) break;
            }
        }
        cache = out;
        cacheKey = key;
        return out;
    }

    private static Particle resolve(String name) {
        String n = name.trim().toUpperCase(java.util.Locale.ROOT);
        if (n.isEmpty()) return null;
        try {
            return Particle.valueOf(n);
        } catch (IllegalArgumentException ex) {
            String alt = ALIASES.get(n);
            if (alt == null) return null;
            try {
                return Particle.valueOf(alt);
            } catch (IllegalArgumentException ex2) {
                return null;
            }
        }
    }

    // ---------- доступ ----------

    /** 0 — нет доступа, 1 — только базовые, 2 — все. */
    public int level(Player p) {
        if (p.isOp() || p.hasPermission("fatecore.particles.all")) return 2;
        Set<String> groups = Tiers.groups(p);
        if (reached(groups, plugin.getConfig().getString("particles.tiers.all", "absolute"))) return 2;
        if (p.hasPermission("fatecore.particles.basic") || p.hasPermission("fatecore.cosmetic.particles")
                || reached(groups, plugin.getConfig().getString("particles.tiers.basic", "hero"))) return 1;
        return 0;
    }

    private static boolean reached(Set<String> groups, String min) {
        List<String> order = StartupCheck.TIERS;
        int need = order.indexOf(min == null ? "" : min.toLowerCase(java.util.Locale.ROOT));
        if (need < 0) return false;
        for (int i = need; i < order.size(); i++) {
            if (groups.contains(order.get(i))) return true;
        }
        return false;
    }

    private static boolean allowed(Entry e, int level) {
        return level >= 2 || (level == 1 && e.basic());
    }

    // ---------- показ частиц ----------

    public void start() {
        long period = Math.max(2L, plugin.getConfig().getLong("particles.interval-ticks", 10));
        new BukkitRunnable() {
            @Override public void run() { Safe.run(plugin, "particles", Particles.this::tick); }
        }.runTaskTimer(plugin, 40L, period);
    }

    private void tick() {
        List<Entry> list = entries();
        if (list.isEmpty()) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            String id = data.getString(p.getUniqueId(), KEY, "");
            if (id == null || id.isEmpty()) continue;
            if (p.getGameMode() == GameMode.SPECTATOR || p.hasPotionEffect(PotionEffectType.INVISIBILITY)) continue;
            if (PerkListener.isRestricted(plugin, p.getWorld())) continue;
            Entry chosen = find(list, id);
            if (chosen == null || !allowed(chosen, level(p))) continue; // привилегию потеряли — частица молчит
            Location at = p.getLocation().add(0, 1.0, 0);
            p.getWorld().spawnParticle(chosen.particle(), at, 3, 0.35, 0.6, 0.35, 0.0);
        }
    }

    private static Entry find(List<Entry> list, String id) {
        for (Entry e : list) if (e.id().equals(id)) return e;
        return null;
    }

    // ---------- команда и меню ----------

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Msg.send(sender, "&cКоманда только для игроков.");
            return true;
        }
        open(p);
        return true;
    }

    /** Открывает меню выбора; без доступа — подсказка, как его получить. */
    public void open(Player p) {
        int level = level(p);
        if (level == 0) {
            Msg.send(p, "&cЧастицы доступны с привилегией Герой (5 базовых) или Абсолют (все), либо купите «Частицы» в магазине: /shop");
            return;
        }
        List<Entry> list = entries();
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, 36, Msg.c("&8Косметика: Частицы"));
        holder.inv = inv;
        Items.fill(inv);
        Items.border(inv, Material.LIGHT_BLUE_STAINED_GLASS_PANE, Material.PINK_STAINED_GLASS_PANE);
        String current = data.getString(p.getUniqueId(), KEY, "");
        for (int i = 0; i < list.size() && i < SLOTS.length; i++) {
            Entry e = list.get(i);
            boolean ok = allowed(e, level);
            boolean selected = e.id().equals(current) && ok;
            String name = (selected ? "&a✔ " : ok ? "&6" : "&7") + e.name();
            ItemStack it = ok
                    ? Items.make(e.icon(), name, e.basic() ? "&7Базовая частица" : "&7Частица Абсолюта",
                            selected ? "&aСейчас выбрана" : "&eКлик — выбрать")
                    : Items.make(e.icon(), name, "&cДоступно с привилегией Абсолют");
            inv.setItem(SLOTS[i], it);
        }
        inv.setItem(SLOT_INFO, Items.make(Material.BLAZE_POWDER, "&6Твои частицы",
                level >= 2 ? "&7Доступны все частицы" : "&7Доступны 5 базовых частиц",
                "&7Они видны вокруг тебя в Выживании и лобби"));
        inv.setItem(SLOT_BACK, Items.make(Material.ARROW, "&7Назад"));
        inv.setItem(SLOT_OFF, Items.make(Material.GRAY_DYE, "&7Выключить частицы"));
        inv.setItem(SLOT_CLOSE, Items.closeButton());
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        int slot = e.getRawSlot();
        if (slot == SLOT_CLOSE) {
            p.closeInventory();
            return;
        }
        if (slot == SLOT_BACK) {
            if (back != null) back.accept(p);
            else p.closeInventory();
            return;
        }
        if (slot == SLOT_OFF) {
            data.setString(p.getUniqueId(), KEY, "");
            Msg.send(p, "&eЧастицы выключены.");
            open(p);
            return;
        }
        List<Entry> list = entries();
        for (int i = 0; i < list.size() && i < SLOTS.length; i++) {
            if (SLOTS[i] != slot) continue;
            Entry en = list.get(i);
            if (!allowed(en, level(p))) {
                Msg.send(p, "&cЭта частица доступна с привилегией Абсолют.");
                return;
            }
            data.setString(p.getUniqueId(), KEY, en.id());
            Msg.send(p, "&aВыбрана частица: &6" + en.name());
            open(p);
            return;
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
