package ru.fatecore.perks;

import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.Light;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.RayTraceResult;
import ru.fatecore.FateCore;
import ru.fatecore.util.Cmd;
import ru.fatecore.util.Modes;
import ru.fatecore.util.Msg;
import ru.fatecore.util.Synthetic;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * /light [1-15] — ставит невидимый блок света (Material.LIGHT) на блок воздуха, куда смотрит игрок (до 5 блоков).
 * /light off — убирает ближайший блок света в радиусе 5 блоков от игрока.
 *
 * Работает только в мирах Выживания (hub, hub_nether, hub_the_end). Перед действием вызывается пробное событие
 * BlockPlaceEvent / BlockBreakEvent, поэтому плагины защиты территорий могут запретить его.
 * Ограничения (config.yml, раздел light): max-per-player — сколько блоков света игрок держит одновременно
 * (старый убирается сам), cooldown-ms — пауза между использованиями. Доступ: право fatecore.light ИЛИ
 * привилегия не ниже command-tiers.light (Мастер).
 */
public final class LightCommand implements CommandExecutor, Listener {
    private static final int RANGE = 5;

    private record Pos(UUID world, int x, int y, int z) {
        static Pos of(Block b) { return new Pos(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ()); }

        Block block() {
            org.bukkit.World w = Bukkit.getWorld(world);
            return w == null ? null : w.getBlockAt(x, y, z);
        }
    }

    private final FateCore plugin;
    private final Map<UUID, ArrayDeque<Pos>> placed = new HashMap<>();
    private final Map<UUID, Long> lastUse = new HashMap<>();

    public LightCommand(FateCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        placed.remove(e.getPlayer().getUniqueId()); // блоки остаются в мире, сбрасывается только учёт
        lastUse.remove(e.getPlayer().getUniqueId());
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player p = Cmd.player(sender);
        if (p == null || !Access.check(plugin, sender, "light")) return true;
        if (!Modes.isSurvivalFamily(p.getWorld())) {
            Msg.send(p, "&c/light работает только в мире Выживания.");
            return true;
        }
        long now = System.currentTimeMillis();
        long cd = Math.max(0, plugin.getConfig().getLong("light.cooldown-ms", 1000));
        if (now - lastUse.getOrDefault(p.getUniqueId(), 0L) < cd) return true;
        lastUse.put(p.getUniqueId(), now);

        if (args.length >= 1 && (args[0].equalsIgnoreCase("off") || args[0].equalsIgnoreCase("remove")
                || args[0].equalsIgnoreCase("clear"))) {
            remove(p);
            return true;
        }
        int level = 15;
        if (args.length >= 1) {
            try {
                level = Integer.parseInt(args[0]);
            } catch (NumberFormatException ex) {
                level = -1;
            }
            if (level < 1 || level > 15) {
                Msg.send(p, "&7Использование: &e/light [1-15] &7или &e/light off");
                return true;
            }
        }
        place(p, level);
        return true;
    }

    private void place(Player p, int level) {
        Block target = target(p);
        if (target == null || !(target.getType().isAir() || target.getType() == Material.LIGHT)) {
            Msg.send(p, "&cСмотрите на блок или в воздух рядом (до " + RANGE + " блоков): там должно быть свободное место.");
            return;
        }
        if (!canBuild(p, target)) {
            Msg.send(p, "&cЗдесь нельзя строить.");
            return;
        }
        Light data = (Light) Bukkit.createBlockData(Material.LIGHT);
        data.setLevel(level);
        target.setBlockData(data, false);

        ArrayDeque<Pos> mine = placed.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>());
        Pos pos = Pos.of(target);
        mine.remove(pos);
        mine.addLast(pos);
        int max = Math.max(1, plugin.getConfig().getInt("light.max-per-player", 10));
        while (mine.size() > max) {
            Block old = mine.pollFirst().block();
            if (old != null && old.getType() == Material.LIGHT) old.setType(Material.AIR, false);
        }
        Msg.send(p, "&aСвет установлен (яркость " + level + "). Убрать: &e/light off");
    }

    private void remove(Player p) {
        Block best = null;
        double bestDist = Double.MAX_VALUE;
        Location loc = p.getLocation();
        for (int dx = -RANGE; dx <= RANGE; dx++) {
            for (int dy = -RANGE; dy <= RANGE; dy++) {
                for (int dz = -RANGE; dz <= RANGE; dz++) {
                    Block b = loc.getWorld().getBlockAt(loc.getBlockX() + dx, loc.getBlockY() + dy, loc.getBlockZ() + dz);
                    if (b.getType() != Material.LIGHT) continue;
                    double d = b.getLocation().add(0.5, 0.5, 0.5).distanceSquared(loc);
                    if (d < bestDist) {
                        bestDist = d;
                        best = b;
                    }
                }
            }
        }
        if (best == null) {
            Msg.send(p, "&cРядом (в радиусе " + RANGE + " блоков) нет блоков света.");
            return;
        }
        final Block victim = best;
        boolean allowed = Synthetic.run(() -> {
            BlockBreakEvent ev = new BlockBreakEvent(victim, p);
            Bukkit.getPluginManager().callEvent(ev);
            return !ev.isCancelled();
        });
        if (!allowed) {
            Msg.send(p, "&cЗдесь нельзя ломать.");
            return;
        }
        victim.setType(Material.AIR, false);
        Msg.send(p, "&aБлок света убран.");
    }

    /** Блок, куда смотрит игрок: клетка рядом с гранью найденного блока или точка на расстоянии RANGE в воздухе. */
    private static Block target(Player p) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceBlocks(eye, eye.getDirection(), RANGE, FluidCollisionMode.NEVER, false);
        if (r != null && r.getHitBlock() != null && r.getHitBlockFace() != null) {
            return r.getHitBlock().getRelative(r.getHitBlockFace());
        }
        return eye.clone().add(eye.getDirection().multiply(RANGE)).getBlock();
    }

    /** Пробное BlockPlaceEvent: плагины защиты могут отменить. Эхо и квесты за него не начисляются (Synthetic). */
    private static boolean canBuild(Player p, Block target) {
        return Synthetic.run(() -> {
            BlockPlaceEvent ev = new BlockPlaceEvent(target, target.getState(), target.getRelative(BlockFace.DOWN),
                    new ItemStack(Material.LIGHT), p, true, EquipmentSlot.HAND);
            Bukkit.getPluginManager().callEvent(ev);
            return !ev.isCancelled() && ev.canBuild();
        });
    }
}
