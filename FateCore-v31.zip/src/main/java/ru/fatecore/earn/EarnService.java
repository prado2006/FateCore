package ru.fatecore.earn;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.event.EventSubscription;
import net.luckperms.api.event.user.UserDataRecalculateEvent;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.query.QueryOptions;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import ru.fatecore.FateCore;
import ru.fatecore.api.IDataStore;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.quest.QuestManager;
import ru.fatecore.rotation.RotationManager;
import ru.fatecore.util.Modes;

import java.time.LocalDate;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/** МОДУЛЬ 4 — расчёт множителей и начисление Эхо. */
public final class EarnService {
    private final FateCore plugin;
    private final EchoManager echo;
    private final RotationManager rotation;
    private final IDataStore data;

    // ---------- кэш донат-множителя ----------
    // Множитель считается на каждый поставленный в Выживании блок (BlockPlaceEvent), а обход наследования групп
    // LuckPerms недёшев. Кэш сбрасывается событием LuckPerms (смена групп/прав игрока), при выходе игрока и при
    // перезагрузке конфига; TTL — страховка.
    private static final long TTL_HOOKED_MS = 60_000L;
    private static final long TTL_UNHOOKED_MS = 10_000L;

    private record Cached(double value, FileConfiguration cfg, long until) {}

    private final Map<UUID, Cached> donateCache = new ConcurrentHashMap<>();
    private volatile boolean lpEventsHooked;
    private boolean lpHookFailed;
    private EventSubscription<UserDataRecalculateEvent> lpSubscription;

    private synchronized void hookLuckPerms(LuckPerms lp) {
        if (lpSubscription != null || lpHookFailed) return;
        try {
            lpSubscription = lp.getEventBus().subscribe(plugin, UserDataRecalculateEvent.class,
                    e -> donateCache.remove(e.getUser().getUniqueId()));
            lpEventsHooked = true;
        } catch (RuntimeException | LinkageError ex) {
            lpHookFailed = true; // работаем только по короткому TTL
            plugin.getLogger().warning("Не удалось подписаться на события LuckPerms (кэш множителя — по TTL): " + ex.getMessage());
        }
    }

    /** Сбросить кэш игрока (выход с сервера). */
    public void forget(UUID id) {
        donateCache.remove(id);
    }

    /** Отписка от событий LuckPerms (onDisable). */
    public synchronized void shutdown() {
        if (lpSubscription != null) {
            try {
                lpSubscription.close();
            } catch (RuntimeException ignored) {
                // LuckPerms уже выгружен
            }
            lpSubscription = null;
        }
        lpEventsHooked = false;
        donateCache.clear();
    }

    public EarnService(FateCore plugin, EchoManager echo, RotationManager rotation, IDataStore data) {
        this.plugin = plugin;
        this.data = data;
        this.echo = echo;
        this.rotation = rotation;
    }

    /**
     * Множитель из config.yml (donate-multipliers) по группам LuckPerms игрока.
     * Только чтение групп; ничего в LuckPerms не изменяется. Нет группы — 1.0.
     */
    public double donateMultiplier(Player p) {
        UUID id = p.getUniqueId();
        FileConfiguration cfg = plugin.getConfig();
        long now = System.currentTimeMillis();
        Cached cached = donateCache.get(id);
        if (cached != null && cached.cfg() == cfg && now < cached.until()) return cached.value();
        try {
            LuckPerms lp = LuckPermsProvider.get();
            hookLuckPerms(lp);
            User user = lp.getUserManager().getUser(id);
            if (user == null) return 1.0;
            Set<String> groups = user.getInheritedGroups(QueryOptions.nonContextual()).stream()
                    .map(Group::getName)
                    .map(String::toLowerCase)
                    .collect(Collectors.toSet());
            ConfigurationSection sec = plugin.getConfig().getConfigurationSection("donate-multipliers");
            if (sec == null) return 1.0;
            double best = 1.0;
            for (String key : sec.getKeys(false)) {
                if (groups.contains(key.toLowerCase())) {
                    best = Math.max(best, sec.getDouble(key, 1.0));
                }
            }
            donateCache.put(id, new Cached(best, cfg, now + (lpEventsHooked ? TTL_HOOKED_MS : TTL_UNHOOKED_MS)));
            return best;
        } catch (IllegalStateException e) {
            return 1.0;
        }
    }

    /**
     * Ротация режима * донат-множитель (x1.10 - x2.20) * временные бусты.
     * Донат-множитель действует во ВСЕХ режимах, включая BedWars/SkyWars. Он влияет только на Эхо:
     * брони, оружия и китов в мини-играх донат не даёт.
     */
    public double totalMultiplier(Player p, String mode) {
        UUID id = p.getUniqueId();
        // Множители СКЛАДЫВАЮТСЯ, а не перемножаются: 1.0 + (привилегия-1) + (буст-1) + (бонус дня-1).
        // Пример: Абсолют x3 + буст x1.5 = 3.5. Итог ограничен economy.multiplier-cap (по умолчанию 5.0).
        double sum = 1.0 + (donateMultiplier(p) - 1.0) + echo.boostBonus(id) + rotation.getBonus(id, mode);
        double cap = plugin.getConfig().getDouble("economy.multiplier-cap", 5.0);
        return Math.max(1.0, Math.min(cap, sum));
    }

    /** economy.multiplier-cap: потолок итогового множителя Эхо (по умолчанию 5.0). */
    public double multiplierCap() {
        return plugin.getConfig().getDouble("economy.multiplier-cap", 5.0);
    }

    private static final String K_FRAC = "echo_frac"; // накопленная дробная часть Эхо, в тысячных

    /**
     * Эхо — целая валюта: дробные суммы (блоки, игры, часы с множителем) копятся в тысячных долях
     * и выдаются целыми Эхо, ничего не теряется на округлении.
     */
    public void credit(Player p, double amount) {
        long milli = Math.round(amount * 1000);
        if (milli <= 0) return;
        UUID id = p.getUniqueId();
        long frac = data.getLong(id, K_FRAC, 0) + milli;
        long whole = frac / 1000;
        data.setLong(id, K_FRAC, frac % 1000);
        if (whole > 0) echo.addEcho(p, whole);
    }

    private static final String K_PLACE_DAY = "place_day";
    private static final String K_PLACE_USED = "place_used"; // в тысячных

    /**
     * Эхо за поставленный блок с суточным лимитом economy.block-place-daily-limit (защита от автокликера/фермы блоков).
     * Лимит считается уже с множителями; сброс в 00:00 МСК. 0 = без лимита.
     */
    public void creditBlockPlace(Player p, double amount) {
        long milli = Math.round(amount * 1000);
        if (milli <= 0) return;
        long limit = Math.round(plugin.getConfig().getDouble("economy.block-place-daily-limit", 100) * 1000);
        if (limit > 0) {
            UUID id = p.getUniqueId();
            long today = LocalDate.now(QuestManager.MSK).toEpochDay();
            if (data.getLong(id, K_PLACE_DAY, -1) != today) {
                data.setLong(id, K_PLACE_DAY, today);
                data.setLong(id, K_PLACE_USED, 0);
            }
            long used = data.getLong(id, K_PLACE_USED, 0);
            milli = Math.min(milli, limit - used);
            if (milli <= 0) return;
            data.setLong(id, K_PLACE_USED, used + milli);
        }
        credit(p, milli / 1000.0);
    }

    /** Убийство в BedWars/SkyWars: +1 Эхо * множители, в пределах дневного лимита игр. */
    public void addKillEcho(Player killer, String mode) {
        grantGameEcho(killer, 1.0, mode);
    }

    /** Победа в BedWars: economy.bedwars-win-echo (50) Эхо * множители, в пределах дневного лимита игр. */
    public void addBedwarsWinEcho(Player winner) {
        grantGameEcho(winner, plugin.getConfig().getDouble("economy.bedwars-win-echo", 50), Modes.BEDWARS);
    }

    /** Победа в SkyWars: economy.skywars-win-echo (50) Эхо * множители, в пределах дневного лимита игр. */
    public void addSkywarsWinEcho(Player winner) {
        grantGameEcho(winner, plugin.getConfig().getDouble("economy.skywars-win-echo", 50), Modes.SKYWARS);
    }

    /** Эхо за поставленный блок в Выживании: economy.block-place-echo (0.05). */
    public double blockPlaceEcho() {
        return plugin.getConfig().getDouble("economy.block-place-echo", 0.05);
    }

    // ---------- дневной лимит Эхо в мини-играх (сброс в 00:00 МСК) ----------

    private static final String K_DAY = "mg_day";        // день (epochDay по МСК), за который ведётся счёт
    private static final String K_EARNED = "mg_earned";  // получено Эхо за день, в тысячных долях
    private static final String K_NOTICE = "mg_notice";  // день, когда игроку уже показали сообщение о лимите

    /** economy.minigames-daily-limit: максимум Эхо в сутки из игр (по умолчанию 300). */
    public double minigamesDailyLimit() {
        return plugin.getConfig().getDouble("economy.minigames-daily-limit", 300);
    }

    /**
     * Начисляет base * множители, но не больше остатка дневного лимита.
     * Лимит исчерпан — Эхо не начисляется, игроку один раз за день сообщается об этом.
     */
    private void grantGameEcho(Player p, double base, String mode) {
        long today = LocalDate.now(QuestManager.MSK).toEpochDay();
        UUID id = p.getUniqueId();
        if (data.getLong(id, K_DAY, -1) != today) {
            data.setLong(id, K_DAY, today);
            data.setLong(id, K_EARNED, 0);
        }
        long limit = Math.round(minigamesDailyLimit() * 1000);
        long earned = data.getLong(id, K_EARNED, 0);
        long want = Math.round(base * totalMultiplier(p, mode) * 1000);
        long pay = Math.min(want, limit - earned);
        if (pay <= 0) {
            if (data.getLong(id, K_NOTICE, -1) != today) {
                data.setLong(id, K_NOTICE, today);
                p.sendMessage("§cДневной лимит Эхо в играх исчерпан!");
            }
            return;
        }
        data.setLong(id, K_EARNED, earned + pay);
        credit(p, pay / 1000.0);
        if (pay < want && data.getLong(id, K_NOTICE, -1) != today) {
            data.setLong(id, K_NOTICE, today);
            p.sendMessage("§cДневной лимит Эхо в играх исчерпан!");
        }
    }
}
