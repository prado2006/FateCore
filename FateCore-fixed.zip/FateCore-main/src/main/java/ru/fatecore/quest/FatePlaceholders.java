package ru.fatecore.quest;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import ru.fatecore.FateCore; // <--- Проверь, что эта строчка есть!
import ru.fatecore.api.IDataStore;
import ru.fatecore.classes.ClassManager;
import ru.fatecore.combat.CombatManager;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.learn.BountyManager;
import ru.fatecore.learn.DailyService;
import ru.fatecore.learn.PlaytimeCommand;
import ru.fatecore.learn.PlaytimeTask;
import ru.fatecore.perks.HomeBonus;
import ru.fatecore.rotation.RotationManager;

import java.util.UUID;

public final class FatePlaceholders extends PlaceholderExpansion {

    private final FateCore plugin;
    private final QuestManager quests;
    private final EchoManager echo;
    private final ClassManager classes;
    private final RotationManager rotation;
    private final HomeBonus homeBonus;
    private final IDataStore dataStore;
    private final DailyService daily;
    private final BountyManager bounties;
    private final CombatManager combat;

    public FatePlaceholders(FateCore plugin, QuestManager quests, EchoManager echo, ClassManager classes,
                            RotationManager rotation, HomeBonus homeBonus, IDataStore dataStore,
                            DailyService daily, BountyManager bounties, CombatManager combat) {
        this.plugin = plugin;
        this.quests = quests;
        this.echo = echo;
        this.classes = classes;
        this.rotation = rotation;
        this.homeBonus = homeBonus;
        this.dataStore = dataStore;
        this.daily = daily;
        this.bounties = bounties;
        this.combat = combat;
    }

    @Override
    public String getIdentifier() { return "fatecore"; }

    @Override
    public String getAuthor() { return "FateCore"; }

    @Override
    public String getVersion() { return plugin.getDescription().getVersion(); }

    @Override
    public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (player == null) return "";
        UUID id = player.getUniqueId();

        switch (params.toLowerCase()) {
            case "class": return classes.getTitle(id);
            case "echo": return echo.format(echo.getEcho(player));
            case "quest_progress": return quests.progressString(id);
            case "quest_done": return quests.dayCompleted(id) + "/3";
            case "featured": {
                String mode = rotation.getBoostedMode();
                return (mode == null || mode.isEmpty()) ? "" : mode.substring(0, 1).toUpperCase() + mode.substring(1);
            }
            case "home": return player.isOnline() ? String.valueOf(homeBonus.limit(player.getPlayer())) : "0";
            case "playtime": return PlaytimeCommand.format(dataStore.getLong(id, PlaytimeTask.KEY, 0));
            case "streak": return String.valueOf(daily.effectiveStreak(id));
            case "bounty": return String.valueOf(bounties.get(id));
            case "combat": return player.isOnline() && combat.isTagged(id) ? "Да" : "Нет";
            default: return null;
        }
    }
}
