package ru.fatecore.menu;

import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.Plugin;
import ru.fatecore.util.Auth;
import ru.fatecore.util.Modes;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * ПКМ по жителю (Villager) в лобби мини-игры выполняет вход в игру от имени игрока:
 * bedwars_lobby → bw join arena1, skywars_lobby → swm join sky1 (команды в config.yml: minigames.*).
 * Команда выполняется ТОЛЬКО от имени игрока (с его правами), не от консоли.
 */
public final class MinigameJoinListener implements Listener {
    private static final long COOLDOWN_MS = 1000;

    private final Plugin plugin;
    private final Map<UUID, Long> last = new HashMap<>();

    public MinigameJoinListener(Plugin plugin) {
        this.plugin = plugin;
    }

    private String commandFor(String world) {
        if (world.equals(Modes.bedwarsLobby())) {
            return plugin.getConfig().getString("minigames.bedwars-join", "bw join arena1");
        }
        if (world.equals(Modes.skywarsLobby())) {
            return plugin.getConfig().getString("minigames.skywars-join", "swm join sky1");
        }
        return null;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEntityEvent e) {
        if (!(e.getRightClicked() instanceof Villager)) return;
        Player p = e.getPlayer();
        String cmd = commandFor(p.getWorld().getName());
        if (cmd == null || cmd.isBlank()) return;

        e.setCancelled(true); // без окна торговли
        // клиент шлёт INTERACT_AT и INTERACT: команду выполняем один раз
        if (e instanceof PlayerInteractAtEntityEvent) return;
        if (e.getHand() != EquipmentSlot.HAND) return;

        if (!Auth.isAuthed(p)) {
            p.sendMessage(MenuItems.text("&cСначала /login"));
            return;
        }
        long now = System.currentTimeMillis();
        Long t = last.get(p.getUniqueId());
        if (t != null && now - t < COOLDOWN_MS) return;
        last.put(p.getUniqueId(), now);

        p.performCommand(cmd.startsWith("/") ? cmd.substring(1) : cmd);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        last.remove(e.getPlayer().getUniqueId());
    }
}
