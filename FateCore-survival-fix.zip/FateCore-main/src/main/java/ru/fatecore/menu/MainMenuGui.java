package ru.fatecore.menu;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import ru.fatecore.classes.ClassManager;
import ru.fatecore.util.Modes;

import java.util.ArrayList;
import java.util.List;

public final class MainMenuGui implements Listener {
    private static final int SIZE = 27;

    public static final class Holder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    private final Plugin plugin;
    private final ClassManager classes;
    private final HelpGui helpGui;
    private final DonateGui donateGui;
    private final TeleportGui teleportGui;

    public MainMenuGui(Plugin plugin, ClassManager classes, HelpGui helpGui, DonateGui donateGui, TeleportGui teleportGui) {
        this.plugin = plugin;
        this.classes = classes;
        this.helpGui = helpGui;
        this.donateGui = donateGui;
        this.teleportGui = teleportGui;
    }

    public void open(Player p) {
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, MenuItems.text("&8Главное меню"));
        holder.inventory = inv;

        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        filler.editMeta(m -> m.displayName(MenuItems.text("&r")));
        for (int i = 0; i < SIZE; i++) inv.setItem(i, filler);

        inv.setItem(10, button(Material.IRON_SWORD, "&6Выбор класса", List.of("&7Выбери свой путь: Кузнец, Воин или Странник.")));
        
        int survOnline = Modes.players(Modes.survivalWorld());
        int bwOnline = Modes.players(Modes.bedwarsLobby(), Modes.bedwarsArena());
        int swOnline = Modes.players(Modes.skywarsLobby(), Modes.skywarsArena());

        List<String> teleportLore = new ArrayList<>();
        teleportLore.add("&7Выбери режим:");
        teleportLore.add("&aSurvival &7(Игроков: " + survOnline + ")");
        teleportLore.add("&cBedWars &7(Игроков: " + bwOnline + ")");
        teleportLore.add("&bSkyWars &7(Игроков: " + swOnline + ")");
        
        inv.setItem(12, button(Material.COMPASS, "&6Телепортация", teleportLore));
        inv.setItem(14, button(Material.NETHER_STAR, "&6Привилегии", List.of("&7Узнай о донат-тирах и поддержи проект.")));
        inv.setItem(16, button(Material.BOOK, "&6Помощь и правила", List.of("&7Все команды сервера и полезные советы.")));

        p.openInventory(inv);
    }

    private ItemStack button(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        item.editMeta(m -> {
            m.displayName(MenuItems.text(name));
            m.lore(lore.stream().map(MenuItems::text).toList());
        });
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;

        switch (e.getSlot()) {
            case 10 -> { p.closeInventory(); classes.openGui(p); }
            case 14 -> { p.closeInventory(); donateGui.open(p); }
            case 16 -> { p.closeInventory(); helpGui.open(p); }
            case 12 -> {
                p.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> teleportGui.open(p));
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
