package ru.fatecore.learn;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.fatecore.api.IDataStore;
import ru.fatecore.api.IEchoService;
import ru.fatecore.util.Modes;

import java.util.UUID;

public final class BountyCommand implements CommandExecutor {
    /** Минимальная награда за голову. */
    public static final long MIN_AMOUNT = 100;
    /** Комиссия поверх награды: при награде 100 списывается 110. */
    public static final int COMMISSION_PERCENT = 10;
    /** Кулдаун между назначениями награды одним игроком (1 час). */
    public static final long COOLDOWN_MS = 60L * 60 * 1000;
    private static final String K_LAST = "bounty.last";

    private final IEchoService echo;
    private final BountyManager bounties;
    private final IDataStore store;

    public BountyCommand(IEchoService echo, BountyManager bounties, IDataStore store) {
        this.echo = echo;
        this.bounties = bounties;
        this.store = store;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Только для игроков.");
            return true;
        }
        if (Modes.isMinigameWorld(p.getWorld())) {
            p.sendMessage("§cВ мини-играх нельзя назначать награды за голову.");
            return true;
        }
        if (args.length < 2) {
            p.sendMessage("§7Использование: §e/bounty <ник> <сумма>");
            p.sendMessage("§7Минимум: §e" + MIN_AMOUNT + " Эхо§7. Комиссия: §e" + COMMISSION_PERCENT + "%§7.");
            return true;
        }

        long now = System.currentTimeMillis();
        long left = store.getLong(p.getUniqueId(), K_LAST, 0) + COOLDOWN_MS - now;
        if (left > 0) {
            p.sendMessage("§cСледующую награду можно назначить через §e" + ((left + 59_999) / 60_000) + " мин§c.");
            return true;
        }

        UUID targetId;
        String targetName;
        Player online = Bukkit.getPlayerExact(args[0]);
        if (online != null) {
            targetId = online.getUniqueId();
            targetName = online.getName();
        } else {
            OfflinePlayer off = Bukkit.getOfflinePlayerIfCached(args[0]);
            if (off == null || !off.hasPlayedBefore()) {
                p.sendMessage("§cИгрок не найден.");
                return true;
            }
            targetId = off.getUniqueId();
            targetName = off.getName() != null ? off.getName() : args[0];
        }
        
        if (online != null && Modes.isMinigameWorld(online.getWorld())) {
            p.sendMessage("§cЭтот игрок сейчас в мини-игре.");
            return true;
        }
        if (targetId.equals(p.getUniqueId())) {
            p.sendMessage("§cНельзя назначить награду за свою голову.");
            return true;
        }

        long amount;
        try {
            amount = Long.parseLong(args[1]);
        } catch (NumberFormatException e) {
            p.sendMessage("§cСумма должна быть целым числом.");
            return true;
        }
        
        if (amount < MIN_AMOUNT) {
            p.sendMessage("§cМинимальная награда — §e" + MIN_AMOUNT + " Эхо§c.");
            return true;
        }
        
        long fee = (amount * COMMISSION_PERCENT + 99) / 100; // округление вверх
        long cost = amount + fee;
        if (!echo.withdraw(p.getUniqueId(), cost)) {
            p.sendMessage("§cНедостаточно Эхо: нужно §e" + cost + " §c(награда " + amount + " + комиссия "
                    + fee + "). Ваш баланс: §e" + echo.getBalance(p.getUniqueId()));
            return true;
        }

        store.setLong(p.getUniqueId(), K_LAST, now);
        long total = bounties.add(targetId, targetName, amount);
        Bukkit.broadcast(net.kyori.adventure.text.Component.text("§6[Баунти] §eИгрок " + p.getName() + " назначил награду §c" + amount
                + " Эхо §eза голову игрока " + targetName + "!"));
        p.sendMessage("§7Списано §e" + cost + " Эхо §7(награда " + amount + " + комиссия " + fee + ").");
        p.sendMessage("§7Общая награда за голову §f" + targetName + "§7: §e" + total + " Эхо");
        return true;
    }
}
