package ru.fatecore.onboarding;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Защита от ботов: при входе в чат приходит кликабельная ссылка [Я НЕ РОБОТ] (запускает /notrobot).
 * Пока игрок не нажал, /reg и /login (и любые другие команды), движение и чат заблокированы.
 * Нажал — блокировки снимаются, можно вводить /reg или /login.
 * Не нажал за antibot.timeout-seconds (60) — кик.
 * Настройки: antibot.* в config.yml (enabled, timeout-seconds, bypass-permission).
 */
public final class AntiBotListener implements Listener, CommandExecutor {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();
    private static final Component KICK_REASON = LEGACY.deserialize("§cПроверка не пройдена.");
    private static final Component PROMPT = LEGACY
            .deserialize("§c[!] Для подтверждения, что вы не робот, зажмите §eCtrl §cи нажмите на ссылку: ")
            .append(LEGACY.deserialize("§a[Я НЕ РОБОТ]")
                    .clickEvent(ClickEvent.runCommand("/notrobot"))
                    .hoverEvent(HoverEvent.showText(LEGACY.deserialize("§7Нажмите, чтобы подтвердить"))));
    private static final String PASSED = "§aПроверка пройдена! Теперь введите /reg <пароль> <пароль>";
    private static final String BLOCKED = "§cСначала нажмите на ссылку [Я НЕ РОБОТ] в чате.";

    private final Plugin plugin;
    /** Игроки, не прошедшие проверку, и их задачи-кики. */
    private final Map<UUID, BukkitTask> pending = new ConcurrentHashMap<>();

    public AntiBotListener(Plugin plugin) {
        this.plugin = plugin;
    }

    public boolean isPending(Player p) {
        return pending.containsKey(p.getUniqueId());
    }

    // ---------- вход / выход ----------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        if (!plugin.getConfig().getBoolean("antibot.enabled", true)) return;
        Player p = e.getPlayer();
        String bypass = plugin.getConfig().getString("antibot.bypass-permission", "fatecore.antibot.bypass");
        if (bypass != null && !bypass.isEmpty() && p.hasPermission(bypass)) return;

        long ticks = Math.max(1, plugin.getConfig().getInt("antibot.timeout-seconds", 60)) * 20L;
        BukkitTask kick = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (pending.remove(p.getUniqueId()) != null && p.isOnline()) {
                p.kick(KICK_REASON);
            }
        }, ticks);
        BukkitTask old = pending.put(p.getUniqueId(), kick);
        if (old != null) old.cancel();

        p.sendMessage(PROMPT);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        BukkitTask t = pending.remove(e.getPlayer().getUniqueId());
        if (t != null) t.cancel();
    }

    /** /notrobot — вызывается кликом по ссылке в чате. */
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        BukkitTask t = pending.remove(p.getUniqueId());
        if (t == null) return true; // уже прошёл проверку (или она выключена) — молча
        t.cancel();
        p.sendMessage(PASSED);
        return true;
    }

    // ---------- блокировки до прохождения проверки ----------

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (pending.isEmpty() || !isPending(e.getPlayer())) return; // самый частый event сервера
        if (e.getTo() == null) return;
        if (e.getFrom().getX() != e.getTo().getX() || e.getFrom().getY() != e.getTo().getY()
                || e.getFrom().getZ() != e.getTo().getZ()) {
            e.setCancelled(true);
        }
    }

    /** Только отменяет сообщение, формат чата и префиксы не трогает. */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        if (!pending.isEmpty() && isPending(e.getPlayer())) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(BLOCKED);
        }
    }

    /** До клика запрещены все команды (включая /reg и /login), кроме самого /notrobot. */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (pending.isEmpty() || !isPending(e.getPlayer())) return;
        String msg = e.getMessage();
        int sp = msg.indexOf(' ');
        String name = (sp < 0 ? msg.substring(1) : msg.substring(1, sp)).toLowerCase(Locale.ROOT);
        if (name.equals("notrobot") || name.equals("fatecore:notrobot")) return;
        e.setCancelled(true);
        e.getPlayer().sendMessage(BLOCKED);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!pending.isEmpty() && e.getEntity() instanceof Player p && isPending(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (!pending.isEmpty() && isPending(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (!pending.isEmpty() && isPending(e.getPlayer())) e.setCancelled(true);
    }
}
