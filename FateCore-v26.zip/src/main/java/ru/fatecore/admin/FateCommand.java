package ru.fatecore.admin;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import ru.fatecore.FateCore;
import ru.fatecore.api.IDataStore;
import ru.fatecore.classes.ClassManager;
import ru.fatecore.earn.EarnService;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.learn.CaseItems;
import ru.fatecore.quest.QuestManager;
import ru.fatecore.quest.QuestNpc;
import ru.fatecore.stats.StatsService;
import ru.fatecore.util.Items;
import ru.fatecore.util.Msg;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Map;
import java.util.UUID;

/**
 * МОДУЛЬ 8 — /fatecore.
 *   reload                          — fatecore.reload (admin, owner)
 *   class                           — fatecore.class.use
 *   npc, bwwin, boost, case         — fatecore.admin.* (только owner и консоль)
 *   donated <ник> <ранг>            — ТОЛЬКО консоль: объявление о покупке привилегии на весь сервер (EasyDonate)
 *   buyecho <ник> <кол-во>          — ТОЛЬКО консоль: Эхо за реальные деньги, лимит economy.weekly-echo-limit в неделю
 * Консоль (ConsoleCommandSender) всегда проходит проверку прав для bwwin.
 * Безопасность: эта команда НЕ выполняет консольные команды и НЕ выдаёт права/группы; боевые подкоманды
 * (npc, bwwin, boost, case, reload) закрыты правами fatecore.* (по умолчанию только owner/консоль).
 * boost и case вызываются из shop.rewards (консоль). Привилегий и донат-групп эти команды не выдают.
 */
public final class FateCommand implements CommandExecutor {
    private static final String USAGE = "&7/fatecore <reload|class|npc|bwwin|swwin|boost|case|donated|buyecho>";
    private static final String SERVER_PREFIX = "§6[Сервер]§r ";

    private final FateCore plugin;
    private final ClassManager classes;
    private final QuestNpc npc;
    private final QuestManager quests;
    private final EarnService earn;
    private final EchoManager echo;
    private final StatsService stats;
    private final IDataStore data;
    private final Runnable reloadHook;

    public FateCommand(FateCore plugin, ClassManager classes, QuestNpc npc, QuestManager quests,
                       EarnService earn, EchoManager echo, StatsService stats, IDataStore data, Runnable reloadHook) {
        this.plugin = plugin;
        this.classes = classes;
        this.npc = npc;
        this.quests = quests;
        this.earn = earn;
        this.echo = echo;
        this.stats = stats;
        this.data = data;
        this.reloadHook = reloadHook;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            Msg.send(sender, USAGE);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                if (!sender.hasPermission("fatecore.reload")) {
                    Msg.send(sender, "&cНет прав.");
                    return true;
                }
                plugin.reloadConfig();
                npc.respawn();
                reloadHook.run();
                Msg.send(sender, "&aКонфиг FateCore перезагружен.");
            }
            case "class" -> {
                if (!(sender instanceof Player p)) {
                    Msg.send(sender, "Только для игроков.");
                    return true;
                }
                classes.openGui(p); // право/ограничение новичка проверяет ClassManager при выборе
            }
            case "npc" -> {
                if (!sender.hasPermission("fatecore.admin.npc")) {
                    Msg.send(sender, "&cНет прав.");
                    return true;
                }
                boolean ok = npc.respawn();
                Msg.send(sender, ok ? "&aКвестовый Мастер пересоздан в quest.npc.location." : "&cМир из quest.npc.location не загружен.");
            }
            case "bwwin" -> bwWin(sender, args);
            case "swwin" -> swWin(sender, args);
            case "boost" -> boost(sender, args);
            case "case" -> giveCase(sender, args);
            case "donated" -> donated(sender, args);
            case "buyecho" -> buyEcho(sender, args);
            default -> Msg.send(sender, USAGE);
        }
        return true;
    }

    /**
     * /fatecore donated <ник> <ранг> — только консоль (вызывается EasyDonate после выдачи группы).
     * Ничего не выдаёт: только объявление всему серверу.
     */
    private void donated(CommandSender sender, String[] args) {
        if (!(sender instanceof ConsoleCommandSender)) {
            Msg.send(sender, "&cЭта команда доступна только консоли.");
            return;
        }
        if (args.length < 3) {
            sender.sendMessage("Использование: fatecore donated <ник> <ранг>");
            return;
        }
        String name = args[1].replace('§', ' ').replace('&', ' ');
        String rank = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)).replace('§', ' ').replace('&', ' ');
        Bukkit.broadcast(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(
                "§6§l[Донат] §eИгрок §f" + name + " §eприобрёл привилегию §6" + rank + "§e! Спасибо за поддержку!"));
    }

    /** /fatecore bwwin <ник> — засчитать победу в BedWars (Эхо + квест). Консоль всегда допускается. */
    private void bwWin(CommandSender sender, String[] args) {
        boolean allowed = sender instanceof ConsoleCommandSender
                || sender.hasPermission("fatecore.admin.bwwin");
        if (!allowed) {
            serverMsg(sender, "§cУ вас нет прав на эту команду.");
            return;
        }
        if (args.length < 2) {
            serverMsg(sender, "§7Использование: /fatecore bwwin <ник>");
            return;
        }

        String name = args[1];
        Player target = Bukkit.getPlayerExact(name);
        if (target == null) {
            // Проверяем, знает ли сервер такого игрока (для понятного сообщения).
            OfflinePlayer off = Bukkit.getOfflinePlayerIfCached(name);
            if (off == null) {
                serverMsg(sender, "§cИгрок не найден: §f" + name);
            } else {
                serverMsg(sender, "§cИгрок §f" + name + " §cсейчас не в сети — победа не засчитана.");
            }
            return;
        }

        earn.addBedwarsWinEcho(target);
        quests.addProgress(target, QuestManager.Type.BEDWARS_WIN, 1);
        stats.addWin(target.getUniqueId());

        serverMsg(sender, "§aПобеда засчитана: §f" + target.getName());
        serverMsg(sender, "§aЭхо за победу начислено: §f" + target.getName() + "§a, квест BedWars засчитан.");
    }

    /** /fatecore swwin <ник> — засчитать победу в SkyWars (Эхо + квест + /stats). Консоль всегда допускается. */
    private void swWin(CommandSender sender, String[] args) {
        boolean allowed = sender instanceof ConsoleCommandSender || sender.hasPermission("fatecore.admin.swwin");
        if (!allowed) {
            serverMsg(sender, "§cУ вас нет прав на эту команду.");
            return;
        }
        if (args.length < 2) {
            serverMsg(sender, "§7Использование: /fatecore swwin <ник>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            serverMsg(sender, "§cИгрок не в сети: §f" + args[1]);
            return;
        }
        earn.addSkywarsWinEcho(target);
        quests.addProgress(target, QuestManager.Type.SKYWARS_WIN, 1);
        stats.addWin(target.getUniqueId());
        serverMsg(sender, "§aПобеда в SkyWars засчитана: §f" + target.getName() + "§a (Эхо начислено, квест и статистика обновлены).");
    }

    /**
     * Сообщение от имени Сервера: отправителю команды и в консоль (если отправитель — игрок).
     */
    private void serverMsg(CommandSender sender, String text) {
        String full = SERVER_PREFIX + text;
        sender.sendMessage(full);
        if (!(sender instanceof ConsoleCommandSender)) {
            Bukkit.getConsoleSender().sendMessage(full);
        }
    }

    /** /fatecore boost <игрок> <множитель 1.0–5.0> <секунды ≤ 604800> — временный множитель Эхо. */
    private void boost(CommandSender sender, String[] args) {
        if (!sender.hasPermission("fatecore.admin.boost")) {
            Msg.send(sender, "&cНет прав.");
            return;
        }
        if (args.length < 4) {
            Msg.send(sender, "&7/fatecore boost <игрок> <множитель> <секунды>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            Msg.send(sender, "&cИгрок не в сети.");
            return;
        }
        double mult;
        long seconds;
        try {
            mult = Double.parseDouble(args[2]);
            seconds = Long.parseLong(args[3]);
        } catch (NumberFormatException e) {
            Msg.send(sender, "&cМножитель и секунды должны быть числами.");
            return;
        }
        if (mult < 1.0 || mult > 5.0 || seconds < 1 || seconds > 604800) {
            Msg.send(sender, "&cМножитель 1.0–5.0, секунды 1–604800.");
            return;
        }
        echo.addBoost(target.getUniqueId(), mult, seconds);
        Msg.send(sender, "&aБуст x" + mult + " на " + seconds + " с выдан: " + target.getName());
    }

    /**
     * /fatecore case <игрок> <common|rare> [возврат_Эхо] — выдаёт предмет-кейс (сундук).
     * Если инвентарь полон: при указанной сумме Эхо возвращается игроку (кейс не выдан), иначе предмет выпадает под ноги.
     */
    private void giveCase(CommandSender sender, String[] args) {
        if (!sender.hasPermission("fatecore.admin.case")) {
            Msg.send(sender, "&cНет прав.");
            return;
        }
        if (args.length < 3 || !(args[2].equalsIgnoreCase("common") || args[2].equalsIgnoreCase("rare"))) {
            Msg.send(sender, "&7/fatecore case <игрок> <common|rare> [возврат_Эхо]");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            Msg.send(sender, "&cИгрок не в сети.");
            return;
        }
        int refund = 0;
        if (args.length >= 4) {
            try {
                refund = Math.max(0, Integer.parseInt(args[3]));
            } catch (NumberFormatException e) {
                Msg.send(sender, "&cСумма возврата должна быть числом.");
                return;
            }
        }
        boolean rare = args[2].equalsIgnoreCase("rare");
        ItemStack item = CaseItems.make(plugin, rare); // CHEST / ENDER_CHEST с меткой кейса
        Map<Integer, ItemStack> left = target.getInventory().addItem(item);
        if (left.isEmpty()) {
            Msg.send(sender, "&aКейс " + args[2].toLowerCase() + " выдан: " + target.getName());
            return;
        }
        if (refund > 0) {
            echo.addEcho(target, refund);
            Msg.send(target, "&cИнвентарь полон — кейс не выдан. Эхо возвращено: &e" + refund + " Эхо&c. Освободите слот и купите снова.");
            Msg.send(sender, "&eУ " + target.getName() + " полный инвентарь: возвращено " + refund + " Эхо.");
        } else {
            Items.give(target, left.values().iterator().next());
            Msg.send(target, "&eИнвентарь полон — кейс выпал под ноги.");
            Msg.send(sender, "&aКейс " + args[2].toLowerCase() + " выпал под ноги: " + target.getName());
        }
    }

    // ---------- Эхо за реальные деньги ----------

    private static final String K_BUY_WEEK = "buyecho_week";
    private static final String K_BUY_USED = "buyecho_used";

    /** Номер недели (epochDay понедельника по МСК): счётчик сбрасывается в понедельник 00:00 МСК. */
    private static long weekKey() {
        return LocalDate.now(QuestManager.MSK).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toEpochDay();
    }

    /** /fatecore buyecho <ник> <кол-во> — только консоль (EasyDonate). Не более economy.weekly-echo-limit в неделю. */
    private void buyEcho(CommandSender sender, String[] args) {
        if (!(sender instanceof ConsoleCommandSender)) {
            Msg.send(sender, "&cКоманда доступна только из консоли.");
            return;
        }
        if (args.length < 3) {
            Msg.send(sender, "&7/fatecore buyecho <ник> <кол-во>");
            return;
        }
        int amount;
        try {
            amount = Integer.parseInt(args[2]);
        } catch (NumberFormatException e) {
            Msg.send(sender, "&cКоличество должно быть целым числом.");
            return;
        }
        if (amount <= 0) {
            Msg.send(sender, "&cКоличество должно быть больше нуля.");
            return;
        }
        Player online = Bukkit.getPlayerExact(args[1]);
        OfflinePlayer target = online != null ? online : Bukkit.getOfflinePlayer(args[1]);
        if (online == null && !target.hasPlayedBefore()) {
            Msg.send(sender, "&cИгрок " + args[1] + " ни разу не заходил на сервер.");
            return;
        }
        UUID id = target.getUniqueId();
        long week = weekKey();
        if (data.getLong(id, K_BUY_WEEK, -1) != week) {
            data.setLong(id, K_BUY_WEEK, week);
            data.setLong(id, K_BUY_USED, 0);
        }
        long limit = plugin.getConfig().getLong("economy.weekly-echo-limit", 100);
        long used = data.getLong(id, K_BUY_USED, 0);
        if (used + amount > limit) {
            Msg.send(sender, "&cЛимит покупки Эхо за неделю превышен: " + args[1] + " уже купил " + used + " из "
                    + limit + " (запрошено " + amount + "). Начисление отменено.");
            if (online != null) {
                Msg.send(online, "&cЛимит покупки Эхо за деньги — " + limit + " в неделю (осталось "
                        + Math.max(0, limit - used) + "). Обратитесь к администрации.");
            }
            return;
        }
        data.setLong(id, K_BUY_USED, used + amount);
        echo.addEcho(target, amount);
        Msg.send(sender, "&aНачислено " + amount + " Эхо игроку " + args[1] + " (за неделю " + (used + amount) + "/" + limit + ").");
        if (online != null) {
            Msg.send(online, "&aВы получили &e" + amount + " Эхо &aза покупку. Спасибо за поддержку сервера!");
        }
    }
}
