package ru.fatecore.menu;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.plugin.Plugin;

import java.util.Locale;
import java.util.Set;

/**
 * Локализация эндер-сундука: /enderchest (/echest, /ec) открывает собственное меню на 27 слотов
 * «Персональный сундук», которое показывает и редактирует настоящий эндер-сундук игрока.
 * Содержимое синхронизируется с эндер-сундуком после каждого клика и при закрытии (предметы не теряются).
 * Команда с ником (/enderchest <игрок>) и игроки без права essentials.enderchest обрабатываются Essentials как обычно.
 */
public final class PersonalChestGui implements Listener {
    private static final Component TITLE = LegacyComponentSerializer.legacySection().deserialize("§8Персональный сундук");
    private static final Set<String> ALIASES = Set.of(
            "enderchest", "echest", "ec", "essentials:enderchest", "essentials:echest", "essentials:ec");

    /** Маркер меню (используется и защитой Творческого режима). */
    public static final class Holder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    private final Plugin plugin;

    public PersonalChestGui(Plugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String msg = e.getMessage();
        if (msg.length() < 3) return;
        String trimmed = msg.trim();
        int sp = trimmed.indexOf(' ');
        if (sp >= 0) return; // /enderchest <игрок> — не наш случай
        if (!ALIASES.contains(trimmed.substring(1).toLowerCase(Locale.ROOT))) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("essentials.enderchest")) return;
        e.setCancelled(true);
        open(p);
    }

    public void open(Player p) {
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, 27, TITLE);
        holder.inventory = inv;
        inv.setContents(p.getEnderChest().getContents());
        p.openInventory(inv);
    }

    private static void sync(Player p, Inventory custom) {
        p.getEnderChest().setContents(custom.getContents());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder) || !(e.getWhoClicked() instanceof Player p)) return;
        Bukkit.getScheduler().runTask(plugin, () -> sync(p, top)); // после применения клика
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder) || !(e.getWhoClicked() instanceof Player p)) return;
        Bukkit.getScheduler().runTask(plugin, () -> sync(p, top));
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getInventory().getHolder() instanceof Holder && e.getPlayer() instanceof Player p) {
            sync(p, e.getInventory());
        }
    }
}
