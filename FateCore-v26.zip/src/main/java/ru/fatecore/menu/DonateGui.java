package ru.fatecore.menu;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class DonateGui implements Listener {

    private static final int SIZE = 54;
    private static final int SLOT_INFO = 4;
    private static final int SLOT_CLOSE = 49;

    /** id = ключ в config.yml (donate.tiers.<id> и donate-multipliers.<id>). */
    private enum Tier {
        VIP("vip", "VIP", Material.GOLD_INGOT, 10),
        PREMIUM("premium", "Премиум", Material.DIAMOND, 12),
        LEGEND("legend", "Легенда", Material.EMERALD, 14),
        ELITE("elite", "Элита", Material.AMETHYST_SHARD, 16),
        MYTHIC("mythic", "Мифик", Material.NETHERITE_INGOT, 28),
        TITAN("titan", "Титан", Material.DRAGON_EGG, 30),
        HERO("hero", "Герой Эха", Material.NETHER_STAR, 32),
        OVERLORD("overlord", "Владыка Судьбы", Material.BEACON, 34);

        final String id;
        final String title;
        final Material icon;
        final int slot;

        Tier(String id, String title, Material icon, int slot) {
            this.id = id;
            this.title = title;
            this.icon = icon;
            this.slot = slot;
        }
    }

    public static final class Holder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    private final Plugin plugin;

    public DonateGui(Plugin plugin) {
        this.plugin = plugin;
    }

    private static final Component TITLE = MenuItems.text("§6Привилегии (Донат)");

    /** Шаблон меню: заполнитель, «Как купить?», «Закрыть» — один раз; предметы тиров — по конфигу (пересборка при reload). */
    private ItemStack[] template;
    private FileConfiguration templateCfg;

    private ItemStack[] template() {
        FileConfiguration cfg = plugin.getConfig();
        ItemStack[] tpl = template;
        if (tpl == null || templateCfg != cfg) { // reloadConfig() создаёт новый объект конфигурации
            tpl = new ItemStack[SIZE];
            Arrays.fill(tpl, MenuItems.filler(Material.BLACK_STAINED_GLASS_PANE));
            for (Tier t : Tier.values()) {
                tpl[t.slot] = tierItem(cfg, t);
            }
            tpl[SLOT_INFO] = MenuItems.button(Material.BOOK, "§eКак купить?",
                    "§7Выбери привилегию и нажми на неё —",
                    "§7в чат придёт ссылка на покупку.",
                    "",
                    "§aНажми, чтобы получить ссылку");
            tpl[SLOT_CLOSE] = MenuItems.button(Material.BARRIER, "§cЗакрыть");
            template = tpl;
            templateCfg = cfg;
        }
        return tpl;
    }

    public void open(Player player) {
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.inventory = inv;
        inv.setContents(template());
        player.openInventory(inv);
    }

    private ItemStack tierItem(FileConfiguration cfg, Tier t) {
        // Описание целиком берётся из config.yml (donate.tiers.<id>.perks): каждая строка — отдельная строка лора.
        List<String> lore = new ArrayList<>(cfg.getStringList("donate.tiers." + t.id + ".perks"));
        lore.add("");
        lore.add("§eЦена: §f" + cfg.getString("donate.tiers." + t.id + ".price", "—"));
        lore.add("§a▶ Нажми, чтобы получить ссылку на покупку!");

        ItemStack item = new ItemStack(t.icon);
        item.editMeta(m -> {
            m.displayName(MenuItems.text("§6Привилегия: " + t.title));
            m.lore(lore.stream().map(MenuItems::text).toList());
        });
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;

        int slot = e.getSlot();
        if (slot == SLOT_CLOSE) {
            p.closeInventory();
            return;
        }
        if (slot == SLOT_INFO) {
            p.closeInventory();
            sendLink(p, null);
            return;
        }
        for (Tier t : Tier.values()) {
            if (t.slot == slot) {
                p.closeInventory();
                sendLink(p, t);
                return;
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    /** Кликабельная ссылка из donate.url. */
    private void sendLink(Player p, Tier tier) {
        String url = plugin.getConfig().getString("donate.url", "");
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            p.sendMessage(MenuItems.text("§cСсылка на донат не настроена. Обратитесь к администрации."));
            return;
        }
        String head = tier == null ? "§6Привилегии сервера §7— " : "§6Привилегия: " + tier.title + " §7— ";
        Component link = Component.text("[Открыть страницу покупки]", NamedTextColor.GREEN, TextDecoration.UNDERLINED)
                .clickEvent(ClickEvent.openUrl(url))
                .hoverEvent(HoverEvent.showText(MenuItems.text("§7" + url)));
        p.sendMessage(MenuItems.text(head).append(link));
    }
}
