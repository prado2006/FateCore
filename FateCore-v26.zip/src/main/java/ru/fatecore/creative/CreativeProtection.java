package ru.fatecore.creative;

import org.bukkit.GameMode;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.entity.ChestBoat;
import org.bukkit.entity.minecart.HopperMinecart;
import org.bukkit.entity.minecart.StorageMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.plugin.Plugin;
import ru.fatecore.menu.PersonalChestGui;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Защита экономики от Творческого режима:
 *  - в CREATIVE нельзя выбрасывать и подбирать предметы;
 *  - в CREATIVE нельзя открывать контейнеры (сундуки, бочки, воронки, шалкеры, эндер-сундук и т.п.);
 *  - при выходе из CREATIVE инвентарь полностью очищается (creative.clear-inventory-on-exit, по умолчанию true).
 * Меню FateCore (GUI) не блокируются. Право fatecore.creative.bypass снимает все ограничения (по умолчанию ни у кого нет).
 */
public final class CreativeProtection implements Listener {
    private static final String DENY = "§cВ режиме Творца нельзя передавать предметы!";
    private static final long MSG_COOLDOWN_MS = 2000L;

    private final Plugin plugin;
    private final Consumer<Player> afterClear;
    private final Map<UUID, Long> lastMsg = new HashMap<>();

    /** @param afterClear вызывается после очистки инвентаря (вернуть Компас и Звезду). */
    public CreativeProtection(Plugin plugin, Consumer<Player> afterClear) {
        this.plugin = plugin;
        this.afterClear = afterClear;
    }

    private static boolean guarded(Player p) {
        return p.getGameMode() == GameMode.CREATIVE && !p.hasPermission("fatecore.creative.bypass");
    }

    private void deny(Player p) {
        long now = System.currentTimeMillis();
        Long last = lastMsg.get(p.getUniqueId());
        if (last != null && now - last < MSG_COOLDOWN_MS) return;
        lastMsg.put(p.getUniqueId(), now);
        p.sendMessage(DENY);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        lastMsg.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        if (!guarded(p)) return;
        e.setCancelled(true);
        deny(p);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player p) || !guarded(p)) return;
        e.setCancelled(true);
        deny(p);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onOpen(InventoryOpenEvent e) {
        if (!(e.getPlayer() instanceof Player p) || !guarded(p)) return;
        Inventory inv = e.getInventory();
        InventoryHolder h = inv.getHolder();
        boolean container = inv.getType() == InventoryType.ENDER_CHEST
                || h instanceof Container
                || h instanceof org.bukkit.block.DoubleChest
                || h instanceof StorageMinecart
                || h instanceof HopperMinecart
                || h instanceof ChestBoat
                || h instanceof PersonalChestGui.Holder;
        if (!container) return; // меню FateCore, верстаки, торговля и т.п. разрешены
        e.setCancelled(true);
        deny(p);
    }

    /** Выход из Творчества — полная очистка инвентаря (иначе предметы из Творчества попадут в Выживание). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onGameModeChange(PlayerGameModeChangeEvent e) {
        Player p = e.getPlayer();
        if (p.getGameMode() != GameMode.CREATIVE || e.getNewGameMode() == GameMode.CREATIVE) return;
        if (p.hasPermission("fatecore.creative.bypass")) return;
        if (!plugin.getConfig().getBoolean("creative.clear-inventory-on-exit", true)) return;
        p.getInventory().clear(); // основной инвентарь, броня и вторая рука
        p.setItemOnCursor(null);
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) afterClear.accept(p);
        });
    }
}
