package ru.fatecore.world;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.plugin.Plugin;
import ru.fatecore.util.Modes;

/**
 * Безопасные зоны: мобы не спавнятся в лобби (main_lobby, bedwars_lobby, skywars_lobby) и на аренах
 * (world_bedwars, world_skywars). В мире Выживания (worlds.survival) спавн запрещён ближе
 * worlds.survival-spawn-radius (100) блоков к спавну мира; дальше — разрешён. Остальные миры (hub_the_end) не затрагиваются.
 * Спавн плагинами и командами (CUSTOM / COMMAND) не отменяется — иначе пропали бы Квестовый Мастер и NPC мини-игр.
 */
public final class MobSpawnListener implements Listener {
    private final Plugin plugin;

    public MobSpawnListener(Plugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        SpawnReason r = e.getSpawnReason();
        if (r == SpawnReason.CUSTOM || r == SpawnReason.COMMAND) return;
        LivingEntity ent = e.getEntity();
        World w = ent.getWorld();
        String name = w.getName();

        if (name.equals(Modes.mainLobby()) || name.equals(Modes.bedwarsLobby()) || name.equals(Modes.skywarsLobby())
                || name.equals(Modes.bedwarsArena()) || name.equals(Modes.skywarsArena())) {
            e.setCancelled(true);
            return;
        }
        if (name.equals(Modes.survivalWorld())) {
            double radius = plugin.getConfig().getDouble("worlds.survival-spawn-radius", 100);
            if (radius <= 0) return;
            Location spawn = w.getSpawnLocation();
            if (ent.getLocation().distanceSquared(spawn) < radius * radius) e.setCancelled(true);
        }
    }
}
