package ru.fatecore.learn;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import ru.fatecore.FateCore;
import ru.fatecore.api.IDataStore;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.perks.HomeBonus;
import ru.fatecore.quest.QuestManager;
import ru.fatecore.util.Msg;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Динамические бусты магазина: каждую неделю (понедельник 00:00 МСК) у каждого игрока свой список из 3-4
 * случайных бустов из config.yml → boosts.pool. Если право из skip-permission у игрока уже есть (например,
 * essentials.fly), такой буст не показывается. Покупок не больше boosts.daily-limit (3) в сутки.
 * Данные в IDataStore: boosts_week, boosts_list, boosts_day, boosts_bought.
 */
public final class BoostsManager {
    private static final String K_WEEK = "boosts_week";
    private static final String K_LIST = "boosts_list";
    private static final String K_DAY = "boosts_day";
    private static final String K_BOUGHT = "boosts_bought";

    /** Один буст из пула. type: "" (команды), "quest_reroll", "home_plus1". */
    public record Offer(String id, String name, Material icon, int price, List<String> commands,
                        String type, String skipPermission) {}

    private final FateCore plugin;
    private final EchoManager echo;
    private final IDataStore data;
    private final QuestManager quests;
    private final HomeBonus homeBonus;

    private FileConfiguration poolCfg;
    private Map<String, Offer> pool = Map.of();

    public BoostsManager(FateCore plugin, EchoManager echo, IDataStore data, QuestManager quests) {
        this.plugin = plugin;
        this.echo = echo;
        this.data = data;
        this.quests = quests;
        this.homeBonus = new HomeBonus(plugin);
    }

    // ---------- пул (кэш до перезагрузки конфига) ----------

    private Map<String, Offer> pool() {
        FileConfiguration cfg = plugin.getConfig();
        if (poolCfg == cfg) return pool;
        Map<String, Offer> out = new LinkedHashMap<>();
        ConfigurationSection root = cfg.getConfigurationSection("boosts.pool");
        if (root != null) {
            for (String id : root.getKeys(false)) {
                ConfigurationSection c = root.getConfigurationSection(id);
                if (c == null) continue;
                Material icon = Material.matchMaterial(c.getString("icon", "CLOCK"));
                String perm = c.getString("skip-permission");
                out.put(id, new Offer(id, c.getString("name", id), icon == null ? Material.CLOCK : icon,
                        c.getInt("price", 500), c.getStringList("commands"), c.getString("type", ""),
                        perm == null || perm.isBlank() ? null : perm));
            }
        }
        pool = out;
        poolCfg = cfg;
        return out;
    }

    // ---------- время ----------

    private static long today() {
        return LocalDate.now(QuestManager.MSK).toEpochDay();
    }

    private static long week() {
        return LocalDate.now(QuestManager.MSK).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toEpochDay();
    }

    private static int extraSlots(Player p) {
        if (p.hasPermission("fatecore.boosts.slots.2")) return 2;
        if (p.hasPermission("fatecore.boosts.slots.1")) return 1;
        return 0;
    }

    // ---------- личный список ----------

    private boolean owned(Player p, Offer o) {
        return o.skipPermission() != null && p.hasPermission(o.skipPermission());
    }

    /** Личные бусты игрока на эту неделю (без тех, чьё право у него уже есть). */
    public List<Offer> offers(Player p) {
        UUID id = p.getUniqueId();
        Map<String, Offer> all = pool();
        long week = week();
        String stored = data.getString(id, K_LIST, "");
        if (data.getLong(id, K_WEEK, -1) != week || stored.isEmpty()) {
            List<Offer> candidates = new ArrayList<>();
            for (Offer o : all.values()) if (!owned(p, o)) candidates.add(o);
            Collections.shuffle(candidates, ThreadLocalRandom.current());
            FileConfiguration cfg = plugin.getConfig();
            int min = Math.max(1, cfg.getInt("boosts.min-offers", 3));
            int max = Math.max(min, cfg.getInt("boosts.max-offers", 4));
            int count = Math.min(candidates.size(), ThreadLocalRandom.current().nextInt(min, max + 1) + extraSlots(p));
            List<String> ids = new ArrayList<>();
            for (int i = 0; i < count; i++) ids.add(candidates.get(i).id());
            stored = String.join(",", ids);
            data.setString(id, K_LIST, stored);
            data.setLong(id, K_WEEK, week);
        }
        List<Offer> out = new ArrayList<>();
        for (String oid : stored.split(",")) {
            Offer o = all.get(oid);
            if (o != null && !owned(p, o)) out.add(o);
        }
        return out;
    }

    public int dailyLimit() {
        return plugin.getConfig().getInt("boosts.daily-limit", 3);
    }

    public int boughtToday(UUID id) {
        return data.getLong(id, K_DAY, -1) == today() ? (int) data.getLong(id, K_BOUGHT, 0) : 0;
    }

    // ---------- покупка ----------

    public void buy(Player p, String offerId) {
        UUID id = p.getUniqueId();
        Offer offer = null;
        for (Offer o : offers(p)) if (o.id().equals(offerId)) offer = o;
        if (offer == null) {
            Msg.send(p, "&cЭтот буст сейчас недоступен.");
            return;
        }
        if (boughtToday(id) >= dailyLimit()) {
            Msg.send(p, "&cЛимит бустов на сегодня исчерпан (" + dailyLimit() + " в день). Новые — после 00:00 МСК.");
            return;
        }
        // проверки ДО списания Эхо
        if (offer.type().equals("quest_reroll")) {
            String why = quests.rerollBlocker(id);
            if (why != null) {
                Msg.send(p, "&c" + why);
                return;
            }
        } else if (offer.type().equals("home_plus1") && !homeBonus.canGrant(p)) {
            Msg.send(p, "&cМаксимум домов уже достигнут.");
            return;
        }
        if (!echo.take(p, offer.price())) {
            Msg.send(p, "&cНе хватает Эхо: нужно " + offer.price() + ", у тебя " + echo.format(echo.getEcho(p)));
            return;
        }
        try {
            switch (offer.type()) {
                case "quest_reroll" -> {
                    quests.reroll(id);
                    Msg.send(p, "&aКвесты обновлены! Откройте &e/quests");
                }
                case "home_plus1" -> {
                    if (!homeBonus.grant(p)) throw new IllegalStateException("лимит домов достигнут");
                }
                default -> {
                    if (offer.commands().isEmpty()) throw new IllegalStateException("нет команд выдачи");
                    ShopGui.runRewardCommands(plugin, p, offer.commands());
                }
            }
        } catch (RuntimeException e) {
            echo.addEcho(p, offer.price());
            Msg.send(p, "&cОшибка выдачи, Эхо возвращено.");
            plugin.getLogger().warning("Boost " + offer.id() + ": " + e.getMessage());
            return;
        }
        long today = today();
        if (data.getLong(id, K_DAY, -1) != today) {
            data.setLong(id, K_DAY, today);
            data.setLong(id, K_BOUGHT, 0);
        }
        data.setLong(id, K_BOUGHT, data.getLong(id, K_BOUGHT, 0) + 1);
        Msg.send(p, "&aКуплено: &6" + offer.name() + " &7(-" + offer.price() + " Эхо)");
    }
}
