package ru.fatecore.learn;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import ru.fatecore.FateCore;
import ru.fatecore.api.IDataStore;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.gui.FateHolder;
import ru.fatecore.perks.HomeBonus;
import ru.fatecore.util.Items;
import ru.fatecore.util.Msg;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * МОДУЛЬ 10 — /shop: GUI 27 слотов, категории и товары из learn.shop, оплата Эхо через Vault (EssentialsX).
 * Выдача: команды консоли из shop.rewards.<id>; если список пуст — встроенная выдача.
 * Донат-тиры через магазин не выдаются (команды с «parent» пропускаются).
 */
public final class ShopGui {

    private record Category(String key, int slot, String title, Material icon) {}

    private record Item(String id, String category, String name, Material mat, int price, int slot, boolean enabled,
                        List<String> lore) {}

    /** Вечное улучшение (уровни 0..prices.length): now[i] — что даёт уровень i+1, next[i] — подпись уровня i+1. */
    private record Upgrade(String key, String name, Material icon, int slot, int[] prices,
                           List<String> now, List<String> next) {
        int max() { return prices.length; }
    }

    private static final String CAT_BOOSTS = "boosts";
    private static final String CAT_UPGRADES = "upgrades";
    private static final int[] BOOST_SLOTS_3 = {11, 13, 15};
    private static final int[] BOOST_SLOTS_4 = {10, 12, 14, 16};
    private static final int[] BOOST_SLOTS_5 = {11, 12, 13, 14, 15};
    private static final int[] BOOST_SLOTS_6 = {10, 11, 12, 14, 15, 16};

    /**
     * Запрещённое в консольных наградах shop.rewards: выдача рангов/групп, op, wildcard-права,
     * управление сервером. Разрешены только узкие права-косметика (lp user ... permission set fatecore.cosmetic.*).
     */
    private static final Pattern FORBIDDEN = Pattern.compile(
            "(?i)\\b(parent|group|op|deop|stop|restart|reload|ban|ban-ip|pardon|sudo|execute|pex|permissions)\\b|\\*");

    private final FateCore plugin;
    private final EchoManager echo;
    private final HomeBonus homeBonus;
    private final IDataStore data;
    private final BoostsManager boosts;
    private java.util.function.Consumer<Player> purchaseHook;

    public ShopGui(FateCore plugin, EchoManager echo, IDataStore data, BoostsManager boosts) {
        this.plugin = plugin;
        this.echo = echo;
        this.data = data;
        this.boosts = boosts;
        this.homeBonus = new HomeBonus(plugin);
    }

    /** Вызывается после успешной покупки (для достижения «первая покупка»). */
    public void setPurchaseHook(java.util.function.Consumer<Player> hook) {
        this.purchaseHook = hook;
    }

    // ---------- чтение learn.shop (разбор и предметы кэшируются до перезагрузки конфига) ----------

    /** Разобранный learn.shop и готовые предметы. Пересобирается, когда reloadConfig() подменяет объект конфигурации. */
    private static final class Snapshot {
        final FileConfiguration cfg;
        final String title;
        final List<Category> categories = new ArrayList<>();
        final List<ItemStack> categoryIcons = new ArrayList<>();
        final List<Item> items = new ArrayList<>();
        final List<ItemStack> itemIcons = new ArrayList<>();
        final List<Upgrade> upgrades = new ArrayList<>();

        Snapshot(FileConfiguration cfg) {
            this.cfg = cfg;
            this.title = cfg.getString("learn.shop.title", "&8Магазин Эхо");
        }
    }

    private Snapshot snapshot;

    private Snapshot snap() {
        FileConfiguration cfg = plugin.getConfig();
        Snapshot s = snapshot;
        if (s == null || s.cfg != cfg) {
            s = build(cfg);
            snapshot = s;
        }
        return s;
    }

    private Snapshot build(FileConfiguration cfg) {
        Snapshot s = new Snapshot(cfg);

        ConfigurationSection cs = cfg.getConfigurationSection("learn.shop.categories");
        if (cs != null) {
            for (String key : cs.getKeys(false)) {
                ConfigurationSection c = cs.getConfigurationSection(key);
                if (c == null) continue;
                Material icon = Material.matchMaterial(c.getString("icon", "CHEST"));
                Category cat = new Category(key, c.getInt("slot"), c.getString("title", key),
                        icon == null ? Material.CHEST : icon);
                s.categories.add(cat);
                s.categoryIcons.add(Items.make(cat.icon(), "&6" + cat.title(), "&eКлик — открыть"));
            }
        }

        for (Map<?, ?> m : cfg.getMapList("learn.shop.items")) {
            Material mat = Material.matchMaterial(String.valueOf(m.get("icon")));
            Object price = m.get("price");
            Object slot = m.get("slot");
            if (mat == null || !(price instanceof Number) || !(slot instanceof Number)) {
                plugin.getLogger().warning("learn.shop.items: пропущен товар с неверными полями: " + m);
                continue;
            }
            Object en = m.get("enabled");
            List<String> extra = new ArrayList<>();
            if (m.get("lore") instanceof List<?> l) for (Object o : l) extra.add(String.valueOf(o));
            Item it = new Item(String.valueOf(m.get("id")), String.valueOf(m.get("category")),
                    String.valueOf(m.get("name")), mat, ((Number) price).intValue(),
                    ((Number) slot).intValue(), !(en instanceof Boolean b) || b, extra);
            s.items.add(it);
            if (it.enabled()) {
                List<String> lore = new ArrayList<>(it.lore());
                lore.add("&7Цена: &f" + it.price() + " Эхо");
                lore.add("&eКлик — купить");
                if (!it.category().equals("cases")) lore.add("&8Эхо не даёт силы в бою");
                s.itemIcons.add(Items.make(it.mat(), "&6" + it.name(), lore.toArray(new String[0])));
            } else {
                s.itemIcons.add(Items.make(Material.GRAY_DYE, "&7" + it.name(), "&cВременно недоступен"));
            }
        }

        ConfigurationSection us = cfg.getConfigurationSection("upgrades");
        if (us != null) {
            for (String key : us.getKeys(false)) {
                ConfigurationSection c = us.getConfigurationSection(key);
                if (c == null) continue;
                List<Integer> pr = c.getIntegerList("prices");
                if (pr.isEmpty()) continue;
                Material icon = Material.matchMaterial(c.getString("icon", "ANVIL"));
                s.upgrades.add(new Upgrade(key, c.getString("name", key), icon == null ? Material.ANVIL : icon,
                        c.getInt("slot", 13), pr.stream().mapToInt(Integer::intValue).toArray(),
                        c.getStringList("now"), c.getStringList("next")));
            }
        }
        return s;
    }

    // ---------- GUI ----------

    public void openMain(Player p) {
        Snapshot s = snap();
        FateHolder holder = new FateHolder("shop");
        Inventory inv = Bukkit.createInventory(holder, 27, Msg.c(s.title));
        holder.bind(inv);
        Items.fill(inv);
        for (int i = 0; i < s.categories.size(); i++) {
            inv.setItem(s.categories.get(i).slot(), s.categoryIcons.get(i));
        }
        inv.setItem(4, Items.make(Material.GOLD_INGOT, "&6Твоё Эхо: &f" + echo.format(echo.getEcho(p)))); // баланс — живое значение
        inv.setItem(22, Items.closeButton()); // симметрия: 10 / 12 / 14 / 16 — категории, 22 — «Закрыть»
        p.openInventory(inv);
    }

    private void openCategory(Player p, Category cat) {
        if (cat.key().equals(CAT_BOOSTS)) {
            openBoosts(p, cat);
            return;
        }
        if (cat.key().equals(CAT_UPGRADES)) {
            openUpgrades(p, cat);
            return;
        }
        Snapshot s = snap();
        FateHolder holder = new FateHolder("shop:" + cat.key());
        Inventory inv = Bukkit.createInventory(holder, 27, Msg.c("&8Магазин: " + cat.title()));
        holder.bind(inv);
        Items.fill(inv);
        for (int i = 0; i < s.items.size(); i++) {
            Item it = s.items.get(i);
            if (it.category().equals(cat.key())) inv.setItem(it.slot(), s.itemIcons.get(i));
        }
        inv.setItem(22, backButton());
        inv.setItem(26, Items.closeButton());
        p.openInventory(inv);
    }

    // ---------- личные бусты ----------

    private static int[] boostSlots(int n) {
        return switch (n) {
            case 4 -> BOOST_SLOTS_4;
            case 5 -> BOOST_SLOTS_5;
            case 6 -> BOOST_SLOTS_6;
            default -> BOOST_SLOTS_3;
        };
    }

    private void openBoosts(Player p, Category cat) {
        FateHolder holder = new FateHolder("shop:" + cat.key());
        Inventory inv = Bukkit.createInventory(holder, 27, Msg.c("&8Магазин: " + cat.title()));
        holder.bind(inv);
        Items.fill(inv);
        List<BoostsManager.Offer> offers = boosts.offers(p);
        int[] slots = boostSlots(offers.size());
        for (int i = 0; i < offers.size() && i < slots.length; i++) {
            BoostsManager.Offer o = offers.get(i);
            inv.setItem(slots[i], Items.make(o.icon(), "&6" + o.name(),
                    "&7Цена: &f" + o.price() + " Эхо",
                    "&7Личный буст на эту неделю",
                    "",
                    "&eКлик — купить"));
        }
        if (offers.isEmpty()) inv.setItem(13, Items.make(Material.BARRIER, "&cНет доступных бустов"));
        inv.setItem(4, Items.make(Material.CLOCK, "&6Куплено сегодня: &f" + boosts.boughtToday(p.getUniqueId())
                + "/" + boosts.dailyLimit(), "&7Список обновляется каждый понедельник"));
        inv.setItem(22, backButton());
        inv.setItem(26, Items.closeButton());
        p.openInventory(inv);
    }

    private void handleBoosts(Player p, int slot) {
        List<BoostsManager.Offer> offers = boosts.offers(p);
        int[] slots = boostSlots(offers.size());
        for (int i = 0; i < offers.size() && i < slots.length; i++) {
            if (slots[i] == slot) {
                boosts.buy(p, offers.get(i).id());
                openBoosts(p, categoryByKey(CAT_BOOSTS)); // обновляем счётчик покупок
                return;
            }
        }
    }

    private Category categoryByKey(String key) {
        for (Category c : snap().categories) if (c.key().equals(key)) return c;
        return new Category(key, 0, key, Material.CHEST);
    }

    // ---------- вечные улучшения (уровни 0-3) ----------

    private static String num(int v) {
        return String.format(Locale.US, "%,d", v).replace(',', ' ');
    }

    private int level(Player p, Upgrade u) {
        return (int) Math.max(0, Math.min(u.max(), data.getLong(p.getUniqueId(), "upgrade_" + u.key(), 0)));
    }

    private static String at(List<String> list, int i) {
        return i >= 0 && i < list.size() ? list.get(i) : "—";
    }

    private ItemStack upgradeIcon(Player p, Upgrade u) {
        int lvl = level(p, u);
        List<String> lore = new ArrayList<>();
        lore.add("§7Текущий уровень: §e[" + lvl + "/" + u.max() + "]");
        lore.add("§7Сейчас: §f" + (lvl == 0 ? "§cНе куплено" : at(u.now(), lvl - 1)));
        if (lvl >= u.max()) {
            lore.add("§aМаксимальный уровень!");
        } else {
            lore.add("§7Следующий уровень: §f" + at(u.next(), lvl));
            lore.add("§7Цена: §e" + num(u.prices()[lvl]) + " Эхо");
            lore.add("§aНажми, чтобы улучшить!");
        }
        return Items.make(u.icon(), "&6" + u.name(), lore.toArray(new String[0]));
    }

    private void openUpgrades(Player p, Category cat) {
        FateHolder holder = new FateHolder("shop:" + cat.key());
        Inventory inv = Bukkit.createInventory(holder, 27, Msg.c("&8Магазин: " + cat.title()));
        holder.bind(inv);
        Items.fill(inv);
        for (Upgrade u : snap().upgrades) inv.setItem(u.slot(), upgradeIcon(p, u));
        inv.setItem(4, Items.make(Material.GOLD_INGOT, "&6Твоё Эхо: &f" + echo.format(echo.getEcho(p)),
                "&7Улучшения вечные и не дают бонусов к Эхо"));
        inv.setItem(22, backButton());
        inv.setItem(26, Items.closeButton());
        p.openInventory(inv);
    }

    private void handleUpgrades(Player p, int slot) {
        for (Upgrade u : snap().upgrades) {
            if (u.slot() != slot) continue;
            int lvl = level(p, u);
            if (lvl >= u.max()) {
                Msg.send(p, "&aЭто улучшение уже на максимальном уровне.");
                return;
            }
            int price = u.prices()[lvl];
            List<String> cmds = plugin.getConfig().getStringList("shop.rewards.upgrade_" + u.key() + "_" + (lvl + 1));
            if (cmds.isEmpty()) {
                Msg.send(p, "&cУлучшение временно недоступно.");
                return;
            }
            if (!echo.take(p, price)) {
                Msg.send(p, "&cНе хватает Эхо: нужно " + num(price) + ", у тебя " + echo.format(echo.getEcho(p)));
                return;
            }
            try {
                runRewardCommands(plugin, p, cmds);
                data.setLong(p.getUniqueId(), "upgrade_" + u.key(), lvl + 1L);
            } catch (RuntimeException e) {
                echo.addEcho(p, price);
                Msg.send(p, "&cОшибка выдачи, Эхо возвращено.");
                plugin.getLogger().warning("Upgrade " + u.key() + ": " + e.getMessage());
                return;
            }
            Msg.send(p, "&aУлучшено: &6" + u.name() + " &7до уровня &e" + (lvl + 1) + "/" + u.max()
                    + " &7(-" + num(price) + " Эхо)");
            if (purchaseHook != null) purchaseHook.accept(p);
            openUpgrades(p, categoryByKey(CAT_UPGRADES));
            return;
        }
    }

    private ItemStack back;

    private ItemStack backButton() {
        ItemStack b = back;
        if (b == null) back = b = Items.make(Material.ARROW, "&7Назад");
        return b;
    }

    public void handleMain(Player p, int slot) {
        if (slot == 22) {
            p.closeInventory();
            return;
        }
        for (Category c : snap().categories) {
            if (c.slot() == slot) {
                openCategory(p, c);
                return;
            }
        }
    }

    public void handleCategory(Player p, String catKey, int slot) {
        if (slot == 26) {
            p.closeInventory();
            return;
        }
        if (slot == 22) {
            openMain(p);
            return;
        }
        if (catKey.equals(CAT_BOOSTS)) {
            handleBoosts(p, slot);
            return;
        }
        if (catKey.equals(CAT_UPGRADES)) {
            handleUpgrades(p, slot);
            return;
        }
        for (Item it : snap().items) {
            if (it.category().equals(catKey) && it.slot() == slot) {
                purchase(p, it);
                return;
            }
        }
    }

    // ---------- покупка ----------

    private void purchase(Player p, Item item) {
        if (!item.enabled()) {
            Msg.send(p, "&cТовар временно недоступен.");
            return;
        }
        if (item.id().equals("home_plus1") && plugin.getConfig().getStringList("shop.rewards.home_plus1").isEmpty()
                && !homeBonus.canGrant(p)) {
            Msg.send(p, "&cМаксимум домов уже достигнут.");
            return;
        }
        boolean isCase = item.id().startsWith("case_");
        if (isCase && !canFit(p, CaseItems.make(plugin, item.id().equals("case_rare")))) {
            Msg.send(p, "&cИнвентарь полон! Освободите слот и повторите покупку.");
            return;
        }
        if (!echo.take(p, item.price())) {
            Msg.send(p, "&cНе хватает Эхо: нужно " + item.price() + ", у тебя " + echo.format(echo.getEcho(p)));
            return;
        }
        try {
            deliver(p, item);
            Msg.send(p, "&aКуплено: &6" + item.name() + " &7(-" + item.price() + " Эхо)");
            if (purchaseHook != null) purchaseHook.accept(p);
        } catch (Exception e) {
            echo.addEcho(p, item.price());
            Msg.send(p, "&cОшибка выдачи, Эхо возвращено.");
            plugin.getLogger().warning("Shop deliver " + item.id() + ": " + e.getMessage());
        }
    }

    /** Поместится ли предмет в инвентарь (свободный слот или неполная стопка такого же). */
    private static boolean canFit(Player p, ItemStack it) {
        Inventory inv = p.getInventory();
        if (inv.firstEmpty() != -1) return true;
        for (ItemStack c : inv.getStorageContents()) {
            if (c != null && c.isSimilar(it) && c.getAmount() < c.getMaxStackSize()) return true;
        }
        return false;
    }

    private void deliver(Player p, Item item) {
        List<String> cmds = plugin.getConfig().getStringList("shop.rewards." + item.id());
        if (!cmds.isEmpty()) {
            runRewardCommands(plugin, p, cmds);
            return;
        }
        switch (item.id()) {
            case "rename" -> Items.give(p, Items.make(Material.NAME_TAG, "&6Бирка переименования",
                    "&7Переименуй предмет на наковальне"));
            case "case_common" -> Items.give(p, CaseItems.make(plugin, false));
            case "case_rare" -> Items.give(p, CaseItems.make(plugin, true));
            case "boost_x2" -> echo.addBoost(p.getUniqueId(), 2.0, 3600);
            case "home_plus1" -> {
                if (!homeBonus.grant(p)) throw new IllegalStateException("лимит домов достигнут");
            }
            default -> throw new IllegalStateException("нет награды для " + item.id());
        }
    }

    /** Консольные команды выдачи с подстановкой %player%; запрещённые (ранги, op, wildcard) пропускаются. */
    public static void runRewardCommands(FateCore plugin, Player p, List<String> cmds) {
        for (String c : cmds) {
            String line = c.replace("%player%", p.getName());
            if (FORBIDDEN.matcher(line).find()) {
                plugin.getLogger().warning("Shop: запрещённая команда пропущена: " + line);
                continue;
            }
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), line);
        }
    }
}
