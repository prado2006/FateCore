package ru.fatecore.learn;

import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.fatecore.FateCore;
import ru.fatecore.util.Items;

import java.util.List;

/**
 * Предметы-кейсы из /shop: «Кейс Странника» (common, CHEST) и «Кейс Судьбы» (rare, ENDER_CHEST).
 * Название и описание — config.yml → cases.<common|rare>. Открывает кейс {@link CaseOpeningListener} (ПКМ).
 */
public final class CaseItems {
    public static final String PDC_CASE = "case";

    private CaseItems() {}

    public static ItemStack make(FateCore plugin, boolean rare) {
        FileConfiguration cfg = plugin.getConfig();
        String path = rare ? "cases.rare" : "cases.common";
        String name = cfg.getString(path + ".name", rare ? "&5Кейс Судьбы" : "&aКейс Странника");
        List<String> lore = cfg.getStringList(path + ".lore");
        if (lore.isEmpty()) {
            lore = List.of(rare ? "&7Содержит: &e400-800 Эхо, алмазы, питомцев, ключи."
                    : "&7Содержит: &e100-300 Эхо, ресурсы, еду, префиксы.");
        }
        lore = new java.util.ArrayList<>(lore);
        lore.add("");
        lore.add("&aПКМ — открыть");
        ItemStack chest = Items.make(rare ? Material.ENDER_CHEST : Material.CHEST, name, lore.toArray(new String[0]));
        ItemMeta m = chest.getItemMeta();
        m.getPersistentDataContainer().set(plugin.key(PDC_CASE), PersistentDataType.STRING, rare ? "rare" : "common");
        chest.setItemMeta(m);
        return chest;
    }

    /** Ключ (как в наградах квестов). */
    public static ItemStack key(FateCore plugin) {
        ItemStack key = Items.make(Material.TRIPWIRE_HOOK, "&6Ключ", "&7Для открытия кейса");
        ItemMeta meta = key.getItemMeta();
        meta.getPersistentDataContainer().set(plugin.key("key"), PersistentDataType.BYTE, (byte) 1);
        key.setItemMeta(meta);
        return key;
    }
}
