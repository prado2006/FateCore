package ru.fatecore.learn;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import ru.fatecore.FateCore;
import ru.fatecore.api.IDataStore;
import ru.fatecore.earn.EarnService;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.util.Modes;

import java.util.UUID;
import java.util.function.Predicate;

/** Раз в минуту считает время игры; каждый отыгранный час — Эхо (economy.hourly-playtime-reward, по умолчанию 5). */
public final class PlaytimeTask implements Runnable {
    public static final String KEY = "playtime.minutes";

    private final FateCore plugin;
    private final IDataStore store;
    private final EchoManager echo;
    private final EarnService earn;
    private final Predicate<Player> eligible;

    public PlaytimeTask(FateCore plugin, IDataStore store, EchoManager echo, EarnService earn, Predicate<Player> eligible) {
        this.plugin = plugin;
        this.store = store;
        this.echo = echo;
        this.earn = earn;
        this.eligible = eligible;
    }

    /** Базовая награда за час (без множителей). */
    public static double baseReward(FileConfiguration cfg) {
        return Math.max(0, cfg.getDouble("economy.hourly-playtime-reward", 5));
    }

    /** Базовая награда для текстов меню (без лишних знаков: «5», а не «5.0»). */
    public static String rewardText(FileConfiguration cfg) {
        double v = baseReward(cfg);
        return v == Math.floor(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    @Override
    public void run() {
        double base = baseReward(plugin.getConfig());
        for (Player p : Bukkit.getOnlinePlayers()) {
            // Проверяем, подходит ли игрок (например, авторизован ли он)
            if (!eligible.test(p)) continue;

            UUID id = p.getUniqueId();
            long minutes = store.getLong(id, KEY, 0) + 1;
            store.setLong(id, KEY, minutes);

            // Каждый 60 минут (1 час)
            if (minutes % 60 == 0 && base > 0) {
                // с учётом донат-множителя, активных бустов и бонуса дня (режим берётся по текущему миру)
                double amount = base * earn.totalMultiplier(p, Modes.of(p.getWorld()));
                echo.addEcho(p, amount);
                p.sendMessage("§a[Эхо Судьбы] §eВы отыграли ещё час! §fНаграда: §a+" + echo.format(amount) + " Эхо.");
            }
        }
    }
}
