package ru.fatecore.learn;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.persistence.PersistentDataType;
import ru.fatecore.FateCore;
import ru.fatecore.echo.EchoManager;
import ru.fatecore.util.Items;
import ru.fatecore.util.Msg;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Открытие кейсов: ПКМ по предмету-кейсу (PDC "case") — предмет списывается, выдаётся награда
 * из config.yml → cases.<common|rare>.rewards (по весам), показываются Title и звук.
 */
public final class CaseOpeningListener implements Listener {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();

    private final FateCore plugin;
    private final EchoManager echo;

    public CaseOpeningListener(FateCore plugin, EchoManager echo) {
        this.plugin = plugin;
        this.echo = echo;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack it = e.getItem();
        if (it == null) return;
        Material type = it.getType();
        if (type != Material.CHEST && type != Material.ENDER_CHEST) return; // быстрый выход: большинство кликов — не кейсы
        if (!it.hasItemMeta()) return;
        String kind = it.getItemMeta().getPersistentDataContainer()
                .get(plugin.key(CaseItems.PDC_CASE), PersistentDataType.STRING);
        if (kind == null) return;

        e.setUseItemInHand(Event.Result.DENY);
        e.setUseInteractedBlock(Event.Result.DENY);
        e.setCancelled(true); // кейс нельзя поставить как сундук

        Player p = e.getPlayer();
        List<Map<?, ?>> rewards = plugin.getConfig().getMapList("cases." + kind + ".rewards");
        if (rewards.isEmpty()) {
            Msg.send(p, "&cНаграды кейса не настроены. Обратитесь к администрации.");
            return;
        }
        Map<?, ?> reward = pick(rewards);

        // списываем ровно один кейс из основной руки
        PlayerInventory inv = p.getInventory();
        ItemStack hand = inv.getItemInMainHand();
        if (hand.getAmount() > 1) {
            hand.setAmount(hand.getAmount() - 1);
            inv.setItemInMainHand(hand);
        } else {
            inv.setItemInMainHand(null);
        }

        String label = apply(p, reward);
        boolean rare = kind.equals("rare");
        p.showTitle(Title.title(
                LEGACY.deserialize(rare ? "§5§lКейс Судьбы" : "§a§lКейс Странника").decoration(TextDecoration.ITALIC, false),
                Component.text("").append(LEGACY.deserialize("§fВаша награда: §e" + label)),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(600))));
        p.playSound(p.getLocation(), Sound.BLOCK_CHEST_OPEN, 1f, 1f);
        p.playSound(p.getLocation(), rare ? Sound.UI_TOAST_CHALLENGE_COMPLETE : Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        Msg.send(p, "&aКейс открыт! Награда: &e" + label);
    }

    private static Map<?, ?> pick(List<Map<?, ?>> rewards) {
        int total = 0;
        for (Map<?, ?> r : rewards) total += Math.max(0, weight(r));
        if (total <= 0) return rewards.get(0);
        int roll = ThreadLocalRandom.current().nextInt(total);
        for (Map<?, ?> r : rewards) {
            roll -= Math.max(0, weight(r));
            if (roll < 0) return r;
        }
        return rewards.get(rewards.size() - 1);
    }

    private static int weight(Map<?, ?> r) {
        return r.get("weight") instanceof Number n ? n.intValue() : 1;
    }

    /** Выдаёт награду, возвращает текст для Title. */
    private String apply(Player p, Map<?, ?> r) {
        String type = String.valueOf(r.get("type")).toLowerCase();
        String label = r.get("label") == null ? type : String.valueOf(r.get("label"));
        switch (type) {
            case "echo" -> {
                int min = r.get("min") instanceof Number n ? n.intValue() : 100;
                int max = r.get("max") instanceof Number n ? n.intValue() : min;
                int amount = ThreadLocalRandom.current().nextInt(Math.min(min, max), Math.max(min, max) + 1);
                echo.addEcho(p, amount);
                return amount + " Эхо";
            }
            case "item" -> {
                Material m = Material.matchMaterial(String.valueOf(r.get("material")));
                int amount = r.get("amount") instanceof Number n ? n.intValue() : 1;
                if (m == null) {
                    plugin.getLogger().warning("cases: неизвестный материал " + r.get("material"));
                    return label;
                }
                Items.give(p, new ItemStack(m, Math.max(1, amount)));
            }
            case "key" -> {
                int amount = r.get("amount") instanceof Number n ? n.intValue() : 1;
                for (int i = 0; i < Math.max(1, amount); i++) Items.give(p, CaseItems.key(plugin));
            }
            case "command" -> {
                Object cmds = r.get("commands");
                if (cmds instanceof List<?> list) {
                    ShopGui.runRewardCommands(plugin, p, list.stream().map(String::valueOf).toList());
                }
            }
            default -> plugin.getLogger().warning("cases: неизвестный тип награды " + type);
        }
        return label;
    }
}
