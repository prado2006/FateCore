package ru.fatecore.rotation;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import ru.fatecore.api.IDataStore;
import ru.fatecore.util.Modes;
import ru.fatecore.util.Msg;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * МОДУЛЬ 3 — Персональный бонус дня: у каждого игрока свой режим с Эхо x2.
 * Режим выбирается случайно при входе (раз в сутки по МСК) и хранится в IDataStore (ключ {@value #KEY}),
 * поэтому перезаход не позволяет «перебрасывать» бонус. Плейсхолдер %fatecore_featured% показывает личный бонус.
 */
public final class RotationManager implements Listener {
    public static final String KEY = "daily_bonus";
    private static final String KEY_DAY = "daily_bonus_day";
    private static final long MSK_OFFSET_MS = 3L * 60 * 60 * 1000;
    private static final long DAY_MS = 24L * 60 * 60 * 1000;

    private final IDataStore data;

    public RotationManager(IDataStore data) {
        this.data = data;
    }

    /** Номер суток по МСК (UTC+3 без перехода на летнее время). */
    private static long today() {
        return (System.currentTimeMillis() + MSK_OFFSET_MS) / DAY_MS;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        String mode = getBonusMode(p.getUniqueId());
        Msg.send(p, "&aВаш бонус дня: Эхо &ex2 &aв режиме &6" + Modes.display(mode) + "&a!");
    }

    /** Личный режим с Эхо x2; при смене суток (или первом входе) выбирается заново. */
    public String getBonusMode(UUID id) {
        long today = today();
        String mode = data.getString(id, KEY, null);
        if (mode != null && Modes.MODES.contains(mode) && data.getLong(id, KEY_DAY, -1) == today) return mode;
        mode = Modes.MODES.get(ThreadLocalRandom.current().nextInt(Modes.MODES.size()));
        data.setString(id, KEY, mode);
        data.setLong(id, KEY_DAY, today);
        return mode;
    }

    /** 2.0 для личного режима дня, иначе 1.0. Принимает только "survival"/"bedwars"/"skywars". */
    public double getMultiplier(UUID id, String mode) {
        if (mode == null) return 1.0;
        String m = mode.toLowerCase();
        if (!Modes.MODES.contains(m)) return 1.0;
        return m.equals(getBonusMode(id)) ? 2.0 : 1.0;
    }
}
