package ru.fatecore.quest;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import ru.fatecore.quest.QuestManager.Type;
import ru.fatecore.util.Modes;

import java.util.EnumSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Квесты Выживания: бревно (BREAK_LOG), любой добытый блок с фильтром (BREAK_BLOCK), урожай (HARVEST), поставленный блок (PLACE_BLOCK).
 * Блок, поставленный игроком, при ломании не засчитывается (защита от «поставил-сломал»; память до перезапуска).
 * Считается только в мире Выживания и не в креативе.
 */
public final class BlockBreakListener implements Listener {
    private static final int MAX_TRACKED = 5000;

    /** Культуры и «бахча»: Ageable считаются только созревшими. */
    private static final Set<Material> HARVESTABLE = EnumSet.of(
            Material.WHEAT, Material.CARROTS, Material.POTATOES, Material.BEETROOTS, Material.NETHER_WART,
            Material.COCOA, Material.SWEET_BERRY_BUSH, Material.SUGAR_CANE, Material.MELON, Material.PUMPKIN,
            Material.CACTUS, Material.BAMBOO);

    private final QuestManager quests;
    private final Set<Long> placed = new LinkedHashSet<>();

    public BlockBreakListener(QuestManager quests) {
        this.quests = quests;
    }

    private static long key(Block b) {
        return (((long) b.getX() & 0x3FFFFFFL) << 38) | (((long) b.getZ() & 0x3FFFFFFL) << 12) | ((long) b.getY() & 0xFFFL);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Block b = e.getBlockPlaced();
        if (!Modes.isSurvivalFamily(b.getWorld()) || e.getPlayer().getGameMode() == GameMode.CREATIVE) return;
        placed.add(key(b));
        if (placed.size() > MAX_TRACKED) {
            Iterator<Long> it = placed.iterator();
            it.next();
            it.remove();
        }
        quests.addProgress(e.getPlayer(), Type.PLACE_BLOCK, 1, b.getType().name());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (!Modes.isSurvivalFamily(b.getWorld()) || e.getPlayer().getGameMode() == GameMode.CREATIVE) return;
        boolean wasPlaced = placed.remove(key(b));
        String name = b.getType().name();
        // Урожай: созревшие культуры считаются всегда (replant не мешает); арбуз, тыква, тростник и т.п. — если не поставлены игроком
        if (HARVESTABLE.contains(b.getType())) {
            boolean ripe = !(b.getBlockData() instanceof Ageable age) || age.getAge() >= age.getMaximumAge();
            boolean crop = b.getBlockData() instanceof Ageable;
            if (ripe && (crop || !wasPlaced)) quests.addProgress(e.getPlayer(), Type.HARVEST, 1, name);
        }
        if (wasPlaced) return;
        if (Tag.LOGS.isTagged(b.getType())) quests.addProgress(e.getPlayer(), Type.BREAK_LOG, 1, name);
        quests.addProgress(e.getPlayer(), Type.BREAK_BLOCK, 1, name);
    }
}
