package ru.fatecore.quest;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Animals;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityEnterLoveModeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType.SlotType;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.MerchantInventory;
import ru.fatecore.quest.QuestManager.Type;
import ru.fatecore.util.Modes;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Квесты Исследования и Взаимодействия: пешие блоки (WALK, только пешком), Нижний мир / Край (VISIT_*),
 * торговля с жителем (TRADE), кормление животных (FEED_ANIMAL), наковальня (ANVIL). Только мир Выживания и его измерения.
 */
public final class QuestExploreListener implements Listener {
    private final QuestManager quests;
    /** Накопленная дробная часть пройденного пешком пути (PlayerMoveEvent вызывается в главном потоке). */
    private final Map<UUID, Double> walk = new HashMap<>();

    public QuestExploreListener(QuestManager quests) {
        this.quests = quests;
    }

    private static boolean survival(Player p) {
        return Modes.isSurvivalFamily(p.getWorld()) && p.getGameMode() != GameMode.CREATIVE;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        walk.remove(e.getPlayer().getUniqueId());
    }

    /**
     * «Пройти X блоков пешком» (PlayerMoveEvent). Считается ТОЛЬКО пеший ход (ходьба, бег, прыжки по земле):
     * не считаются полёт (в т.ч. элитры и креатив-полёт), любой транспорт (лошадь, лодка, вагонетка, свинья и т.п.),
     * плавание, телепорты и рывки больше 1 блока за событие. Считается горизонтальное смещение; дробные
     * части копятся и засчитываются целыми блоками. Только мир Выживания и его измерения, не креатив.
     * Для скорости: событие без смещения (поворот головы) отбрасывается первым, затем проверяется,
     * есть ли у игрока квест на ходьбу сегодня.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        if (dx == 0 && dz == 0) return; // поворот камеры / вертикальное движение
        Player p = e.getPlayer();
        if (!survival(p)) return;
        if (p.isInsideVehicle() || p.isFlying() || p.isGliding() || p.isSwimming() || p.isRiptiding()) return;
        UUID id = p.getUniqueId();
        if (!quests.hasActive(id, Type.WALK)) return;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > 1.0) return; // телепорт / рывок
        double acc = walk.merge(id, dist, Double::sum);
        if (acc >= 1.0) {
            int blocks = (int) acc;
            walk.put(id, acc - blocks);
            quests.addProgress(p, Type.WALK, blocks);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        World w = p.getWorld();
        if (!Modes.isSurvivalFamily(w) || p.getGameMode() == GameMode.CREATIVE) return;
        if (w.getEnvironment() == World.Environment.NETHER) quests.addProgress(p, Type.VISIT_NETHER, 1);
        else if (w.getEnvironment() == World.Environment.THE_END) quests.addProgress(p, Type.VISIT_END, 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (e.getSlotType() != SlotType.RESULT || !(e.getWhoClicked() instanceof Player p)) return; // быстрый выход
        if (e.getCurrentItem() == null || e.getCurrentItem().getType().isAir()) return;
        if (!e.isShiftClick() && !e.getCursor().getType().isAir()) return; // забрать результат нельзя — курсор занят
        if (!survival(p)) return;
        if (e.getInventory() instanceof MerchantInventory) {
            quests.addProgress(p, Type.TRADE, 1);
        } else if (e.getInventory() instanceof AnvilInventory anvil && p.getLevel() >= anvil.getRepairCost()) {
            quests.addProgress(p, Type.ANVIL, 1);
        }
    }

    /** Покормили животное (оно готово к размножению). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFeed(EntityEnterLoveModeEvent e) {
        HumanEntity h = e.getHumanEntity();
        if (!(h instanceof Player p) || !(e.getEntity() instanceof Animals) || !survival(p)) return;
        quests.addProgress(p, Type.FEED_ANIMAL, 1);
    }
}
