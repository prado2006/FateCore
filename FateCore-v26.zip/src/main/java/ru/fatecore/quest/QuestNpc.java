package ru.fatecore.quest;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Villager;
import org.bukkit.persistence.PersistentDataType;
import ru.fatecore.FateCore;
import ru.fatecore.util.ConfigUtil;
import ru.fatecore.util.Retry;

import java.util.ArrayList;
import java.util.List;

/**
 * Квестовый Мастер: Villager без AI внутри FateCore (Citizens не нужен).
 * Спавнится в onEnable в quest.npc.location, удаляется в onDisable, помечен PDC-ключом quest_npc.
 */
public final class QuestNpc {
    public static final String NAME = "Квестовый Мастер";

    private final FateCore plugin;
    public static final String LABEL = "§6§lКВЕСТЫ §r§7(ПКМ) §e- Случайная награда за 3 шт.!";

    private final NamespacedKey key;
    private final NamespacedKey labelKey;

    public QuestNpc(FateCore plugin) {
        this.plugin = plugin;
        this.key = plugin.key("quest_npc");
        this.labelKey = plugin.key("quest_npc_label");
    }

    private boolean isLabel(Entity e) {
        return e instanceof ArmorStand a && a.getPersistentDataContainer().has(labelKey, PersistentDataType.BYTE);
    }

    /** Невидимая подпись над Квестовым Мастером (ArmorStand-маркер). */
    private void spawnLabel(Location npcLoc) {
        Location at = npcLoc.clone().add(0, 2.2, 0);
        npcLoc.getWorld().spawn(at, ArmorStand.class, a -> {
            a.setInvisible(true);
            a.setMarker(true);
            a.setGravity(false);
            a.setInvulnerable(true);
            a.setSilent(true);
            a.setPersistent(true);
            a.setCustomName(LABEL);
            a.setCustomNameVisible(true);
            a.getPersistentDataContainer().set(labelKey, PersistentDataType.BYTE, (byte) 1);
        });
    }

    public boolean isNpc(Entity e) {
        return e instanceof Villager v && v.getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    /** Ждёт загрузки мира и создаёт NPC, если рядом с точкой его ещё нет. */
    public void spawnWhenReady() {
        Retry.run(plugin, 100L, 10, this::spawnIfMissing);
    }

    /** true — NPC на месте (был или создан), false — мир ещё не загружен. Лишние копии рядом удаляются. */
    public boolean spawnIfMissing() {
        Location loc = ConfigUtil.location(plugin.getConfig().getConfigurationSection("quest.npc.location"));
        if (loc == null) return false;
        loc.getChunk().load();
        List<Villager> found = new ArrayList<>();
        List<ArmorStand> labels = new ArrayList<>();
        for (Entity e : loc.getWorld().getNearbyEntities(loc, 3, 4, 3)) {
            if (isNpc(e)) found.add((Villager) e);
            else if (isLabel(e)) labels.add((ArmorStand) e);
        }
        if (!found.isEmpty()) {
            for (int i = 1; i < found.size(); i++) found.get(i).remove();
            for (int i = 1; i < labels.size(); i++) labels.get(i).remove();
            if (labels.isEmpty()) spawnLabel(loc);
            return true;
        }
        for (ArmorStand a : labels) a.remove();
        loc.getWorld().spawn(loc, Villager.class, v -> {
            v.setAI(false);
            v.setCustomName(NAME);
            v.setCustomNameVisible(true);
            v.setPersistent(true);
            v.setRemoveWhenFarAway(false);
            v.setInvulnerable(true);
            v.setSilent(true);
            v.setProfession(Villager.Profession.LIBRARIAN);
            v.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        });
        spawnLabel(loc);
        return true;
    }

    /** Удаляет всех Квестовых Мастеров в загруженных чанках (вызывается в onDisable и перед респавном). */
    public int removeAll() {
        int n = 0;
        for (World w : Bukkit.getWorlds()) {
            for (Villager v : w.getEntitiesByClass(Villager.class)) {
                if (isNpc(v)) {
                    v.remove();
                    n++;
                }
            }
            for (ArmorStand a : w.getEntitiesByClass(ArmorStand.class)) {
                if (isLabel(a)) a.remove();
            }
        }
        return n;
    }

    /** Пересоздаёт NPC в актуальной точке из конфига (после правки координат). */
    public boolean respawn() {
        removeAll();
        return spawnIfMissing();
    }
}
