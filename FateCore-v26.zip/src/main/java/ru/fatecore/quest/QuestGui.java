package ru.fatecore.quest;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import ru.fatecore.gui.FateHolder;
import ru.fatecore.quest.QuestManager.Def;
import ru.fatecore.util.Items;
import ru.fatecore.util.Msg;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * GUI Квестового Мастера (27 слотов): слоты 11 / 13 / 15 — три личных квеста дня, 22 — случайная награда, 26 — «Закрыть».
 * Открывается кликом по NPC и командой /quests. В каждой награде: «Привилегии не выдаются.»
 */
public final class QuestGui {
    private static final String NO_PRIV = "&7Привилегии не выдаются.";
    private static final int[] SLOTS = {11, 13, 15};
    private static final int[] SLOTS_4 = {10, 12, 14, 16};
    private static final int[] SLOTS_5 = {10, 11, 13, 15, 16};

    private final QuestManager quests;

    public QuestGui(QuestManager quests) {
        this.quests = quests;
    }

    public void open(Player p) {
        UUID id = p.getUniqueId();
        FateHolder holder = new FateHolder("quests");
        Inventory inv = Bukkit.createInventory(holder, 27, Msg.c("&8Квестовый Мастер"));
        holder.bind(inv);
        Items.fill(inv);

        List<Def> active = quests.activeQuests(id);
        int[] slots = slotsFor(active.size());
        for (int i = 0; i < active.size() && i < slots.length; i++) {
            inv.setItem(slots[i], questItem(id, active.get(i)));
        }
        inv.setItem(22, plushkaItem(id, active.size()));
        inv.setItem(26, Items.closeButton());
        p.openInventory(inv);
    }

    private static int[] slotsFor(int n) {
        return switch (n) {
            case 4 -> SLOTS_4;
            case 5 -> SLOTS_5;
            default -> SLOTS;
        };
    }

    private ItemStack plushkaItem(UUID id, int total) {
        int done = quests.dayCompleted(id);
        boolean given = quests.plushkaGiven(id);
        List<String> lore = new ArrayList<>();
        lore.add("§e§lВыполните все 3 задания и получите 1 случайную награду!");
        lore.add("&eВыполнено: " + done + "/" + total);
        lore.add(given ? "&aНаграда получена" : "&cНаграда ещё не получена");
        lore.add(NO_PRIV);
        // серая, пока не выполнены все квесты дня
        return given
                ? Items.make(Material.BOOK, "&dСлучайная награда", lore.toArray(new String[0]))
                : Items.make(Material.GRAY_DYE, "&7Случайная награда", lore.toArray(new String[0]));
    }

    private ItemStack questItem(UUID id, Def d) {
        int cur = quests.progress(id, d);
        boolean done = cur >= d.target();
        return Items.make(d.icon(), d.difficulty().color + d.title(),
                d.description().isEmpty() ? "&7Категория: &f" + (d.category().isEmpty() ? "—" : d.category()) : "&7" + d.description(),
                "&7Категория: &f" + (d.category().isEmpty() ? "—" : d.category()),
                "&7Сложность: " + d.difficulty().color + d.difficulty().label,
                "&7Прогресс: &f" + cur + "/" + d.target(),
                done ? "&aВыполнено" : "&cВ процессе",
                "&6Награда: &f" + quests.rewardText(d),
                NO_PRIV,
                "&8Новые квесты в 00:00 МСК");
    }
}
