package ru.fatecore.quest;

import org.bukkit.GameMode;
import org.bukkit.entity.Animals;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import ru.fatecore.quest.QuestManager.Type;
import ru.fatecore.util.Modes;

/** Квесты Выживания: убийство мобов (KILL_MOB), рыбалка (FISH), крафт (CRAFT). Только мир Выживания, не креатив. */
public final class QuestActivityListener implements Listener {
    private final QuestManager quests;

    public QuestActivityListener(QuestManager quests) {
        this.quests = quests;
    }

    private static boolean survival(Player p) {
        return Modes.isSurvivalFamily(p.getWorld()) && p.getGameMode() != GameMode.CREATIVE; // Выживание + Незер + Край (блейзы, эндермены)
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMobKill(EntityDeathEvent e) {
        LivingEntity dead = e.getEntity();
        if (dead instanceof Player) return;
        Player killer = dead.getKiller();
        if (killer == null || !survival(killer)) return;
        String hostile = dead instanceof Enemy ? "HOSTILE" : null;
        String animal = dead instanceof Animals ? "ANIMAL" : null;
        quests.addProgress(killer, Type.KILL_MOB, 1, dead.getType().name(), hostile, animal);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent e) {
        if (e.getState() != PlayerFishEvent.State.CAUGHT_FISH || !survival(e.getPlayer())) return;
        Entity caught = e.getCaught();
        String name = caught instanceof Item it ? it.getItemStack().getType().name() : null;
        quests.addProgress(e.getPlayer(), Type.FISH, 1, name);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCraft(CraftItemEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || !survival(p)) return;
        ItemStack result = e.getRecipe().getResult();
        int crafts = 1;
        if (e.isShiftClick()) { // shift-клик собирает сразу много: число крафтов = наименьшая стопка ингредиентов
            crafts = Integer.MAX_VALUE;
            for (ItemStack it : e.getInventory().getMatrix()) {
                if (it != null && !it.getType().isAir()) crafts = Math.min(crafts, it.getAmount());
            }
            if (crafts == Integer.MAX_VALUE || crafts < 1) crafts = 1;
        }
        quests.addProgress(p, Type.CRAFT, crafts * Math.max(1, result.getAmount()), result.getType().name());
    }
}
